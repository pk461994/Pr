n=int(input('Enter no of Students:'))
d={}
for i in range(n):
    name=input('Enter student name:')
    marks=input('Enter student marks:')
    d[name]=marks
print(d)
for name,marks in d.items():
    print('{} got {} marks'.format(name,marks))
while True:
    name=input('Enter student name to get marks:')
    marks=d.get(name,-1)    #If the name is there We'll get corresponding marks if not we'll get -1
    if marks==-1:           #marks==-1 means student not found
        print('Student not found')
    else:
        print('The marks of {}:{}'.format(name,marks))
    option=input('Do you want to find another students marks[Yes|No]:')
    if option=="No":
        break        #If option is not No then again loop will go to name=input('Enter student name to get marks:')
print('Thanks for using our Application!')

#Output:-
#Enter no of Students:2
#Enter student name:Prashant
#Enter student marks:99.9%
#Enter student name:Durga
#Enter student marks:99%
#{'Prashant': '99.9%', 'Durga': '99%'}
#Prashant got 99.9% marks
#Durga got 99% marks
#Enter student name to get marks:Prashant
#The marks of Prashant:99.9%
#Do you want to find another students marks[Yes|No]:No
#Thanks for using our Application!







#Enter no of Students:2
#Enter student name:Aishwarya
#Enter student marks:99%
#Enter student name:Prashant
#Enter student marks:99.9%
#{'Aishwarya': '99%', 'Prashant': '99.9%'}
#Aishwarya got 99% marks
#Prashant got 99.9% marks
#Enter student name to get marks:Rekha
#Student not found
#Do you want to find another students marks[Yes|No]:Yes
#Enter student name to get marks:Aishwarya
#The marks of Aishwarya:99%
#Do you want to find another students marks[Yes|No]:No
#Thanks for using our Application!
