n=int(input('Enter the number of rows:'))
for i in range(1,n+1):  #i represents row number
    for j in range(i):  #j represents the number of *. We can also take range(1,i+1) in place of range(i)
        print('*',end=' ')
    print()

#Alternate Code
#n=int(input('Enter the number of rows:'))
#for i in range(1,n+1):
    #print('* '*i)
