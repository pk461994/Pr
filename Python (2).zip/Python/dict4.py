d={100:'abc',200:'pqr',300:'xyz'}
print(d.setdefault(100,'pkj')) #setdefault() method used for setting the default value
print(d.setdefault(400,'mno'))  #It will be added
print(d)

#Output:
#abc
#mno
#{100: 'abc', 200: 'pqr', 300: 'xyz', 400: 'mno'}
