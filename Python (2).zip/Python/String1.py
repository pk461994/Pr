s=input('Enter some string:')
i=0
for x in s:
    print('The character present at positive index:{} and at negative index:{} is:{}'.format(i,i-len(s),x))
    i=i+1
#Logic of Code:-
#Here for +ve index the value will be i which starts from 0 and goes until string ends
#For -ve index the value will be i-len(s). Like length of string is 5 so it will be 0-5=-5 then -4 then -3 and so on
#Then at last we need to print all the values of x in s i.e, string so we have printed it.
#i is for positive index:{}, i-len(s) is for negative index:{} and x is for is:{}
