n=int(input('Enter the nuber of rows:'))
for i in range(1,n+1):      #i represents row number
    for j in range(i):      #j represents the number of stars. Here we can also take range(1,i+1)
        print('*',end='')
    print()
