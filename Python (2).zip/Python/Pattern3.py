n=int(input('Enter the value of n:'))
for i in range(1,n+1):      #No of rows
    for j in range(1,n+2-i): #No of * in each column. Let n=5, i=1, then j value will be 1 to 5+2-1=6 it means it would print n-1, 6-1=5. So, 1 to 5, * * * * *
        print('* ',end=' ')
    print()
