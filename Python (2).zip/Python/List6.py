l=[2,5,6,2,4,78,9,8,11,26,35,55,10]
l.sort()
print(l)
l.sort(reverse=True) #To reverse the natural sorting order
print(l)
