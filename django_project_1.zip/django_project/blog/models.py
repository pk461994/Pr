from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse

class Post(models.Model):
    title=models.CharField(max_length=100)
    content=models.TextField()
    date_posted=models.DateTimeField(default=timezone.now)
    author=models.ForeignKey(User, on_delete=models.CASCADE)  #author will have one to many relationship with posts for this we use ForeignKey. on_delete=models.CASCADE to delete posts if user got deleted

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk}) #Full path is path to post-detail route and It needs a specific post with pk and the value will be self.pk i.e, instance of specific post

'''
The diff between reverse and redirect function is,
Redirect will redirect you to a specific route
But reverse will simply return the full URL to that route as a string.
In this case we want to return URL as string so we use reverse and let the veiw handle redirect for us
'''
