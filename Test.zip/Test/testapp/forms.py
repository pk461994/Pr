from django.forms import ModelForm
from testapp.models import Search

class SearchForm(ModelForm)::
    class Meta:
        fields=['uin']
