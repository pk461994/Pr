from django.contrib import admin
from testapp.models import Search
# Register your models here.
class SearchAdmin(admin.ModelAdmin):
    class Meta:
        fields='__all__'
admin.site.register(Search, SearchAdmin)
