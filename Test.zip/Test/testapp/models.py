from django.db import models

# Create your models here
class Search(models.Model):
    GSTIN=models.CharField(max_length=30)
