from django.shortcuts import render
from testapp.models import Search

# Create your views here.
def create_view(request):
    form=SearchForm()
    if request.method=="POST":
        form=SearchForm(request.POST)
        if form.is_valid():
            form.save()
    return render (request,'testapp/view.html',{'form':form})
