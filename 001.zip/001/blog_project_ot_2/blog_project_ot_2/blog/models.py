from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.core.urlresolvers import reverse

class CustomManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(status='published')
        #Now we have to define objects in our main class Post. So that it will not go to default manager it'll go to CustomManager
        #Whenever we use Post.objects.all(), internally get_queryset() will be called and will return only published Posts. Not Draft posts
        #Model manager is used so that without touching our view function we can customize the data that we'll get

# Create your models here.
class Post(models.Model):
    STATUS_CHOICES=(('draft','Draft'),('published','Published')) #in DB values draft and published will be saved. For end user Draft and Published will be shown
    title=models.CharField(max_length=256)
    slug=models.SlugField(max_length=264,unique_for_date='publish') #Used for SEO purpose to build proper URLs. Slug field will always be unique for a Publish Date. Like 7 posts in one da so slug should not be same for all. Alplabet symbols, underscore symbols, - symbols can be used
    author=models.ForeignKey(User,related_name='blog_posts') #Author refers FK to user model. So we're not allowed to give our value. Value would be chosen from User table options. Dropdown will come and we'll select from there itself. The value of author must be one of Users in default auth app
    body=models.TextField()
    publish=models.DateTimeField(default=timezone.now)  #To select Default time zone
    created=models.DateTimeField(auto_now_add=True) #The first time when POST request created for DB that time automattically will be considered. For First Time
    updated=models.DateTimeField(auto_now=True) #The last and most recent time we call save method to update, that time will be considered. Updated time
    status=models.CharField(max_length=10,choices=STATUS_CHOICES,default='draft') #Define status field. Define choices for status field in tuples of tuples. Default value will be draft if user doen't select anything. STATUS_CHOICES values will come in status field
    objects=CustomManager()

    class Meta:
        ordering=('-publish',)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post_detail',args=[self.publish.year,self.publish.strftime('%m'),self.publish.strftime('%d'),self.slug])

'''
We've used post_detail in urls.py as canonical name. And here we're passing it in get_absolute_url so that it'll generate reverse URL for this post_detail with arguments args
We used get_absolute_url because it'll give us reverse URL. Whereever canonical URL is there By considering below fields
()'post_detail',args=[self.publish.year,self.publish.strftime('%m'),self.publish.strftime('%d'),self.slug])
self means current post object
strftime('%m') will return 2 digits month value
strftime('%d') will give day value
It'll generate name URL for us to make it easy. Here 4 arguements we've passed. For view also 4 arguements are there
In the result URL also we'll get base on these 4 arguements serially
'''
