from django.shortcuts import render
from testapp.models import Company
from django.views.generic import ListView,DetailView,CreateView

# Create your views here.
class CompanyListView(ListView):
    model=Company
    #default template_name is company_list.html
    #defult context_object_name is company_list

class CompanyDetailView(DetailView):
    model=Company
    #default template_name is company_detail.html
    #defult context_object_name is company or object
class CompanyCreateView(CreateView):
    model=Company
    fields=('name','location','ceo')
