from django.shortcuts import render
from django.views.generic import ListView,DetailView,CreateView,UpdateView
from testapp.models import Company

# Create your views here.
class CompanyListView(ListView):
    model=Company
    #default template file:company_list.html
    #default context object:company_list

class CompanyDetailView(DetailView):
    model=Company
    #default template file:company_detail.html
    #default context object:company or object
class CompanyCreateView(CreateView):   #Will take company_form.html as default template
    model=Company
    fields=('name','location','ceo')

class CompanyUpdateView(UpdateView):   #Will take company_form.html as default template
    model=Company
    fields=('name','ceo')

'''
If we want to create, createview Than we have to write a class CompanyCreateView(CreateView):
Fields we've to specify compulsory. Withour specifying fields, creteview won't work
And then in urls.py we've to define->  url(r'^create/', views.CompanyCreateView.as_view(),name='create'),
Defualt template file for insertion is company_form.html. Who is responsible to send this form object?
CreateView internally will be responsible to send the form object. Whichever fields we specified according to those form will come
'''
