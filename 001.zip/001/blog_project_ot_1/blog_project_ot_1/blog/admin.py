from django.contrib import admin
from blog.models import Post

# Register your models here.
class PostAdmin(admin.ModelAdmin):
    list_display=['title','slug','author','body','publish','created','updated','status'] #Fields to be shown in admin page
    list_filter=('status','author','created','publish') #Filter applied to the fields shown in admin page
    search_fields=('title','body') #For Search Box option based on title or body. If matched it'll be displayed.
    raw_id_fields=('author',) #For author to be searched by ID. We can use 1,2,3 or 4 based on that author value will come
    date_hierarchy='publish' #Date field will come on top for better access of data. We can filter by Date, Month and Year
    ordering=['status','publish'] #Ordering based on Status. If status is ordered also then based on publish
    prepopulated_fields={'slug':('title',)} #Populate fields based on some other fields.So it is dictionary. Key is slug and for this key, value will be title. If we type title the same would be considered for the Slug


admin.site.register(Post,PostAdmin)
