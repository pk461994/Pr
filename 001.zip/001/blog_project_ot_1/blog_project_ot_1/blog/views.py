from django.shortcuts import render,get_object_or_404
from blog.models import Post

# Create your views here.
def post_list_view(request):
    post_list=Post.objects.all() #Here we'll get all the posts irrespective of status(=published) or date because we called all(). To restrict to status we need to use model manager
    return render(request,'blog/post_list.html',{'post_list':post_list})

def post_detail_view(request,year,month,day,post): #To get Post based on year,month,day,post
    post=get_object_or_404(Post,slug=post,
                                status='published',
                                publish__year=year,
                                publish__month=month,
                                publish__day=day) #Get Post object wrt request,year,month,day,post. slug=post means slug is name of post.
    return render(request,'blog/post_detail.html',{'post':post}) #Sending post object to post_detail.html to print details

'''
List out all posts that we have so we're using post_list_view(request) method
get_object_or_404 means if object is there return or else give 404
If we want to know details of particular post
We've defined one view function. Then we defined URL. To create the URL, in our models.py we have created get_absolute_url method
After that we're calling that method in post_list.html
When we're calling the method then automatically corresponding URL will be created.
If we click URL in html template automatically view function will be executed.
This view function is going to send POST request to template file. Now the template file i.e, post_list.hml will display info
'''
