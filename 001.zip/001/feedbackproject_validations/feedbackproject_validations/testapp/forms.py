from django import forms
from django.core import validators
def starts_with_d(value):
    if value[0] != 'D':
        raise forms.ValidationError('Name should starts with D')

class FeedbackForm(forms.Form):
    name=forms.CharField(validators=[starts_with_d])
    rollno=forms.IntegerField()
    email=forms.EmailField()
    feedback=forms.CharField(widget=forms.Textarea,validators=[validators.MaxLengthValidator(20)])

    # def clean_name(self):
    #     print('clean_name is executing...')
    #     inputname=self.cleaned_data['name']
    #     if len(inputname)<4:
    #         raise forms.ValidationError('The minimum number of characters in the name should be 4')
    #     return inputname
    # def clean_rollno(self):
    #     inputrollno=self.cleaned_data['rollno']
    #     print('clean_rollno is executing..')
    #     return inputrollno
    # def clean_email(self):
    #     inputemail=self.cleaned_data['email']
    #     print('clean_email is executing..')
    #     return inputemail
    # def clean_feedback(self):
    #     inputfeedback=self.cleaned_data['feedback']
    #     print('clean_feedback is executing..')
    #     return inputfeedback
