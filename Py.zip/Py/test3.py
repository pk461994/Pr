for i in range(4):
    for j in range(4):
        print('i={} and j={}'.format(i,j))
