def double(x):
    return x*2
l=[1,2,3,4,5,6]
l1=list(map(double,l)) #For each element present in l apply double function
print(l1)



#[2, 4, 6, 8, 10, 12]

l2=list(map(lambda x:2*x,l)) #For one time requirement we use lambda function
print(l2)


#[2, 4, 6, 8, 10, 12]


#map function takes double as the arguement and for the sequence l
#map is the name of a higher-order function that applies a given function to each element of a list, returning a list of results in the same order.
#map function is often called apply-to-all when considered in functional form.
