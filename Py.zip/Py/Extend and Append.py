l1=[10,20,30]
l2=[40,50,60]
l1.extend('Durga') # All the elements of Durga will be added seperately. Every character will be treated as an object
print(l1)
l2.append('Durga') #Add string Durga as a single entity
print(l2)
