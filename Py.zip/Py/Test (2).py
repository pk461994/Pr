n=int(input('Enter some number:'))
sum=0
i=1
while i<=n:
    sum=sum+i
    i+=1
print('The sum of first',n,'number is:',sum)
