def f1(*n):                     # f1(*n) var-arg function
    print('var-arg function')
f1()
f1(10)
f1(10,20)
f1(10,20,30)
f1(10,20,30,40)
print(type(f1))

#Output
#var-arg function
#var-arg function
#var-arg function
#var-arg function
#var-arg function
#<class 'function'>

#n means tuple. Internally this is tuple concept.
