#Print Square root from 1 to 10 in a list
l1=[]
for x in range(1,11):           #Using normal For loop
    l1.append(x*x)
print(l1)
l2=[x*x for x in range(1,11)]   #By using Comprehension
print(l2)

#l2=[x*x for x in range(1,11)]
#For each value of x in range 1 to 11
#Value will be taken and will automaically be assigned to x
#Like 1 so x*x=1*1 and so on
#For every x in the given sequence apply the expression
#After applying the expression the result we will get
#With that result we create the List Object
