#To add elements to List upto 100 which are divisible by 10
l=[]
for x in range(101):
#for x in range(0,101,10)       Alternate way. Need not to use if statement also
    if x%10==0:
        l.append(x)
print(l)
