def calculator(firstnumber,secondnumber):
    sum=firstnumber+secondnumber
    sub=firstnumber-secondnumber
    mul=firstnumber*secondnumber
    div=firstnumber/secondnumber
    modulus=firstnumber%secondnumber
    return sum,sub,mul,div,modulus
firstnumber=int(input('Enter the First number:'))
secondnumber=int(input('Enter the Second number:'))
t=calculator(firstnumber,secondnumber)  #These are Positional Arguements
print(type(t))   #<class 'tuple'>
print('The Results are:')
for x in t:
    print(x)
