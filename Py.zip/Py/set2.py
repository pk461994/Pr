w=input('Enter some word:')
s=set(w)
v={'a','e','i','o','u','A','E','I','O','U'}
d=s.intersection(v)
print('The different vowels present in word are:',d)
print('The number of different vowels present in word are:',len(d))

#Output:
#Enter some word:Prashant Jha Aishwarya Sharma
#The different vowels present in word are: {'i', 'a', 'A'}
#The number of different vowels present in word are: 3
 
