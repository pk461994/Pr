l=[10,20,30,40,50,60,70,80,90]
l.pop()
print(l.pop())  #Will remove 90
print(l.pop())  #Will remove 80
print(l)

#pop function will always remove the last element.
#If list is empty and we call pop method. We'll get IndexError: pop from empty list
#pop function can return the removed element just like in output below.

#Output:-
#90
#80
#[10, 20, 30, 40, 50, 60, 70]
