#To find Vowels in some List of Words

vowels=['a','e','i','o','u','A','E','I','O','U']
word=input('Enter some word to search:')
found=[]
for letter in word:                     #Selects and Matches each letter in word
    if letter in vowels:                #If letter not in vowels no action. If letter is in vowels than move further
        if vowels not in found:         #And if vowel is not in found which is empty at beginning
            found.append(letter)        #Append or add that letter in found
print(found)
print("The number of different Vowels present in",word,"is:",len(found))


#Output:-
#Enter some word to search:Aishwarya Sharma Prashant Jha
#['A', 'i', 'a', 'a', 'a', 'a', 'a', 'a', 'a']
#The number of different Vowels present in Aishwarya Sharma Prashant Jha is: 9


#If we only need lowe case letters in words, we need to use
#if letter.lower() in vowels:
#And we need to use letter.lower() in place of letter in further steps

