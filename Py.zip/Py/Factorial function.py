def factorial(n):
    result=1
    while n>=1:
        result=result*n
        n=n-1
    return result
print(factorial(4))
n=int(input('Enter the end result:'))
for i in range(1,n):
    print('The factorial of {} is: {}'.format(i,factorial(i)))



#24
#Enter the end result:5
#The factorial of 1 is: 1
#The factorial of 2 is: 2
#The factorial of 3 is: 6
#The factorial of 4 is: 24
