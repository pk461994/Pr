x=[[10,20,30],[40,50,60],[70,80,90]]
print(x)
print('Elements Row wise:')
for r in x:
    print(r)
print('Elements present in Marix form:')
for i in range(len(x)):
    for j in range(len(x[i])):
        print(x[i][j],end=' ')
    print()


#for i in range(len(x)):
#First len(x) is 3. So 0 to 2. So this loop will be repeated. For i=0, for i=1 and for i=2
#for j in range(len(x[i])):
#Again len(x[i]) is 3. So j will iterate 0, 1 and 2
#So, i=0 and j=o. So print(x[i][j] means x[i][j]=x[0][0]=10
#j will be incremented to 1. So x[0][1]=20
