s=input('Enter some string:')
n=len(s)
i=0
print('Data in forward direction')
while i<n:
    print(s[i],end='')
    i=i+1
print('\nData in backward direction')
i=n-1               #i=-1
while i>=0:         #while i>=-n:
    print(s[i],end='')
    i=i-1
