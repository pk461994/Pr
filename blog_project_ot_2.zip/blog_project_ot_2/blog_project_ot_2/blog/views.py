from django.shortcuts import render,get_object_or_404
from blog.models import Post
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from taggit.models import Tag

# Create your views here.
def post_list_view(request,tag_slug=None):
    post_list=Post.objects.all()
    tag=None
    if tag_slug:
        tag=get_object_or_404(Tag,slug=tag_slug)
        post_list=post_list.filter(tags__in=[tag])

    paginator=Paginator(post_list,2)    #With no of post lists we have to show only 2 posts per page by using pagenator object
    page_number=request.GET.get('page') #In request can we get current page number
    try:
        post_list=paginator.page(page_number)
    except PageNotAnInteger:
        post_list=paginator.page(1)     #If we don't pass any page number it'll show 1st page
    except EmptyPage:
        post_list=paginator.page(paginator.num_pages) # If required page exceeds the total no of pages. It'll show last page
    return render(request,'blog/post_list.html',{'post_list':post_list , 'tag':tag })


from django.views.generic import ListView
from blog.forms import CommentForm
class PostListView(ListView):  #Defining class based view for above FBV post_list_view. It'll search for default template i.e, post_list.html
    model=Post
    paginate_by=1              #It will show only 1 post per page



def post_detail_view(request,year,month,day,post): #Complete detail of Post including comment also
    post=get_object_or_404(Post,slug=post,
                                status='published',
                                publish__year=year,
                                publish__month=month,
                                publish__day=day) #Get Post object wrt request,year,month,day,post. slug=post means slug is name of post. publish_year-year means we're providing year on which post is published to publish_year
    comments=post.comments.filter(active=True)   #To get all active comments. We're using comments from related_name='comments' in models
    comment_submit=False        #Means it is not submitted
    if request.method=='POST':
        form=CommentForm(request.POST)  #With end user provided data pls create a form object
        if form.is_valid():
            new_comment=form.save(commit=False)  #Get new comment but don't save in DB. So we're getting only comments end user submitted
            new_comment.post=post  #post associated with new_comment.post
            new_comment.save()
            comment_submit=True
    else:
        form=CommentForm()  #If it is not POST request pls show form
    return render(request,'blog/post_detail.html',{'post':post,'form':form,'comment_submit':comment_submit,'comments':comments}) #Sending post object to post_detail.html to print details
#comment_submit=False return post_detail.html with post, empty comment form (in else blog) and comment_submit=False



from django.core.mail import send_mail
from blog.forms import EmailSendForm

def mail_send_view(request,id):   #id is the unique ID of the post
    post=get_object_or_404(Post,id=id,status='published') #Get object from Post model. So based on id we're getting post. Like post for id=3
    sent=False #Considering mail has not been sent initially
    if request.method=='POST':  #If we submitted data and click on Send mail button than it is POST request
        form=EmailSendForm(request.POST)    #Create FORM object with POST data using forms.py
        if form.is_valid():                 #Form validations
            cd=form.cleaned_data            #Data will be available in dictionary cd. Getting data and after that send mail
            subject='{}({}) recommends you to read"{}"'.format(cd['name'],cd['email'],post.title)
            post_url=request.build_absolute_uri(post.get_absolute_url())
            message='Read Post At:\n {}\n\n{}\'s Comments:\n{}'.format(post_url,cd['name'],cd['comments'])
            send_mail(subject,message,'durga@blog.com',[cd['to']])
            sent=True #If method is POST then after sending mail set sent=True. Now it'll go to sharebyemail.html and if mail is sent onle sent info will be displayed
    else:
        form=EmailSendForm()  #If it is not POST request create an empty form for GET request and send the form
    return render(request,'blog/sharebymail.html',{'form':form,'post':post,'sent':sent})



'''
List out all posts that we have so we're using post_list_view(request) method
get_object_or_404 means if object is there return or else give 404
If we want to know details of particular post
We've defined one view function. Then we defined URL. To create the URL, in our models.py we have created get_absolute_url method
After that we're calling that method in post_list.html
When we're calling the method then automatically corresponding URL will be created.
If we click URL in html template automatically view function will be executed.
This view function is going to send POST request to template file. Now the template file i.e, post_list.hml will display info


we took sent=False because if it is GET request create an emplty form to user to be filled. If sent=True means for POST data we've sent it successfully



def post_list_view(request,tag_slug=None):
    post_list=Post.objects.all()
    tag=None
    if tag_slug:
        tag=get_object_or_404(Tag,slug=tag_slug)
        post_list=post_list.filter(tags__in=[tag])

Logic- If we're sending request and not clicking tags it'll show the post only bz of post_list=Post.objects.all()
But if you click on tags, tag is not None and we'll also get all posts and tag object related to slug bz of tag=get_object_or_404(Tag,slug=tag_slug)
Now we're filtering post related to the particular tag by post_list=post_list.filter(tags__in=[tag])
Filtered list will be sent to the template file. Now template file will not diaplay all posts it'll only display post related to that particular tag
tags__in=[tag] means for each post tags will be there. If tags related to post is there in [tag] object we're getting that

'''
