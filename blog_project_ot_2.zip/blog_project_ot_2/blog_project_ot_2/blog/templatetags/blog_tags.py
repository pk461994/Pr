from blog.models import POST
from django import template #We want to define our own template so we have to import template
register = template.Library() #Now we have to register our function as a template tag

@register.simple_tag
def total_posts():
    return Post.objects.count()

@register.inclusion_tag('blog/latest_posts123.html')
def show_latest_posts(count=3):
    latest_posts=Post.objects.order_by(-publish)[:count]   #-publish for latest published posts i.e, in ascending order.
    return {'latest_posts':latest_posts}

from django.db.models import Count
@register.assignment_tag
def get_most_commented_posts(count=5):
    return Post.objects.annotate(total_comments=Count('comments')).order_by('-total_comments')[:count]

'''
Use of simple_tag to return number of posts published
We can define our our tag name by @register.simple_tag(name='my_tag'). And we have to use my_tag in template file like {%my_tag%}

inclusion_tag used to Perform some processing and returns a rendered template
latest_posts=Post.objects.order_by(-publish)[:count]
Here we have defined the default arguement as count=3. So default number of posts will be 3. We can change it to required one
If we want to change the value we need to call in template base.html like {% show_latest_posts 4 %}   Now it'll show 4 posts

Usage of assignment_tag to display the most commented posts
In our query, every posts comments are there. We need to count it and assign it to variable total_comments
So we used, annotate(total_comments=Count('comments'))
'''
