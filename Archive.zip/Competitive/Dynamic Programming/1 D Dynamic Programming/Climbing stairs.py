"""
You're climbing a staircase. Takes n steps to reach the top
Each time you can either climb 1 or 2 steps.
How many distinct ways you can climb to the top.
"""