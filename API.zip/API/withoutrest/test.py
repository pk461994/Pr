import requests
BASE_URL='http://127.0.0.1:8000/'
ENDPOINT='apijsoncbv'
resp = requests.post(BASE_URL + ENDPOINT)  #It'll give us GET request like http://127.0.0.1:8000/apijson   So it's concatination only
data = resp.json()   #To get Python Dictionary from Json.   .json() will convert autoatically Json to Dicitonary
print(data)
