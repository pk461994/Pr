from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from django.views.generic import View
from testapp.mixins import HttpResponseMixin
import json

# Create your views here.
def emp_data_view(request):
    emp_data={'eno':100, 'ename':'Prashant', 'esal':1000, 'eaddr': 'US',}
    resp= f"Employee No: {emp_data['eno']}, Employee Name: {emp_data['ename']}, Employee Salary: {emp_data['esal']}, Employee Address: {emp_data['eaddr']}"
    return HttpResponse(resp)

def emp_data_jsonview(request):
    emp_data={'eno':100, 'ename':'Prashant', 'esal':1000, 'eaddr': 'US',}
    json_data=json.dumps(emp_data)
    return HttpResponse(json_data,content_type='application/json')
# Default content type for HttpResponse is HTML so we have to specify content_type='application/json' explacitely for Json type response
# content_type is internally of MIME type (Multipurpose Internet Mail Extension type)

def emp_data_jsonview2(request):
    emp_data={'eno':100, 'ename':'Prashant', 'esal':1000, 'eaddr': 'US',}
    return JsonResponse(emp_data) #Here we need not to convert it to Json bz of we imported JsonResponse. Dict will be coverted automatically to Json



class JsonCBV(HttpResponseMixin, View):
    def get(self,request,*args,**kwargs):
        json_data=json.dumps({'msg':'This is from GET method'})
        #return HttpResponse(json_data,content_type='application/json')
        return self.render_to_http_response(json_data) #self bz we're calling one instance method from another instance method

    def post(self,request,*args,**kwargs):
        json_data=json.dumps({'msg':'This is from POST method'})
        #return HttpResponse(json_data,content_type='application/json')
        return self.render_to_http_response(json_data)

    def put(self,request,*args,**kwargs):
        json_data=json.dumps({'msg':'This is from PUT method'})
        #return HttpResponse(json_data,content_type='application/json')
        return self.render_to_http_response(json_data)

    def delete(self,request,*args,**kwargs):
        json_data=json.dumps({'msg':'This is from DELETE method'})
        #return HttpResponse(json_data,content_type='application/json')
        return self.render_to_http_response(json_data)
