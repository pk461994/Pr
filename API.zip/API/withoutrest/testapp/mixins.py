from django.http import HttpResponse

class HttpResponseMixin(object):   #Independent class which will not extend any other class. We can take it as class HttpResponseMixin:
    def render_to_http_response(self,json_data):
        return HttpResponse(json_data, content_type='application/json')

'''
Mixins are the Independent class. We can define instance methods within this class.
Wherever functionality related to this class is required we'll make this Mixin class as Parent class in other classes
Just like we did in views.py i.e,  class JsonCBV(HttpResponseMixin, View):
Now Mixin class functionality will be available to JsonCBV class as it extends HttpResponseMixin which is Mixin class

Mixin is direct child class of object class. It doesn't contain any instance variable but only contains instance methods which are helpful for child classes
So we don't create objects for calling Mixin classes bz it doesn't contain any instance variable
'''
