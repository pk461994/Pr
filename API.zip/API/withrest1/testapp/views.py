from django.shortcuts import render
from testapp.models import Employee
from django.views.generic import View
import io
from rest_framework.parsers import JSONParsers
from testapp.serializers import EmployeeSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

# Create your views here.
@method_decorator(csrf_exempt,name='dispatch')
class EmployeeCRUDCBV(View):
    def get(self,request,*args,**kwargs):
        json_data=request.body
        stream=io.BytesIO(json_data)    #Converting json_data into Bytes types from json
        pdata=JSONParser().parse(stream)  #Now it in Python dict form
        id=pdata.get('id',None)  #If id is there from Partner app than return id and if not return None
        if id is not None:
            emp=Employee.objects.get(id=id)
            serializer=EmployeeSerializer(emp)
            json_data=JSONRenderer().render(serializer.data)
            return HttpResponse(json_data,content_type='application/json')
        qs=Employee.objects.all()
        serializer=EmployeeSerializer(qs,many=True)
        json_data=JSONRenderer().render(serializer.data)
        return HttpResponse(json_data,content_type='application/json')

    def post(self,request,*args,**kwargs):
        json_data=request.body
        stream=io.BytesIO(json_data)        #Convert json to python data
        ptata=JSONParser().parse(stream)    #Here its converting json to Python dict
        serializer=EmployeeSerializer(data=pdata)
        if serializer.is_valid():
            serializer.save()   #Whenever we call serializer.save() internally it'll call create method in serializers.py
            msg={'message':'Resource created Successfully'}
            json_data=JSONRenderer().render(msg)
            return HttpResponse(json_data,content_type='application/json')
        json_data=JSONRenderer().render(serializer.errors)
        return HttpResponse(json_data,content_type='application/json',status=400)

    def put(self,request,*args,**kwargs):
        json_data=request.body
        stream=io.BytesIO(json_data)
        pdata=JSONParser().parse(stream)
        id=pdata.get('id')      #Getting the id of instance that we need to update
        emp=Employee.objects.get(id=id) #Getting the emp object with id provided
        serializer=EmployeeSerializer(emp,data=pdata,partial=True) #Creating serializer object and update emp with pdata. We've to take partial=True if we want to update record partially
        if serializer.is_valid():   #Whenever we call serializer.is_valid internally it will call validate_esal
            serializer.save()
            msg={'message':'Resource updated Successfully'}
            json_data=JSONRenderer().render(msg)   #Convert message in json data
            return HttpResponse(json_data,content_type='application/json')
        json_data=JSONRenderer().render(serializer.errors)
        return HttpResponse(json_data,content_type='application/json',status=400)

    def delete(self,request):
        json_data=request.body
        stream=io.BytesIO(json_data)
        pdata=JSONParser().parse(stream)  #Now data is in Python dictionary from json
        id=pdata.get('id')
        emp.delete()
        msg={'message':'Resource deleted successfully'}
        json_data=JSONRenderer().render(msg)
        return HttpResponse(json_data,content_type='application/json')

#We use serializer for get, post and put only. Serializer is not needed for delete operation
