from rest_framework import serializers
from testapp.models import Employee

def multiples_of_1000(value):
    print('Validation by validator attribute')
    if value%1000!=0:
        raise serializers.ValidationError('Employee Salary should be multiples of 1000')

class EmployeeSerializer(serializers.Serializer):
    eno=serializers.IntegerField()
    ename=serializers.CharField()
    esal=serializers.FloatField(validators=[multiples_of_1000])
    eaddr=serializers.CharField()
    def validate_esal(self,value):
        print('Field level validation')
        if value<50000:
            raise serializers.ValidationError('Employee salary should be minimum 50000$')
        return value

    def validate(self,data):
        print('Object level validation')
        ename=data.get('ename')
        esal=data.get('esal')
        if ename.lower()=='sunny':
            if esal<50000:
                raise serializers.ValidationError('Sunny salary should be minimum 50000')
        return data

    def create(self,validated_data):    #validated_data contains key-value pairs. With all key-value pairs we're creating Employee record
        return Employee.objects.create(**validated_data)

    def update(self,instance,validated_data):  #To update the instance(current existing object present inside DB) with validated_data(partner app provided data)
        instance.eno=validated_data.get('eno',instance.eno)  #In validated_data if any field is there with eno, take that field and assign to existing object eno. If no eno provided take default eno
        instance.ename=validated_data.get('ename',instance.ename)
        instance.esal=validated_data.get('esal',instance.esal)
        instance.eaddr=validated_data.get('eaddr',instance.eaddr)
        instance.save()
        return instance
#If we want to perform update operation we've to override this instance
