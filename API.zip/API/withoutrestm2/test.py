import requests
import json
BASE_URL='http://127.0.0.1:8000'
ENDPOINT='api'

def get_resource(id=None):
    data={}                 #If we aren't passing any ID than id=None by default. So, empty dictionary will be sent
    if id is not None:
        data={'id':id}
    resp=requests.get(BASE_URL+ENDPOINT,data=json.dumps(data))
    print(resp.status_code)
    print(resp.json())      #.json() to convert in Python dict
get_resource()

def create_resource():
    new_std={'name':'Chandan','rollno':101,'marks':100,'gf':'bhabhiji','bf':'xxx'}
    r = requests.post(BASE_URL+ENDPOINT,data=json.dumps(new_std))
    print(r.status_code)
    print(r.json())
create_resource()

def update_resource():
    new_data={'id':id,'gf'='Pinkish'}
    r=requests.put(BASE_URL+ENDPOINT,data=json.dumps(new_data))
    print(r.status_code)
    print(r.json())
update_resource(1)

def delete_resource(id):
    data={'id':id}
    r=requests.delete(BASE_URL+ENDPOINT,data=json.dumps(data))
    print(r.status_code)
    print(r.json())
delete_resource(5)
