import requests
import json
BASE_URL='http://127.0.0.1:8000/'
ENDPOINT='api/'

# def get_resource(id=None):   #I we put ID we'll get record related to that ID if no ID means all records
#     data={}                #Initially data is empty if we pass id than it should contain id
#     if id is not None:
#         data = {'id':id}
#     resp=requests.get(BASE_URL+ENDPOINT,data=json.dumps(data))
#     print(resp.status_code) #For the Status Code
#     print(resp.json()) # To return Json data in form of a dictionary
# get_resource(3)
# #id=input("Enter some ID: ")
# #get_resource(id)
#
# def get_all():
#     resp=requests.get(BASE_URL+ENDPOINT)
#     print(resp.status_code)
#     print(resp.json())
# #get_all()
#
# def create_resource():
#     new_emp={'eno':500,'ename':'Kim','esal':999999,'eaddr':'Canada'}
#     resp=requests.post(BASE_URL+ENDPOINT, data=json.dumps(new_emp)) #data=json.dumps(new_emp)) to send our new data to django app after converting to json format
#     print(resp.status_code)
#     print(resp.json()) #Prinitng response. .json() will print data in form of dictionary after converting resp which is in json to dict
# #create_resource()
#
# def update_resource(id):
#     new_emp={'id':id,'esal':1000000,'eaddr':'Delhi'}
#     resp=requests.put(BASE_URL+ENDPOINT, data=json.dumps(new_emp)) #data=json.dumps(new_emp)) to send our new data to django app after converting to json format
#     print(resp.status_code)
#     print(resp.json())
# update_resource(7)
#
def delete_resource(id):
    data={'id':id}
    resp=requests.delete(BASE_URL+ENDPOINT, data=json.dumps(data))
    print(resp.status_code)
    print(resp.json())
delete_resource(7)

'''
As we've mentioned ENDPOINT='api/'  and if we see urls.py     re_path(r'^api/$', views.EmployeeListCBV.as_view()),
So we have to write functionality inside EmployeeListCBV
'''
