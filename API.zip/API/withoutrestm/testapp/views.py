from django.shortcuts import render
from django.views.generic import View
from testapp.models import Employee
import json
from django.http import HttpResponse
from django.core.serializers import serialize
from testapp.mixins import SerializeMixin,HttpResponseMixin
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from testapp.utils import is_json
from testapp.forms import EmployeeForm
# Create your views here.

@method_decorator(csrf_exempt,name='dispatch')
class EmployeeDetailCBV(HttpResponseMixin,SerializeMixin,View):
    def get_object_by_id(self,id):
        try:
            emp = Employee.objects.get(id=id) #To get emp object based on Employee ID
        except Employee.DoesNotExist:         #In the model itself DoesNotExist is defined internally we only need to call it
            emp = None
        return emp

    def get(self,request,id,*args,**kwargs):        #To get record by id
        try:
            emp=Employee.objects.get(id=id) #To make id as user input not hard coding it
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg': 'The requested resource is not available'})
            return HttpResponse(json_data , content_type='application/json' , status=404)
        else:
            json_data = self.serialize([emp,])
            return HttpResponse(json_data , content_type='application/json') #Default content type for HttpResponse is HTML so we have to specify content_type='application/json' explacitely for Json type response

    def put(self,request,id,*args,**kwargs):  #To perform updation task
        emp=self.get_object_by_id(id)  #Calling get_object_by_id method
        if emp is None:
            json_data = json.dumps({'msg': 'No Matched Resource found. Not possible to perform Updation'})
            return HttpResponse(json_data, content_type='application/json', status=404)
        data=request.body  #If emp is not None we're getting data by .body
        if not is_json:
            json_data = json.dumps({'message':'Please send valid Json data only'})
            return self.render_to_http_response(json_data,status=400)
        provided_data=json.loads(data)  #Converting valid Json data to dict
        original_data = {'eno':emp.eno,'ename':emp.ename,'esal':emp.esal,'eaddr':emp.eaddr} #Converting emp object we're converting to Python dictionary form
        original_data.update(provided_data) #Adding provided_data to dict original_data by using update() function
        form=EmployeeForm(original_data,instance=emp) #We're updating data so we've to take instance=emp so that updation will happer to existing Employee object i.e, emp. If we don't take like this a new object will be created with the data
        if form.is_valid():
            form.save(commit=True)
            json_data=json.dumps({'message':'Resource Updated Successfully'})
            return self.render_to_http_response(json_data)
        if form.errors:
            json_data=json.dumps(form.errors)
            return self.render_to_http_response(json_data,status=400)

    def delete(self,request,id,*args,**kwargs):
        emp=self.get_object_by_id(id)
        if emp is None:
            json_data=json.dumps({'message':'No Matched Resource found. Not possible to perform Deletion'})
            return self.render_to_http_response(json_data,status=404)
        status,deleted_item=emp.delete() #If we print Return type of delete() it'll be Tuple. We're unpacking tuple. So t is tuple. It contains 2 values. 1st is status and 2nd is deleted item
        if status == 1:
            json_data = json.dumps({'message': 'Resource deleted Successfully'})
            return self.render_to_http_response(json_data)
        json_data = json.dumps({'message': 'Unable to Delete record. Please try again'})
        return self.render_to_http_response(json_data)



@method_decorator(csrf_exempt,name='dispatch') #To disable csrf for post request.name='dispatch' will make it disabled for all http requests
class EmployeeListCBV(HttpResponseMixin,SerializeMixin,View):
    def get(self,*args,**kwargs):       #To get all records
        qs=Employee.objects.all()
        json_data = self.serialize(qs)  # self.serialize means SerializeMixin. So it'll call serialize function which takes qs as arguement and will return json_data
        return HttpResponse(json_data , content_type='application/json')

    def post(self,request,*args,**kwargs):  #To create a resource
        data=request.body #test.py is sending some data. That json data if we want to access inside Post we need to call .body
        #valid_json= is_json(data)
        if not is_json:
            json_data = json.dumps({'message':'Please send valid Json data only'})
            return self.render_to_http_response(json_data,status=400)
        empdata=json.loads(data) #We're getting partner app i.e, test.py provided data in dictionary
        form=EmployeeForm(empdata)
        if form.is_valid():
            form.save(commit=True)
            json_data = json.dumps({'message':'Resource created successfully'})
            return self.render_to_http_response(json_data)
        if form.errors:
            json_data = json.dumps(form.errors) #form.errors is a dictionary by default
            return self.render_to_http_response(json_data,status=400)

'''
As we're extending SerializeMixin and HttpResponseMixin class present in mixins.py so its method will be available for the child classes
'''
