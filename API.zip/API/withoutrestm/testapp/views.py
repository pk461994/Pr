from django.shortcuts import render
from django.views.generic import View
from testapp.models import Employee
import json
from django.http import HttpResponse
from django.core.serializers import serialize
from testapp.mixins import SerializeMixin,HttpResponseMixin
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from testapp.utils import is_json
from testapp.forms import EmployeeForm
# Create your views here.

class EmployeeDetailCBV(HttpResponseMixin,SerializeMixin,View):
    def get(self,request,id,*args,**kwargs):
        try:
            emp=Employee.objects.get(id=id) #To make id as user input not hard coding it
        except Employee.DoesNotExist:
            json_data = json.dumps({'msg': 'The requested resource is not available'})
            return HttpResponse(json_data , content_type='application/json' , status=404)
        else:
            json_data = self.serialize([emp,])
            return HttpResponse(json_data , content_type='application/json') #Default content type for HttpResponse is HTML so we have to specify content_type='application/json' explacitely for Json type response

@method_decorator(csrf_exempt,name='dispatch') #To disable csrf for post request.name='dispatch' will make it disabled for all http requests
class EmployeeListCBV(HttpResponseMixin,SerializeMixin,View):
    def get(self,*args,**kwargs):
        qs=Employee.objects.all()
        json_data = self.serialize(qs)  # self.serialize means SerializeMixin. So it'll call serialize function which takes qs as arguement and will return json_data
        return HttpResponse(json_data , content_type='application/json')

    def post(self,request,*args,**kwargs):
        data=request.body #test.py is sending some data. That json data if we want to access inside Post we need to call .body
        #valid_json= is_json(data)
        if not is_json:
            json_data = json.dumps({'message':'Please send valid Json data only'})
            return self.render_to_http_response(json_data,status=400)
        empdata=json.loads(data) #We're getting partner app i.e, test.py provided data in dictionary
        form=EmployeeForm(empdata)
        if form.is_valid():
            form.save(commit=True)
            json_data = json.dumps({'message':'Resource created successfully'})
            return self.render_to_http_response(json_data)
        if form.errors:
            json_data = json.dumps(form.errors) #form.errors is a dictionary by default
            return self.render_to_http_response(json_data,status=400)

'''
As we're extending SerializeMixin and HttpResponseMixin class present in mixins.py so its method will be available for the child classes
'''
