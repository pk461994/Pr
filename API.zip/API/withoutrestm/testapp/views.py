from django.shortcuts import render
from django.views.generic import View
from testapp.models import Employee
import json
from django.http import HttpResponse
from django.core.serializers import serialize
from testapp.mixins import SerializeMixin,HttpResponseMixin
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from testapp.utils import is_json
from testapp.forms import EmployeeForm
# Create your views here.

@method_decorator(csrf_exempt,name='dispatch')
class EmployeeCRUDCBV(View,SerializeMixin,HttpResponseMixin):
    def get_object_by_id(self,id):
        try:
            emp=Employee.objects.get(id=id)
        except Employee.DoesNotExist:
            emp=None
        return emp

    def get(self,request,*args,**kwargs):
        data=request.body
        valid_json=is_json(data)
        if not valid_json:
            json_data=json.dumps({'message':'This is not a valid json data'})
            return self.render_to_http_response(json_data,status=404)
        pdata=json.loads(data)   #We're passing client provided data. If it is valid json data we're converting it to dictionary
        id=pdata.get('id',None)  #If id is there in data we'll get the id if not available simply return None
        if id is not None:
            emp=self.get_object_by_id(id) #If id is not None we're calling get_object_by_id function to return record of the gived id
            if emp is None:                #Suppose we gave 100 as ID and it's not available
                json_data = json.dumps({'msg': 'The requested resource is not available with matched ID'})
                return HttpResponse(json_data , content_type='application/json' , status=404)
            json_data = self.serialize([emp,])   #We're sending Employee object in list form so that it'll become list of objects which is qs. Initially emp is single object we need to pass it as list
            return self.render_to_http_response(json_data)
        qs = Employee.objects.all()  #If id is None means caller didn't pass any ID we need to give him all datas
        json_data=self.serialize(qs)
        return self.render_to_http_response(json_data)

    def post(self,request,*args,**args):
        data=request.body
        valid_json=is_json(data)
        if not valid_json:
            json_data=json.dumps({'message':'Please send valid json data only'})
            return self.render_to_http_response(json_data,status=400)
        emp_data=json.loads(data)
        form=EmployeeForm(emp_data)
        if form.is_valid():
            form.save(commit=True)
            json_data=json.dumps({'message':''})
            return self.render_to_http_response(json_data)
        if forms.errors:
            json_data=json.dumps(form.errors)
            return self.render_to_http_response(json_data,status=400)

    def put(self,request,*args,**args):
        data=request.body
        valid_json=is_json(data)
        if not valid_json:
            json_data=json.dumps({'message':'Please send valid json data only'})
            return self.render_to_http_response(json_data,status=404)
        pdata=json.loads(data)
        id=pdata.get('id',None)  #To get the ID of employee for whom we want to perform updation. If id is there return id if not return None
        if id is None:
            json_data=json.dumps({'message':'To mperform updation ID is mandatory. Please provide ID'})
            return self.render_to_http_response(json_data,status=400)
        emp=self.get_object_by_id(id)
        if emp is None:
            json_data=json.dumps({'message':'No Resource found with matched ID'})
            return self.render_to_http_response(json_data,status=404)
        provided_data=json.loads(data)
        original_data={'eno':emp.eno,'ename':emp.ename,'esal':emp.esal,'eaddr':emp.eaddr}
        original_data.update(provided_data)
        form=EmployeeForm(original_data,instance=emp)
        if form.is_valid():
            form.save(commit=True)
            json_data=data.dumps({'message':'Resource Updated Successfully'})
            return self.render_to_http_response(json_data)
        if form.errors:  #If any error comes it'll be stored in errors. We can ignore this if also
            json_data=json.dumps(form.errors)
            return self.render_to_http_response(json_data,status=400)

    def delete(self,request,*args,**kwargs):
        data=request.body
        valid_json=is_json(data)
        if not valid_json:
            json_data=json.dumps({'message':'Please provide valid Json data only'})
            return self.render_to_http_response(json_data,status=400)
        pdata=json.loads(data)
        id=pdata.get('id',None)
        if id is not None:
            emp=self.get_object_by_id(id)
            if emp is None:
                json_data=json.dumps({'message':'The requested resource is not available with given ID'})
                return self.render_to_http_response(json_data)
            status,deleted_item= emp.delete()   #delete() will give 2 things. 1 is status and other is deleted_item. Suppose if we're deleting and DB is down so deletion will not happen
            if status == 1:                     #status=1 means deleted Successfully
                json_data=json.dumps({'message':'Resource deleted successfully'})
                return self.render_to_http_response(josn_data)
            json_data=json.dumps({'message':'Resource cannot be deleted. Please try again'})
            return self.render_to_http_response(josn_data)
        json_data=json.dumps({'message':'To perform deletion ID is mandatory. Please provide correct ID'})
        return self.render_to_http_response(json_data,status=400)





# @method_decorator(csrf_exempt,name='dispatch')
# class EmployeeDetailCBV(HttpResponseMixin,SerializeMixin,View):
#     def get_object_by_id(self,id):
#         try:
#             emp = Employee.objects.get(id=id) #To get emp object based on Employee ID
#         except Employee.DoesNotExist:         #In the model itself DoesNotExist is defined internally we only need to call it
#             emp = None
#         return emp
#
#     def get(self,request,id,*args,**kwargs):        #To get record by id
#         try:
#             emp=Employee.objects.get(id=id) #To make id as user input not hard coding it
#         except Employee.DoesNotExist:
#             json_data = json.dumps({'msg': 'The requested resource is not available'})
#             return HttpResponse(json_data , content_type='application/json' , status=404)
#         else:
#             json_data = self.serialize([emp,])
#             return HttpResponse(json_data , content_type='application/json') #Default content type for HttpResponse is HTML so we have to specify content_type='application/json' explacitely for Json type response
#
#     def put(self,request,id,*args,**kwargs):  #To perform updation task
#         emp=self.get_object_by_id(id)  #Calling get_object_by_id method
#         if emp is None:
#             json_data = json.dumps({'msg': 'No Matched Resource found. Not possible to perform Updation'})
#             return HttpResponse(json_data, content_type='application/json', status=404)
#         data=request.body  #If emp is not None we're getting data by .body
#         if not is_json:
#             json_data = json.dumps({'message':'Please send valid Json data only'})
#             return self.render_to_http_response(json_data,status=400)
#         provided_data=json.loads(data)  #Converting valid Json data to dict
#         original_data = {'eno':emp.eno,'ename':emp.ename,'esal':emp.esal,'eaddr':emp.eaddr} #Converting emp object we're converting to Python dictionary form
#         original_data.update(provided_data) #Adding provided_data to dict original_data by using update() function
#         form=EmployeeForm(original_data,instance=emp) #We're updating data so we've to take instance=emp so that updation will happer to existing Employee object i.e, emp. If we don't take like this a new object will be created with the data
#         if form.is_valid():
#             form.save(commit=True)
#             json_data=json.dumps({'message':'Resource Updated Successfully'})
#             return self.render_to_http_response(json_data)
#         if form.errors:
#             json_data=json.dumps(form.errors)
#             return self.render_to_http_response(json_data,status=400)
#
#     def delete(self,request,id,*args,**kwargs):
#         emp=self.get_object_by_id(id)
#         if emp is None:
#             json_data=json.dumps({'message':'No Matched Resource found. Not possible to perform Deletion'})
#             return self.render_to_http_response(json_data,status=404)
#         status,deleted_item=emp.delete() #If we print Return type of delete() it'll be Tuple. We're unpacking tuple. So t is tuple. It contains 2 values. 1st is status and 2nd is deleted item
#         if status == 1:
#             json_data = json.dumps({'message': 'Resource deleted Successfully'})
#             return self.render_to_http_response(json_data)
#         json_data = json.dumps({'message': 'Unable to Delete record. Please try again'})
#         return self.render_to_http_response(json_data)



# @method_decorator(csrf_exempt,name='dispatch') #To disable csrf for post request.name='dispatch' will make it disabled for all http requests
# class EmployeeListCBV(HttpResponseMixin,SerializeMixin,View):
#     def get(self,*args,**kwargs):       #To get all records
#         qs=Employee.objects.all()
#         json_data = self.serialize(qs)  # self.serialize means SerializeMixin. So it'll call serialize function which takes qs as arguement and will return json_data
#         return HttpResponse(json_data , content_type='application/json')
#
#     def post(self,request,*args,**kwargs):  #To create a resource
#         data=request.body #test.py is sending some data. That json data if we want to access inside Post we need to call .body
#         #valid_json= is_json(data)
#         if not is_json:
#             json_data = json.dumps({'message':'Please send valid Json data only'})
#             return self.render_to_http_response(json_data,status=400)
#         empdata=json.loads(data) #We're getting partner app i.e, test.py provided data in dictionary
#         form=EmployeeForm(empdata)
#         if form.is_valid():
#             form.save(commit=True)
#             json_data = json.dumps({'message':'Resource created successfully'})
#             return self.render_to_http_response(json_data)
#         if form.errors:
#             json_data = json.dumps(form.errors) #form.errors is a dictionary by default
#             return self.render_to_http_response(json_data,status=400)

'''
As we're extending SerializeMixin and HttpResponseMixin class present in mixins.py so its method will be available for the child classes
'''
