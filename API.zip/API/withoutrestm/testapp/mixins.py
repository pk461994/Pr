#To render HttpResponse and to Serialize

from django.core.serializers import serialize
import json
from django.http import HttpResponse

#If Employee exists that Employee infor we've to provide to partner app. So we have to convert it in json. So for that we're defining SerializeMixin
class SerializeMixin(object):
    def serialize(self,qs):             #qs is queryset which is list of objects
        json_data= serialize('json',qs) #serialize will always take qs and return json_data. Converting qs into json
        p_data = json.loads(json_data)  #Converting Json data to dictionary
        final_list=[]
        for items in p_data:
            emp_data = items['fields'] #Choosing only fields section which will give dictionary of data. Avoiding unnecessary infos like ID
            final_list.append(emp_data)
        json_data = json.dumps(final_list) #Converting Dictionary data to Json format
        return json_data

class HttpResponseMixin(object):
    def render_to_http_response(self,json_data,status=200):     #We've to call this function by passign json_data
        return HttpResponse(json_data,content_type='application/json',status=status)
#If we don't write status instead of status=status than it'll throw error SyntaxError: positional argument follows keyword argument
