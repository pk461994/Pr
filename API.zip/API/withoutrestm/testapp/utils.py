import json
def is_json(data):
    try:
        p_data=json.loads(data)
        valid=True  #Just to check whether it is Json data or not. If yes data will be loaded to p_data after getting converted to json format
    except ValueError:
        valid=False
