from django.db import models
from django.core.urlresolvers import reverse
# Create your models here.
class Company(models.Model):
    name=models.CharField(max_length=128)
    location=models.CharField(max_length=64)
    ceo=models.CharField(max_length=64)
    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('detail',kwargs={'pk':self.pk})

class Employee(models.Model):
    eno=models.IntegerField()
    name=models.CharField(max_length=64)
    salary=models.FloatField()
    company=models.ForeignKey(Company,related_name='employees')

'''
Logic of get_absolute_url(self) method. CompanyCreateView internally calls this method
After inserting data in DB, if we want Target Page automatically, get_absolute_url(self) we have to specify
If we want to redirect to home no need to pass any arguement like kwargs={'pk':self.pk}
After inserting data please go to detail with arguement current object pk
pk is used and then corresponding function, views.CompanyCreateView.as_view() will be called. This is reverse URL concept
pk means name of arguement which in this case is Primary Key. self.pk means current object's primary key passed as value
pk is fixed. We've used pk in urls.py. For every object internally, pk will be maintained as it is implicitely available
After inserting data it will call implicitely get_absolute_url method to display next target page. So we have to define this method of target page
On the model object it is going to be called. The object we inserted on that object get_absolute_url will be called
'''
