s=input('Enter string: ')
output=''
for items in s:
    if items.isalpha():
        output=output+items
        previous=items
    else:
        output=output+chr(ord(previous)+int(items))
print(output)