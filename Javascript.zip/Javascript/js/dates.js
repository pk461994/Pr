{
    // January start from 00 and goes till december i.e, 11. 12 means next year's January and so on
    let myDate = new Date()
    console.log(myDate)

    let myDate1 = new Date(2020, 12)
    console.log(myDate1)

    let myDate2 = new Date(0)
    console.log(myDate2)

    let myDate3 = new Date()
    let time = Date.now()
    console.log(time)       // Time in milliseconds


    let start = Date.now()
    let x = 0
    for(let i=0 ; i<10000000000 ; i++){
        x += i
    }
    let end = Date.now()
    let total = end - start
    console.log('Time took ' + total)
    console.log(x)

    //Get Days in days ratger than milliseconds
    let before = new Date(2020, 10, 15)
    let after = new Date(2020, 10, 20)
    let oneDay = 1000 * 60 * 60 * 24
    let days = (after - before) / oneDay
    console.log('Total no of days: ' + days)
}