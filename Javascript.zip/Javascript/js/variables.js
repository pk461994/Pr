// var username = prompt('Enter your name:');
// console.log(username);

(function(){
    // IIFE- Immediately invoked function expression
    var age = 5 //If we don't put var and simply age = 5 than it will be the property of window object which is global
})();
let y1 = 50; // Will not be attached to window object. We can see by using window.y1 in conswole
var x1 = 10; // Will be accessible globally as declared outside functon and attached to window object. We can see by using window.x1 in console

{
    let p = 10;
    const q = 20;
    {
        let p = 111;
        console.log(p)
    }
    console.log(y1, x1)
}

// Two basic types of variable. Primitives and Objects