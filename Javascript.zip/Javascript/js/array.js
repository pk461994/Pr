{
    
    // let stuff = [12, {'sex':'Male'}, 'prashant', function(){console.log('Coding')}, [1,2,3]]
    // console.log(stuff)
    // console.log(stuff[3]()) //Index and than calling by () The reason we got undefined is bz we're calling the function inside of console.log so its console.log of return and the function is not returning anything so undefined
    // stuff[3]()

    // let grades = []
    // grades[0] = 12
    // grades[1] = 22
    // grades[2] = 32
    // console.log(grades)
    // grades.length = 3000  // We can change the length property of an array in JS. The length of grades is 3 now increasing it to 3000
    
    // grades[3570] = 99
    // console.log(grades.length)

    // for (i=0 ; i<grades.length ; i++){
    //     console.log(grades[i])
    // }

    // let new_grades = [1,2,3,34,45,7]
    // console.log(new_grades)
    // new_grades.length = 3       // Cut the length of new_grades to 3
    // console.log(new_grades)

    // To ignore the undefined due to changing of the length of the array

    // let sample = [1,2,3,4,56,6,7,7,8,8,56]
    // sample.length = 200
    // sample[311] = 99

    // for (let i=0 ; i<sample.length ; i++){
    //     if (sample[i] !== undefined){
    //         console.log(sample[i])
    //     }
    // }


    // // Search element in array
    // let a = [5,2,4,35,4,6,76,3,2,3,4,2,1,1,76,7,76]
    // let found = false
    // let search = 76

    // for(let i=0 ; i<a.length ; i++){
    //     if(a[i] === search){
    //         found = true
    //         console.log(a[i] + ' found at index ' + i)
    //     }
    // }
    // if (found){
    //     //Do domethind
    // }

    /*
    // Find largest number in array
    const sample_num = [1,2,4,56,6,4,3,5,6,7,7643,334,4,5432,2,12]
    let largest_num = sample_num[0]
    let largest_index = 0
    for (let i=0 ; i<sample_num.length ; i++){
        if(sample_num[i] > largest_num){
            // Replace it with largest number
            largest_num = sample_num[i]
            largest_index = i
        }
    }
    console.log(largest_num)
    console.log(largest_index)

    // Function to find index of largest number in array
    function indexOfMax(sample_num) {
        if (sample_num.length === 0) {
            return -1;
        }
        var max = sample_num[0];
        var maxIndex = 0;
        for (var i = 1; i < sample_num.length; i++) 
        {
            if (sample_num[i] > max) 
            {
                maxIndex = i;
                max = sample_num[i];
            }
        }
        return maxIndex;
    }
    console.log('Largest number found at: '+indexOfMax(sample_num))
    */

    //Calculating average in array
    // let a = [1,2,3,4,5,6,7,8,9,10]
    // let count = 0
    // let total = 0
    // for (let i=0 ; i<a.length ; i++){
    //     if(a[i] !== undefined){
    //         count += 1
    //         total += a[i]
    //     }
    // }
    // let avg = total / count
    // console.log(avg)

    // Fill Array from User Input Indefinite Loop and Sentinel Value
    // let grades = []
    // while(true){
    //     let input = prompt('Add a grade')
    //     if (input === 'q' || input === null){
    //         break;
    //     }
    //     grades.push(Number(input))
    //     console.log(grades)
    // }

    //Sort an array using callback function
    // grades = [1,2,3,4,5,56,4,6,56,5,7,676,6,786,87,8,7,9,8,9,78,8,76,7,5,6]
    // console.log(grades.sort( function ( a, b ) { return a - b } ))
    // console.log('Reverse sorting: '+grades.reverse())
    // console.log('Filling the array with desired value ' + grades.fill(-1, 0, grades.length))


    // Concatination of arrays
    // gradesA = [1,2,3]
    // gradesB = [4,5,6]
    // let tacos = gradesA.concat(gradesB)
    // console.log(tacos)
    // console.log(tacos.indexOf(5))       //Index of element present in array
    // console.log(gradesB.includes(5))
    // console.log(gradesA.includes(5))


    /*
    let grades = [12,34,56,54,34,56,77,13]
    //Normal for loop
    for(let i=0 ; i<grades.length ; i++){       //We need to check for undefined and we need to access values using index
        if(grades[i] !== undefined) console.log(grades[i])
    }

    // forEach loop using callback function. Callback function is when we pass a function as an argument to forEach.
    // forEach function will call the inner function
    grades.forEach(function(element) {          //forEach is only going to check for values which are NOT undefined. No need to check each values using index(in normal for loop), we can access using element
        console.log(element)
    })

    // passing index and array(the array we're working with) in forEach loop in above same example
    grades.forEach(function(item , i, array) {
        console.log(item + ' Present at ' + i + ' and the array we are working with is: ' + array)
    })
    */


    /*
    // Working with nested array using normal for loop
    let grades = [
        [12,34,54,55,34,56,77,14],
        [19,34,71,57,39,59,76,13],
        [00,34,56,68,34,50,14,18]
    ]
    for (let i=0 ; i<grades.length; i++){           // get elements from grades which is in list so 3 lists
        for(let k=0 ; k<grades[i].length ; k++){    // get elements of all 3 lists that we got from outer for loop
            console.log(grades[i][k])
        }
        console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~')
    }
    
    // Using forEach loop and callback function. No need to check for undefined values
    grades.forEach(function(row){           // by row(row is array itself) we got all 3 arrays in grades array
        //console.log(row)
        row.forEach(function(col){          // by col(col is array itself) we got each element present in all three arrays
            console.log(col)
        })
        console.log('~~~~~~~~~~~~~~~~~~~~~')
    })
    */

   // Labels
   let grades = [
    [12,34,54],
    [76,13,11,23, 22,29,7,8],
    [00,34,1,2,3,4,5]
   ]
   // Providing label to for loop i.e, outerLoop(can be any name)
   outerLoop: for (let i=0 ; i<grades.length; i++){
        for(let k=0 ; k<grades[i].length ; k++){
            console.log(grades[i][k])
            if(grades[i][k] === 76){
                console.log('You found the value')
                // break                // ignore the elements in a particular nested array after the value we provide like 76
                // continue
                // break  outerLoop     // break out the outer loop. Stops searching all thogether after finding req element
                continue outerLoop      // Same like using break without lables. Continue with next iteration of outer loop(moving to next array ignoring all next elements in current array) than continuing with the inner loop
            }
            console.log('Doing Stuff')
        }
        console.log('~~~~~~~~~~~~~') // This code is ignored with continue outerLoop
        //This code is not ignored with a break
    }
}