{
    // while
    // do-while
    // for loop

    // initialization
    // condition
    // update

    /*
    let i = 10000;  // initialization
    do {
        console.log(i);
        i++;    // update
    } while(i < 10);    // condition
    */

    /*
    for(i = 0 ; i <= 10; i++){
        console.log(i)
    }
    */

    /*
    let password;   //if we define inside do block, it'll not be available in while so giving error. So we've defined outside do block
    do{
        password = prompt('Enter the password')
    } while(password.toLowerCase() !== 'let me in');
    */

    /*
    for(i = 1 ; i < 10 ; i = i+2){
        console.log(i);
    }
    
    let list = [1,2,34,45,56,6,74,2,2,4,5,9]
    for (let i=0 ; i < list.length ; i++){
        console.log(list[i]);
    } 

    let sample_string = 'Search this c c string c c baby';
    let char_to_search = 'c';
    for (let i = 0; i < sample_string.length ; i++){
        if(sample_string[i] === char_to_search){
            console.log(sample_string[i] + ' is present at index ' + i);
            break;
        }
    }
    */

    let d = document.getElementById('destination');
    for (let i = 0 ; i < 10 ; i++){
        for (let k = i ; k >= 0 ; k--){
            d.append(`${k } `);
        }
        var br = document.createElement('br');
        d.appendChild(br);
    }
}