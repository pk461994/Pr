{
    let position = {
        x2:10,
        y2:20,
        print : function(){
            console.log(`Method: X: ${this.x2}, Y: ${this.y2})`)
            console.log(this)
        },
        myObject : {sweetProperty : 'Hello Friends'}, //Nested object
    }
    function print(){
        console.log(`Function: X: ${this.x2}, Y: ${this.Y2}`)
        console.log(this)
    }
    print();
    position.print();                // As we're assigning function() to print. So while calling we put ()
    position.myObject.sweetProperty; // sweetProperty is just a string so we didn't give ()
}