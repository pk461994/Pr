// {
//     var name = prompt();
//     var age = prompt();
//     if(name === 'Prashant'){        // identity operator //strict equal
//         console.log('Welcome Prashant')
//     } 
//     else if(name === 'Aish') {
//         console.log('Aish I love u')
//     }
//     else if(name !== 'Aish'){       // Strict not equal
//         console.log('HI')
//     }
//     else if (age === 18){
//         console.log('This statement will not print bz we are comparing string which is age to 18 which is int')
//     }
//     else if (age == 18){
//         console.log('This will print as internally type will be converted to same type and then condition will be checked')
//     }
// }


// Single line if statement
// { 
//     let name = prompt()
//     if (name === 'Prashant')    console.log('hello Prashant')
//     console.log('This happens everytime')
// }

//Terniary operator
{
    let name = prompt('Name?')
    let points = name === 'Chandan' || name === 'chandan' ? 100 : 0;
    // name === 'Chandan' || name === 'chandan' ? console.log('100') : console.log('0');
    // let points = 'Chandan' || 'chandan' ? 100 : 0;
    console.log(points)
}