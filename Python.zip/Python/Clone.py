x=[10,20,30,40,50,60]
y=x.copy()  #Clone
y[1]=999
print(x)
print(y)
z=x[:]      #Clone
z[1]=777
print(x)
print(z)
a=x         #Alias
print(a)

#By using Slice operator and copy function we can Clone.
#Cloning means completely different object will be created
#Aliasing means same object but duplicate reference variable will be created
#Difference b/w = operator and copy() method
#     = operator is meant for Aliasing
#     copy() method is meant for Cloning
