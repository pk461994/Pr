import logging
logging.basicConfig(filename='log.txt',level=logging.WARNING) 
print('Python logging demo')
logging.debug('debug message')
logging.info('info message')
logging.warning('warning message')
logging.error('error message')
logging.critical('critical message')



'''
We have specified required logging level as WARNING
So,
logging.warning('warning message')
logging.error('error message')
logging.critical('critical message')
will execute. Bz as we've specified, WARNING and its above will execute as error and critical
If log.txt is not there, it'll create it in the current working directory only
logging.basicConfig is the function name
Default logging level is WARNING
Just like we don't mention in line 2 like    level=logging.WARNING    in   logging.basicConfig(filename='log.txt',level=logging.WARNING)
So it'll take default as WARNING only. Here WARNING or DEBUG or anything should be in capital letter only in line 2
where we're defining the level
'''
