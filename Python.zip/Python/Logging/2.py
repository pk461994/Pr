import logging

logging.basicConfig(filename='log1.txt',level=logging.WARNING)

logging.info('A new request came')

try:
    x=int(input('Enter first number:'))
    y=int(input('Enter second number:'))
    print(x/y)

except ZeroDivisionError as msg:
    print('Cannot divide by zero')
    logging.exception(msg)         #Here we're saving the error messgae i.e, msg in log1 for future referrence purpose. All the error which'll come will be saved in log1 file

except ValueError as msg:
    print('Enter only int values')
    logging.exception(msg)

logging.info('Request processing completed')

'''
As many times we run and give input and if error comes that error information will be stored in log1 file
'''
