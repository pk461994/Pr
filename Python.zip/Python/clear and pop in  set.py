s={1,2,3,4,5,6}
print(s)
print(s.clear())   #To delete of clear the set
s={10,20,30,40,50}
print(s)
print(s.pop())
print(s.pop())
print(s.pop())
print(s.pop())
print(s.pop())
print(s)
print(s.pop())  #Now the set is empty so it'll throw, KeyError: 'pop from an empty set'



#Output:-
#{1, 2, 3, 4, 5, 6}
#None
#{40, 10, 50, 20, 30}
#40
#10
#50
#20
#30
#set()
#Traceback (most recent call last):
#  File "C:/Users/pkuma182/Documents/Py/pop in  set.py", line 8, in <module>
#    print(s.pop())
#KeyError: 'pop from an empty set'

#pop() will remove and return the last element if we do not pass any arguement
#But as this is set order is not preserved so it will randomly remove an element
#Internally elemnts will be added according to some fixed hash code
#but in set it is not fixed so it will remove randomly
