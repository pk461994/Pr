d=dict()        #Empty Dictionary
d={}            #Empty Dictionary
d[100]='durga'
d[200]='Prashant'
d[300]='Aishwarya'
d['Tom']='Jerry'
d['Love']='Pug'
print(d)
print(d['Love'])
print(d[500])       #500 Key is absent so will get KeyError: 500

#output
#{100: 'durga', 200: 'Prashant', 300: 'Aishwarya', 'Tom': 'Jerry', 'Love': 'Pug'}
#Pug
#Traceback (most recent call last):
#  File "C:/Users/pkuma182/Documents/Py/dict.py", line 9, in <module>
#    print(d[500])
#KeyError: 500
