def outer():
    def inner(a,b):
        print('The sum is:',a+b)
        print('The average is:',(a+b)/2)
    inner(10,20)
    inner(30,40)
    inner(70,50)
outer()
inner()


#The sum is: 30
#The average is: 15.0
#The sum is: 70
#The average is: 35.0
#The sum is: 120
#The average is: 60.0
#Traceback (most recent call last):
#  File "F:/Python/nested function.py", line 9, in <module>
#    inner()
#NameError: name 'inner' is not defined


#To define function specific repeatedly required functionality we use function inside function i.e, nested function
#Logic:-
#Whenever we call outer() function all the inner function will also be executed
#We cannot call inner function ouside. Because it's not directly available. It's part of outer()
#If we call it we'll get NameError: name 'inner' is not defined
