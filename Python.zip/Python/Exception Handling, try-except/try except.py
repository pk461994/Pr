print('hello')
try:
    print(10/0)
except ZeroDivisionError as msg:    #In place of msg we can use anything like x
    print("exception raised and it's description is:",msg)
print('World')

#Printing exception information to console