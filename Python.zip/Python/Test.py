s=input("Enter some string:")
x=int(input('Enter start range:'))
y=int(input('Enter end range:'))
print('Slicing range is:',s[x:y])
