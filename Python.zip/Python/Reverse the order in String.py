s=input('Enter some string:')
l=s.split()     #l is List contains elments of string seperated by spaces
l1=[]           #
i=len(l)-1
while i>=0:
    l1.append(l[i]) #i is the last index. So l[i] means the last index in l will be added to empty list l1
    i=i-1
print(l1)       #1st output to Print normally
output=' '.join(l1) #We want as a single string with a space seperator. All the elements present in l1 will be joined in a single string with a space seperator
print(output)


#Output
#Enter some string:Prashant kumar jha
#['jha', 'kumar', 'Prashant']           This o/p is bz of print(l1)
#jha kumar Prashant                     This o/p is bz of output=' '.join(l1) followed by print(output)
#append method used to add one lement to the list
