s=input('Enter some string:')
l=[]
for x in s:         #For each value of x in string s
    if x not in l:  #If x will not be in l then only add elements of s in empty list l. If itmis there don't add to l
        l.append(x)
print(l)            #Print output normally as a List. To convert output in string below output is there:
print(''.join(l))  #All the values presend in l please combine together with '' means no seperator. Now it will be a string



#Enter some string:ABCDABCDABCD
#['A', 'B', 'C', 'D']           --> This o/p is due to print(l)
#ABCD                           --> This o/p is due to print(''.join(l))


#Alternate way:-
# We can use set in place of list, l. Because in set duplicates are not allowed by default.
# But the small problem with using set is order is not important. So output will shuffle

#Code:-
#s=input('Enter some String:')
#print(''.join(set(s)))

#Output:-
#Enter some String:ABCDABCDABCD
#CDBA
