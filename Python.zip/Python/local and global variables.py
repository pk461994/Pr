a=10            #Global Variable. Applicable for all functions
def f1():
    a=20        #local variable. Applicable for only f1.
    print(a)
    print(globals()['a'])
    print(globals())
f1()



#20
#10 
#{'__name__': '__main__', '__doc__': None, '__package__': None, '__loader__': <class '_frozen_importlib.BuiltinImporter'>, '__spec__': None, '__annotations__': {}, '__builtins__': <module 'builtins' (built-in)>, '__file__': 'C:/Users/pkuma182/Documents/CG/Py/local and global variables.py', 'a': 10, 'f1': <function f1 at 0x0000000002FA1BF8>}


#Local variable priority is more for the particular function only.
#Like for f1(), a=20 will be applicable as it is local variable of that function
#If we want global variable instead of local variable than we need to use globals()['a']
#globals() is the inbulit python function
#globals() is a dictionary which contains all global variables and corresponsing values
