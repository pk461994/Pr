def countdown(num):
    print('Starting Countdown!')
    while(num>0):
        yield num   #yield returns values in case of generator
        num=num-1
        
values=countdown(7)
for x in values:
    print(x)
