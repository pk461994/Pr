try:
    x = int(input('Enter First Number:'))
    y = int(input('Enter Second Number:'))
    print(x/y)
except ZeroDivisionError:
    print("Can't divide by zero")
except ValueError:
    print("Please provide int value only")

'''We can take multiple except block
But Python is always going to consider from top to bottom only
Like First except block will come. If it is not matched than it'll consider 2nd except block and so on'''