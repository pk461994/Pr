#import os
try:
    print('try block')
    #os._exit(0)
    print(10/0)
except ZeroDivisionError:
    print('ZeroDivisionError: cannot divide by zero')
finally:
    print('finally')

''' Case 1- If no exception comes, finally block will also be executed
Case 2- If exception comes and handled by except block than also finally block will be executed
Case 3- If exception comes but not handled like we know in try block ZeroDivisionError will come
but we put ValueError in except like 
except ValueError:
Than this is abnormal termination as it has no matched except block
So it'll come to first finally block and first finally block only will be executed. No other block will be executed except finally block in case of abnormal termination
After finally block execution only abnormal termination will be happened.
So doesn't matter exception comes or not finally block will always be executed

Case 4- If we shut down PVM(Python Virtual Machine) using a module named "os" by command
os._exit(0)       before execution of finally block than only finally block will not be executed
Like we can take os._exit(0) in try block so that it'll be executed before finally block execution
0 indicates status code and it means normal termination. Multiple status codes are there and we can take any value in place of 0 like 1, 2, 3,.. 100 or -1, -2.....  But one int value we have to take compulsory
But to use that we need to import os module by using
import os
'''