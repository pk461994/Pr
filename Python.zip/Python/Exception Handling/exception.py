class TooYoungException(Exception):
    def __init__(self,arg):         #Constructor
        self.msg=arg

class TooOldException(Exception):
    def __init__(self,arg):         #Constructor
        self.msg=arg

age=int(input('Enter your age:'))
if age<18:
    raise TooYoungException('You are not eligible for marraige')  #We're creating object. whatever we're passing it'll become arguement to constructor
elif age>60:
    raise TooOldException('You are not eligible for marraige')
else:
    print('Thanks for registration')

'''
arg is the variable whatever we're passing. We can use anything in place of arg
.msg, self, __init__ are predefined variables we can't change it
'''
