try:
    x = int(input('Enter First Number:'))
    y = int(input('Enter Second Number:'))
    print(x/y)
except ZeroDivisionError:
    print("ZeroDivisionError: cannot divide by zero")
except:               #this is default except block, It'll execute when the exception is not ZeroDivisionError
    print('Default Except: Please provide valid input')

''' When no other except block matches than only default except will work
Default Except block should be at last otherwise we'll get error like
SyntaxError: default 'except:' must be last
'''