try:
    x = int(input('Enter First Number:'))
    y = int(input('Enter Second Number:'))
    print(x/y)
except (ZeroDivisionError,ValueError) as msg:  #as msg we need to take outside () block only. We can take anything in place of msg like x
    print("Please provide valid numbers only and the problem is:", msg)

'''It'll handle 2 exceptions
We're taking 2 error within () as it is mandatory so this group of exceptions internally considered as tuple'''