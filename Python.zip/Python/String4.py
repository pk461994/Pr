#To print characters at odd position and even position for the give string

#   2)   Code using slice operator
s=input('Enter some string:')
#print('Characters present at Even position:',s[::2])    #Starts from 0th index till end and diff will be 2 so will print even
#print('Characters present at Odd position:',s[1::2])    ##Starts from 1st index till end and diff will be 2 so will print odd

#   1)   Alternate Code without slice operator

i=0
print('The characters at even position:')
while i<len(s):
    print(s[i],end=',')
    i=i+2
print('\nThe characters at even position:')
i=1
while i<len(s):
    print(s[i],end=',')
    i=i+2
