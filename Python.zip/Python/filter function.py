def iseven(number):
    if number%2==0:
        return True
    else:
        return False
l=[0,5,10,15,20,25,30,35,40,45]  #Can be set or tuple or list
l1=list(filter(iseven,l))  #For each element present in l, apply iseven function
print(l1)



#[0, 10, 20, 30, 40]



#We can also do it with use of lambda function i,e, anonymous function. We'll use once only without defining the function


p=[0,5,10,15,20,25,30,35,40,45,50,55,60,65]
l2=list(filter(lambda x:x%2==0,p))
l3=list(filter(lambda x:x%2!=0,p))
print(l2)
print(l3)

#[0, 10, 20, 30, 40, 50, 60]
#[5, 15, 25, 35, 45, 55, 65]


#The filter() method filters the given sequence with the help of a function that tests each element in the sequence to be true or not.

#Suppose input contains 10 elements than output will contain less than or equal to the input elements
#In filter function the no of elements in input is not equal to no of elements in output
