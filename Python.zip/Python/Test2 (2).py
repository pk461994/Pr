name=''
password=''
while name!='Prashant' or password!='Jha':
    name=input('Enter Name:')
    password=input('Enter password:')
print('Hello Prashant!')
    
