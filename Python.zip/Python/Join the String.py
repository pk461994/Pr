l=['durga','soft','solutions']
s='-'.join(l)
print(s)




#We are joining th string in l with - symbol and assigning it to s
