l1=['Chicken','Mutton','Fish']
l2=['KF','Bacadi','RC']
l1.append(l2)
print(l1)
print(l2)
