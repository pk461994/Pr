list=eval(input('Enter some List:'))
i=0
while i<len(list):
    print(list[i])
    i=i+1

#Alternate loop using for:-
#for x in list:
#    print(x)


#Output
#Enter some List:1,2,3,4,5
#1
#2
#3
#4
#5

