samplelist=[1,2,3,4,5,1,5,47,12,32,4,6,1,52,4,77,47,12,9,8,9,5,6,7,9,7,4]
result=[]
[result.append(item) for item in samplelist if item not in result]
print(result)
