l=[10,20,30,40,50,12,69,33,666,58,1,2,3]
target=int(input('Enter the value to search in list l:'))
if target in l:
    print(target,'available and its first occurance is at:',l.index(target))
else:
    print(target,'not available')


#Alternate code using try except:-
#try:
#    print(target,'available and its first occurance is at:',l.index(target))
#except ValueError:
#    print(target,'not available')



#Output:-
#Enter the value to search in list l:50
#50 available and its first occurance is at: 4

#Enter the value to search in list l:444
#444 not available



