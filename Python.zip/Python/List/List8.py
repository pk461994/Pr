#To eliminates duplicates values from a list

l=eval(input('Enter some List:'))
l1=[]
for x in l:
    if x not in l1:
        l1.append(x)
print(l1)

#Alternate Option. Convert List into set.

s=set(l)    #Order is not preserved
print(s)

#Output:-
#Enter some List:1,2,3,4,56,12,1,3,4
#[1, 2, 3, 4, 56, 12]
#{1, 2, 3, 4, 12, 56}
