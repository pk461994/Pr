#Print n nos without using any predefined function like range

def printnos(n):
    if n>0:
        printnos(n-1)
        print(n)
        #printnos(n-1)
printnos(5)
