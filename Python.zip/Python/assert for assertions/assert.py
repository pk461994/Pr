def squareIt(x):
    return x**x    #For square we need to take x*x or x**2

assert squareIt(2)==4,'The square of 2 should be 4'  #Statement under '' is the arguement that we pass
assert squareIt(3)==9,'The square of 3 should be 9' #These are augmental assertion as it has both conditional_expression and message
#assert conditional_expression,message

print(squareIt(2))
print(squareIt(3))
print(squareIt(4))

'''
We'll get Assertion Error like

Traceback (most recent call last):
  File "C:/Users/pkuma182/Documents/Python/assert for assertions/assert.py", line 5, in <module>
    assert squareIt(3)==9,'The square of 3 should be 9'
AssertionError: The square of 3 should be 9

To hide this assert statement in client machine like in production
We need to use -O like
py -O file.py
It is capital O for owl
'''
