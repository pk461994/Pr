s='''this is ' and '' symbol'''
print(s)
