s='durga software solutions Hyd India'
l=s.split(' ',3)   #l=s.rsplit(' ',3)  for spliting it from right
for x in l:
    print(x)
