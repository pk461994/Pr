#To display all positions of substring in the given string:
s=input('Enter some String:')
subs=input('Enter substring:')
flag=False
pos=-1
n=len(s)      #n=Lenght of string
count=0
while True:
    pos=s.find(subs,pos+1,n)
    if pos==-1:
        break
    print('Found at index:',pos)
    flag=True
    count=count+1
if flag==False:
    print("subs not found")
print('The  number of occurences:',count)

#Suppose our string is 'abaab'
#We want to search for a. How many time it is available in string 'abaab'
#flag=False bz if subs i.e, a if not available in string than it will go directly to if flag==False and execute: print("subs not found")
#pos=-1 and n=len(s). So n=5
#Now it will go in while loop, while True
#pos=s.find(subs,pos+1,n)    This will find the substring, subs in s
#pos is -1. Now pos+1= 0. So it will find from 0 index to the end length of string i.e, n-1. It will search from 0 to n-1=4. So 0 to 4
#So we found a in 0th position so will not go to if pos==-1 followed by break.
#Then it will print,   print('Found at index:',pos) Like Found at index:0 and
# Then flag=True and continues the loop until it finds all a present in s
#We have already searched for 0th index so now pos=1. pos is 0 now. Then pos+1 means 0+1=1. So it will search from 1st index to last and so on
#If we can't find the substring the it will go to if pos==-1 then it will break loop and come out of loop.
#After coming out it will move to if flag==False and will print, subs not found


#Output: Enter some String:abcaabbccaa
#Enter substring:a
#Found at index: 0
#Found at index: 3
#Found at index: 4
#Found at index: 9
#Found at index: 10    
