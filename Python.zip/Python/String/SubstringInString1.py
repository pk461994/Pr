s='abcabcabcabc'
print(s.count('ca'))
print(s.count('ca',3,len(s)))#Search ca from 3rd index to last element of string
