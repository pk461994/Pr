s=input('Enter some string:')
i=0
for x in s:
    print('The character present at positive index:{} and at negative index:{} is:{}'.format(i,i-len(s),x))
    i=i+1
#Here for +ve index the value will be i which starts from 0 and goes until string ends
#
