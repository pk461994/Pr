s=input('Enter some string:')
print(s[::-1]) #-1 so it will start from right to left.
#We are taking each character from right to left
