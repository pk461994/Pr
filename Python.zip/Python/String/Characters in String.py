s=input('Enter some character:')
if s.isalnum():
    print('Alpha Nummeric Character')
    if s.isalpha():
        print('Numeric Character')
        if s.islower():
            print('Lower character alphabet character')
        else:       #This is for if s.islower():
            print('Upper case alphabet character')
    else:           #This is for if s.isalpha():
        print('It is a Digit')
elif s.isspace():   #This is for if s.isalnum():    If the s is not alphanumeric then it will come to this to check if it is space character
    print('It is Space character')
else:               #If s is neither alphanumeric not space character than this is Special Character like (@#$%)
    print('Non Space Special Character')
