s=input('Enter some String:')
output=''
for x in s:
    if x.isalpha():
        output=output+x
        previous=x
    else:
        newch=chr(ord(previous)+int(x))
        output=output+newch
print(output)

'''Logic:-
Suppose we enter a4 so output should be ae. 4th char after a is e
Now x is a first. output=output+x.   output=a      As output is empty string
We are storing value of x i.e, a in previous
Now its completed for the first character in if block. Now 4 will come so loop will be in else as 4 is no an alphabet character
We are storing value in newch
previous is a. Now ord(previous)=ord(a)=97
newch= chr(97+int(x))=chr(97+4) (->the current int value i.e, int(x) is 4)=101
newch=chr(101)= e
Add that value of newch in output. output=output+newch
output=a+e=ae
output=ae

Enter some String:a4
ae

Enter some String:a4b3
aebe

Enter some String:f143
fgji
'''
