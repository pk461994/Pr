print('Durga123'.isalnum())     #True
print('durga123'.isalnum())     #True
print('durga'.isalpha())        #True
print('Durga'.isalpha())        #True
print('Durga123'.isalpha())     #False
print('123123'.isdigit())       #True
print('abc'.islower())          #True
print('Abc'.islower())          #False
print('abc123'.islower())       #True   Checks only alphabet symbol. If it is lower than returns true
print('ABC'.isupper())          #True
print('123'.istitle())          #False
print('A123'.istitle())         #True   Checks 1st character to be in Upper case only
print('Learning Python is easy'.istitle())          #False  Each word's 1st character should be in upper case.
print('Learning Python Is Easy'.istitle())          #True
print('   '.isspace())          #True
