s=input('Enter some String:')
output=''
for x in s:
    if x.isalpha():         #If it is alphabet
        output=output+x     #Than add to output
        previous=x          #Previous is that alphabet only
    else:
        output=output+previous*(int(x)-1)
print(output)



'''
Output
Enter some String:B4A1D3
BBBBADDD
'''
