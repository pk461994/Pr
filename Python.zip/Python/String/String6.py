s=input('Enter some String:')
output=''
for x in s:
    if x.isalpha():
        output=output+x
        previous=x
    else:
        output=output+previous*(int(x)-1)
print(output)



#Output
#Enter some String:B4A1D3
#BBBBADDD
