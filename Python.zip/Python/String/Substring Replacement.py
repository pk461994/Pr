s='Learning Python is very difficult'
print(s)
s=s.replace('difficult','easy')   #s.replace(oldstring,newstring)
print(s)
