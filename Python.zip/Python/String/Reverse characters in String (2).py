s=input('Enter some String:')
line=s.split()
l1=[]
for word in line:
    l1.append(word[::-1])      #append method used to add one element to the list
print(l1)
output=' '.join(l1)
print(output)

'''
Output
Enter some String:Prashant Jha
['tnahsarP', 'ahJ']            This is for: print(l1)
tnahsarP ahJ                   This is for: output=' '.join(l1) followed by print(output)

This is a 3 phase process - First we split the string to words, then we reverse the words and then connect them together again
'''
