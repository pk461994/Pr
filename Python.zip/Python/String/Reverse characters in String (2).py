s=input('Enter some String:')
l=s.split()
l1=[]
for x in l:
    l1.append(x[::-1])      #append method used to add one element to the list
print(l1)
output=' '.join(l1)
print(output)

#Output
#Enter some String:Prashant Jha
#['tnahsarP', 'ahJ']            This is for: print(l1)
#tnahsarP ahJ                   This is for: output=' '.join(l1) followed by print(output)
