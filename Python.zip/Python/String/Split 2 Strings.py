s='Durga Software Solutions'
l=s.split()
print(type(l))
print(l)
for x in l:
    print(x)    #print(x,end=' ')
