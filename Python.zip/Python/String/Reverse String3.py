s=input('Enter some string:')
i=len(s)-1
output=''
while i>=0:
    output=output+s[i]
    i=i-1
print(output)
