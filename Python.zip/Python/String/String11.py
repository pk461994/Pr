>>> s='0123456789'
>>> s[0:5:1]
'01234'
>>> s[4:-1:-1]   #-1 means start i.e, 4 to n+1. So n is -1 so -1+1=0. In this case output will be empty string
''
>>> s[-7:-2:-1]  #-1 means bacward direction. -7 to -2+1=-1. So we can't more from 77 to -1 in backward direction. So we'll get empty string
''

#Notes:-
#end should not be -1 or end+1 is 0 then result is always empty string
#s[Begin:End:Step]
#If Step is -ve then Backward Direction. Begin to End+1. End should not be -1 or end+1 is 0 then result is always empty string
#If Step is +ve then Forward Direction. Begin to End-1

#  s[x:-1:-z]
# We can take any x value or any z value. Result will always be empty String. Examples:-
>>> s[5:-1:-5]
''
>>> s[1:-1:-5]
''
>>> s[7:-1:-1]
''

