# Like Input : B4A1D3 and Output: BAD413 but again we want o/p like ABD134
s=input('Enter some string:')
s1=s2=output=''
for x in s:
    if x.isalpha():         #Will check the alphabet characters
        s1=s1+x
    else:               #If we take elif x.isdigit():       all the special characers will be ignored like !@#$%.... Only digits will be considered
        s2=s2+x
for x in sorted(s1):    #Sort the characters in Ascending in S1 which is alphabet like A,B,C,d......
    output=output+x
for x in sorted(s2):    #Sort the characters in Ascending in S2 which is digit like 1,2,3.... 
    output=output+x
print(output)
#Alternate method to Sort the output in Ascending order
output=s1+s2
print(sorted(output))
