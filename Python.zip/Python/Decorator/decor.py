def decorator_function(any_function):
    def inner():
        print('The name of most Handsome boy in the world is below')
        any_function()
    return inner

@decorator_function

def sample_function():
    print('Prashant Jha')

sample_function()
#var = decorator_function(sample_function)
#var()

'''
Instead of using @decorator_function we can use 2nd way to do so
var = decorator_function(sample_function)
var()
Here we're calling decorator_function with sample_function as it's argument and saving it to var() than calling var()

We have to call sample_function() compulsory to execute everything. Then it'll check for any decorator function with @
decorator_function will take anything as any function as argument. 
sample_function() will be passed as an argument to decorator_function with "any_function" name
This decorator_function will return some inner. So instead of sample_function(), inner() will be executed
The body of inner() will be executed.

def decorator_function(any_function) --> Here any_function will be the input of function
And in this case any_function is sample_function()
Output of decorator_function is inner()
So inner will execute and within the body of inner() wherever any_function aka sample_function will come
it'll execute sample_function
'''