#Addition using Decorator Function

def sum_decor(any_function):
    def wrapper_function(a,b):
        print('Adding 2 numbers using decorator')
        print('#'*50)
        print('First argument:',a)
        print('Second argument:',b)
        print(f'The sum of {a} and {b} is {a+b}')
    return wrapper_function

#@sum_decor
def sum(a,b):
    print(a+b)

#sum(10,20)
var = sum_decor(sum)
sum(20,30)   #We can call normal function also
print('*'*50)
var(10,20)

'''
If we use @ than decorator will execute for sure. But if we want both options to execute decorators or
execute normal function also we need not to use @   Instead we have to use below way
var = sum_decor(sum)
sum(20,30)   #We can call normal function also
var(10,20)
'''