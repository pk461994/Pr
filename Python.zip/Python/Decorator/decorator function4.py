def decor(func):
    def inner(name):   #Original name which we've passed in wish(name) will be the arguement of this function
        print('Decor Function Execution')  #First this will be printed
        func(name)  #We're calling func(name)
    return inner

def decor1(func):    #decor1 input is the output of decor function
    def inner(name):
        print('Second Decor(Decor1) Execution')
        func(name)
    return inner
@decor1
@decor
def wish(name):
    print('Hello',name,'Greetings!')

wish('Durga')


#Second Decor(Decor1) Execution
#Decor Function Execution
#Hello Durga Greetings!
