def decor(func):           #Decorator function
    def inner(name):
        if name=='Kim':
            print('Hey Kim! I Love You')
        else:
            func(name)
    return inner

def wish(name):
    print('Hello',name,'You are my friend')

decorfunction=decor(wish) #We called  the function decor() without decortor. We didn't use @decor

wish('Kim') #Here decor(func) will not execute bz we removed the linked b/w decor() and wish(). As we haven't used @decor
decorfunction('Kim')  #Here the decor() will execute. Here we're calling decor() by decorfunction which returns inner()
wish('Sunny')
decorfunction('Sunny')

#Hello Kim You are my friend
#Hey Kim! I Love You
#Hello Sunny You are my friend
#Hello Sunny You are my friend



#Decorator function is function that takes other function as input and provide output function with extended functionality
