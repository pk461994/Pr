def doubledecor(func):
    def inner():
        x=func()
        return 2*x
    return inner

def squaredecor(func):
    def inner():
        x=func()
        return x*x
    return inner
@doubledecor  #Input is squaredecor
@squaredecor  #Input is num()

def num():
    return 10
print(num())

#200

'''Whenever we're calling num() like from print(num())
 immediately python will check for the decorators. We have multiple decorator functions. Python will execute those decorators from
 Top to Bottom. So first doubledecor comes.
 doubledecor() is going to return inner. So statements under inner() will be executed
 For doubledecor(func) when we call func() like x=func(), it means squaredecor(func) input.
 So whenever we're calling x=func() from doubledecor(func), Control will go to inner() of squaredecor(func). Now in squaredecor(func)
 x=func(). For the squaredecor, num() is the input. So x will become 10 as num() returns 10. So x=10.
 Not squaredecor returns x*x. So value becomes 10*10=100
 It will be input to x=func() in doubledecor. So x=100. Now inner() in doubledecor(func) returns 2*x
 So 2*100=200
 This 200 we will print eventually by print(num()) '''
