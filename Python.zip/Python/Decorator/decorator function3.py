def smartdivision(func):
    def inner(firstnumber,secondnumber):
        if secondnumber==0:
            print("Hello Stupid! We can't divide by 0")
            return     #Nothing will be returned. O/p we will get as None
        else:
            return func(firstnumber,secondnumber)  #firstnumber,secondnumber is the arguement for func
    return inner #Decorator @smartdivision will always call def smartdivision(func). smartdivision(func) is going to return inner(firstnumber,secondnumber). inner(firstnumber,secondnumber) will be called automatically by python bz of @smartdivision

@smartdivision
def division(firstnumber,secondnumber):
    return firstnumber/secondnumber
print(division(10,2))
print(division(10,5))
print(division(10,0))


#5.0
#2.0
#Hello Stupid! We can't divide by 0
#None                               Bz of the empty retun statement
