import re
string=""" 9812398099 Hello my Number is 9430760930 and my firend's no is 8936887624"""
regex='\d+'
match=re.findall(regex,string)
print(match)