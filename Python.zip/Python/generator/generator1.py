import random
import time

names=['Sunny','Kim','Camella','Kylie']
subjects=['java','python','c++','JS']

def people_list(num_people):
    result=[]
    for i in range(num_people):
        person = {
                    'id':i,
                    'name': random.choice(names),
                    'subject':random.choice(subjects)
                 }
        result.append(person)
    return result

def people_generator(num_people):
    for i in range(num_people):
        person = {
                   'id':i,
                   'name': random.choice(names),
                   'major':random.choice(subjects) 
                 }
        yield person #yield is to generate value in case of generator

t1= time.perf_counter() #We have to use time.perf_counter() or time.process_time() instead of time.clock()
people= people_list(10000000)
t2= time.perf_counter()

t1= time.perf_counter()
people=people_generator(10000000)
t2= time.perf_counter()

print('Took {}'.format(t2-t1))


#Took 1.7940114999999963
