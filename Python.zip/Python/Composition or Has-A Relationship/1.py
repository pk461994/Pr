class Bike:
    def __init__(self,name,model,color):
        self.name=name
        self.model=model
        self.color=color
    def getinfo(self):
        print('Bike name: {}, Model: {}, Color: {}'.format(self.name,self.model,self.color))

class Employee:
    def __init__(self,ename,eno,bike):
        self.ename=ename
        self.eno=eno
        self.bike=bike
    def empinfo(self):
        print('Employee name:',self.ename)
        print('Employee number:',self.eno)
        print('Employee Bike Info,')
        self.bike.getinfo()  #Employee has bike reference by using that we can call all the methods inside Bike class
b=Bike('Jawa','42','Blue')   #Creating Bike class object
e=Employee('Prashant','100',b)  #We have put b so that employee object has access to Bike object which refers to Bike class
e.empinfo()

'''b means Bike class object and employee object e has b. Using this e we can access functionalities of Bike class.
this behavior is called Comprehension or Has-A Relationship

By using Class Name or by creating object,
we can access members of one class inside another class is nothing but composition (Has-A Relationship)
'''
