word=input('Enter some word:')
vowels={'a','e','i','o','u','A','E','I','O','U'}
d={}
for x in word:
    if x in vowels:
        d[x]=d.get(x,0)+1  #If it is available first time take 0. So d[x]=1. If the same letter comes again d[x]=1+1=2.(x,0) is Key,Value concept
for k,v in sorted(d.items()):
    print('{} occurred {} times'.format(k,v))


#Output:-
#Enter some word:Prashant Aishwarya Jha
#A occurred 1 times
#a occurred 5 times
#i occurred 1 times
