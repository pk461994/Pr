>>> d={}    #Empty Dictionary
>>> d={100:'Prashant',200:'Chandan',300:'Aishwarya'}
>>> d
{100: 'Prashant', 200: 'Chandan', 300: 'Aishwarya'}
>>> d[400]='Sharma'  #Adding Key and Value to d
>>> d
{100: 'Prashant', 200: 'Chandan', 300: 'Aishwarya', 400: 'Sharma'}
>>> del d[200]      #To delete the element present at 200 Key and value. 200: 'Chandan' now deleted from d
>>> d
{100: 'Prashant', 300: 'Aishwarya', 400: 'Sharma'}
>>> d[200]          #d[200] is not there in d. So we'll get KeyError: 200
Traceback (most recent call last):
  File "<pyshell#71>", line 1, in <module>
    d[200]
KeyError: 200
>>> d.clear()       #To clear or delete all Key and values from d. Result would be empty dictionary
>>> d
{}
>>> d={100: 'durga', 200: 'Prashant', 300: 'Aishwarya', 'Tom': 'Jerry', 'Love': 'Pug'}
>>> d
{100: 'durga', 200: 'Prashant', 300: 'Aishwarya', 'Tom': 'Jerry', 'Love': 'Pug'}
>>> del d       #It will delete all key and values as well as variable also. Like it will delete variable d as well
>>> d
Traceback (most recent call last):
  File "<pyshell#77>", line 1, in <module>
    d
NameError: name 'd' is not defined

>>> list=['Durga','Prashant','Aishwarya']  #Adding list to the value. We can add a list or tuple or set etc
>>> d={100:list,200:'Rekha'}
>>> d
{100: ['Durga', 'Prashant', 'Aishwarya'], 200: 'Rekha'}

>>> d=dict([(100,'Prashant'),(200,'Rekha'),(300,'Aishwarya')]) #List of tuples or tuples of tuples or set of tuples. But can be used only using dict method. Inner thing should be tuple() outer can be list, tuple or set
>>> d
{100: 'Prashant', 200: 'Rekha', 300: 'Aishwarya'}

>>> d=dict({(100,'Prashant'),(200,'Rekha'),(300,'Aishwarya')}) 
>>> print(d.get(100))  #To get the value from a key. 
Prashant
>>> print(d.get(500))  #If key is not available we'll get None as output. No KeyError
None
>>> print(d.get(500,'Jha')) #If key is unavailable and we don't want None. So any default value can be assigned. We'll get that value in O/p. If key is avalable the default value will only come
Jha
>>> d
{300: 'Aishwarya', 100: 'Prashant', 200: 'Rekha'}

>>> print(d.pop(200))  #pop to remove item and return the value in O/p.
Rekha
>>> d
{300: 'Aishwarya', 100: 'Prashant'}
>>> print(d.popitem()) #popitem() removes some random value
(100, 'Prashant')
>>> print(d.popitem()) #Again we call it and result is empty dictionary
(300, 'Aishwarya')
>>> d #If we call popitem() again we will get KeyError: 'popitem(): dictionary is empty'
{}
>>> d={100:'abc',200:'pqr',300:'xyz'}
>>> d.pop()
Traceback (most recent call last):
  File "<pyshell#116>", line 1, in <module>
    d.pop()
TypeError: pop expected at least 1 arguments, got 0


>>> d=dict(((100,'abc'),(200,'pqr'),(300,'xyz')))
>>> print(d.keys())
dict_keys([100, 200, 300])  #Internally it is List only. But of dict_keys object
>>> print(d.values())
dict_values(['abc', 'pqr', 'xyz'])


>>> d={100:'abc',200:'pqr',300:'xyz'}
>>> list=d.items()
>>> print(list)
dict_items([(100, 'abc'), (200, 'pqr'), (300, 'xyz')])




>>> squares={x:x*x for x in range(1,6)}     #Comprehension. Will be stored in key:value that why we took x:x*x
>>> squares
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
>>> doubles={x:x*2 for x in range(1,6)}
>>> doubles
{1: 2, 2: 4, 3: 6, 4: 8, 5: 10}
