s=[0,1,2,3,4,5,6,7,8,9]
print(s[:0:-1])

#Output-    [9, 8, 7, 6, 5, 4, 3, 2, 1]
#It is backward slicing step so for this always the starting point is the End of String.
#So in this it took 9 as starting point which is at -1 index and moved to 0 which is 0th index
