def outer():
    print('Outer function started')
    def inner():
        print('Inner function started')
    print('Outer function returning inner function')
    return inner   #() is not required bz we're are not performing inner function call. We're only returning it
outer()
print()
print()
f1=outer()   #Function calling. If we wrote like f1=outer without (), this is aliasing, giving another name to outer as f1
f1()
f1()        #We can call f1() multiple times


#Outer function started
#Outer function returning inner function


#Outer function started
#Outer function returning inner function
#Inner function started
#Inner function started


#If we caller outer() function. The outer() function will execute
#But that outer() function returns inner() function so inner() function will also execute
#If we want to call inner() function directly from outside. We need to assign outer() function to a function like f1
#Than we can call f1() function.
#We're calling outer () function which will return inner() function. That inner() function we're assigning with f1()
