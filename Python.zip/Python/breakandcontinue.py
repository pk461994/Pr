cart=[1,2,3,50,36,1220,66]
for item in cart:
    if item>=500:
        print('Sorry we cannot process',item,'access needed')
        continue  #break
    print('The item in cart is:',item)
else:           #else is associated with break only not with continue. else means loop without break
    print('Congrats all itms processed successfully')
    
