l=[10,20,30,40,50,60]
x=int(input('Enter Element to be removed:'))
if x in l:
    l.remove(x) #Remove function will remove the element. It will not return the removed element in output
    print('Removed Successfully')
    print(l)
else:
    print('Specified element is not available')



#Output:-
#Enter Element to be removed:50
#Removed Successfully
#[10, 20, 30, 40, 60]

#Enter Element to be removed:100
#Specified element is not available
