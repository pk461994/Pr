l1=['Chicken','Mutton','Fish']
l2=['KF','Bacadi','RC']
l1.extend(l2)
print(l1)
print(l2)
l3=l1.extend(l2)
print(l3)


# extend is applicable for everything like list, set, tuple, etc
#extend method won't return anything

#Output:-
#['Chicken', 'Mutton', 'Fish', 'KF', 'Bacadi', 'RC']
#['KF', 'Bacadi', 'RC']
#None

# We received l3 as None bs extend method won't return anything.
# It'll not return any value as an output
# l3=l1.extend(l2)  l2 elemets will be added to l1.
# But as extend() will not return anything so we will get output as None
