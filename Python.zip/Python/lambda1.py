sum=lambda a,b:a+b
greater=lambda x,y:x if x>y else y  #Terniary operator
print("The sum of {} and {} is {}".format(2,4,sum(2,4)))
print("The sum of {} and {} is {}".format(20,40,sum(20,40)))
print("The sum of {} and {} is {}".format(87,78,sum(87,78)))
print("The greater of {} and {} is {}".format(87,78,greater(87,78)))
print("The greater of {} and {} is {}".format(20,40,greater(20,40)))



#The sum of 2 and 4 is 6
#The sum of 20 and 40 is 60
#The sum of 87 and 78 is 165
#The greater of 87 and 78 is 87
#The greater of 20 and 40 is 40
