d={100:'abc',200:'pqr',300:'xyz'}
d1={'a':'apple','b':'banana'}
d2={111:'aaa',222:'bbb'}
print(d)
d.update(d1)
print(d)
d.update(d1,d2) #Can't add more than 1 argument in dict
print(d)

#Output:
#{100: 'abc', 200: 'pqr', 300: 'xyz'}
#{100: 'abc', 200: 'pqr', 300: 'xyz', 'a': 'apple', 'b': 'banana'}
#Traceback (most recent call last):
#  File "C:/Users/pkuma182/Documents/Py/dict5.py", line 7, in <module>
#    d.update(d1,d2)
#TypeError: update expected at most 1 arguments, got 2
