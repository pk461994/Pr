l=[10,20,30,40,50,60,70,80,90]
n=int(input('Enter the Index you want to Remove:'))
print(l.pop(n))  #This will remove element on the nth index
print(l)

#pop method by default will remove last element if we do not pass any arguement
#But if we want to remove an element at certain index we need to use pop(index)
#pop method can take index as an arguement.
#If list is empty and we call pop method. We'll get IndexError: pop from empty list
#If we pass index value which is out of range of list. Like in above ex we take n=10. l.pop(10)
#So 10th index is unavailable so we'll get IndexError: pop index out of range

#Output:-
#Enter the Index you want to Remove:2
#30
#[10, 20, 40, 50, 60, 70, 80, 90]
