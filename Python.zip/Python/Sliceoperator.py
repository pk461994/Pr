s=[0,1,2,3,4,5,6,7,8,9]
print (s[0:5:1])
print (s[-1:-7:-1])

#If the Slice step count is Positive like in first print statement it is 1. Then the last index would be n-1
#If the Slice step count is Negative like in second print statement it is -1. Then the last index would be n+1
#Slice step cannot be 0
