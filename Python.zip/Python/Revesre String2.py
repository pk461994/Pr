s=input('Enter some String:')
for x in reversed(s):
    print(x,end='')     #1st way to reverse
print()
print(''.join(reversed(s)))     #2nd way to reverse. '' means without any seperator it'll print
