class Duck:
    def talk(self):
        print('Quack Quack Quack...')
class Dog:
    def bark(self):
        print('Bark....')
class Cat:
    def talk(self):
        print('Meow....')
class Lion:
    def talk(self):
        print('Roar...')
class Bird:
    def fly(self):
        print('Flyyyyy....')

l=[Duck(),Dog(),Cat(),Lion(),Bird()]
for object in l:
    if hasattr(object,'talk'):
        object.talk()
    elif hasattr(object,'bark'):
        object.bark()
    elif hasattr(object,'fly'):
        object.fly()
'''
Here talk() is not available for every classes so we used hasattr to check whether the other properties like
bark() or fly() is there on not. If yes print that method as well
This is to avoid any AttributeError
'''