from abc import *   #abc= abstract base class module
class Vehicle:
    @abstractmethod
    def getNoOfWheels(self):
        print('Abstract method')

v=Vehicle()
v.getNoOfWheels()

'''
Only declaration but not proper implementation

If we take like
class Vehicle(ABC):
we'll get error like
TypeError: Can't instantiate abstract class Vehicle with abstract methods getNoOfWheels

If we take like
class Vehicle(ABC):
and we don't take decorator @abstractmethod
than also it will execute fine as it doesn't contain any abstract method

If class extending ABC class and contains atleast one abstract method, then object creation is not possible
'''
