from abc import *
class DBInterface(ABC):
    @abstractmethod
    def connect(self):
        pass

    @abstractmethod
    def disconnect(self):
        pass

class Oracle(DBInterface):
    def connect(self):
        print('Connecting to Oracle DB')
    def disconnect(self):
        print('Disconnecting to Oracle DB')

class MySql(DBInterface):
    def connect(self):
        print('Connecting to MySql DB')
    def disconnect(self):
        print('Disconnecting to MySql DB')

class Sybase(DBInterface):
    def connect(self):
        print('Connecting to Sybase DB')
    def disconnect(self):
        print('Disconnecting to Sybase DB')

dbname=input('Enter Database name:')
classname=globals()[dbname]  #inbuilt function globals() converts string to class name and return class name
x=classname()
x.connect()
x.disconnect()

'''
globals() will provide the dictionary values and its key is [dbname]
'''


