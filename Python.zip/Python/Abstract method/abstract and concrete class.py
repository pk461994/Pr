from abc import *

class CollegeAutomation(ABC):    #Interface as nothing to do with implementation part
#For CollegeAutomation class we can't create object as it extends ABC class and has at least one abstractmethod
    @abstractmethod
    def m1(self): pass
    @abstractmethod
    def m2(self): pass
    @abstractmethod
    def m3(self): pass

class ImplementationClass(CollegeAutomation): #Abstract class only partial implementation as m3 is absent. So 1 abstract method m3()
    def m1(self):
        print('m1 implementation')
    def m2(self):
        print('m2 implementation')

class ConcreteClass(ImplementationClass):   #Concrete class as filly inplemented as it contains all methods
    def m3(self):
        print('m3 implementation')

c=ConcreteClass()
c.m1()
c.m2()
c.m3()

'''
If we don't know anything about implementation just we have requirement specification. Then we should go for interface.
We are talking about implementation but not completely (Just partially implementation) then we should go for abstract class.
We are talking about implementation completely and ready to provide service, then we should go for concrete class.
'''
