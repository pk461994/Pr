from abc import *   #abc= abstract base class module
class Vehicle:
    @abstractmethod
    def getNoOfWheels(self):
        print('Abstract method')

class Bike(Vehicle):
    def getNoOfWheels(self):
        return 2

class Car(Vehicle):
    def getNoOfWheels(self):
        return 4

b=Bike()
print(b.getNoOfWheels())
c=Car()
print(c.getNoOfWheels())
