from abc import *
class Printer(ABC):
    @abstractmethod
    def printit(self,text):
        pass

    @abstractmethod
    def disconnect(self):
        pass

class EPSON:
    def printit(self,text):
        print('Printing from EPSON Printer')
        print(text)

    def disconnect(self):
        print('Disconnect to EPSON printer')

class HP:
    def printit(self,text):
        print('Printing from HP Printer')
        print(text)

    def disconnect(self):
        print('Disconnect to HP printer')

with open('config.txt','r') as f:
    pname=f.readline()

classname=globals()[pname]
x=classname()
print(classname)
x.printit('This is data to print')
x.disconnect()

'''
Here we have saved the EPSON in first line of config.txt file. So we're opening the file and reading the line by
pname=f.readline()
Than we're creating class name related to that EPSON by using globals().
globals() internally is a dictionary which will read string and return the classname after converting the string to classname 
Than we created object of classname()
Than finally we're printing some arguement
This is how we read the text from a file
'''