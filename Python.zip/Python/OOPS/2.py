class Student:
    '''This is Student class with required data'''   #This is doc string under ''' '''  We can also print it
    def __init__(self,x,y,z):     #__init__ is constructor
        self.name=x
        self.rollno=y
        self.marks=z
    def display(self):
        print('Student name: {}, Roll no: {}, Marks: {}'.format(self.name,self.rollno,self.marks))

s1=Student('Prashant',100,100)      #Creating Student class object with s1
print(s1.__doc__)                   #Printing doc string
s1.display()                        #calling display()
print()
#print(s1.name,s1.rollno,s1.marks)  #By using s1 we're accessing object properties

s2=Student('Aish',100,100)
print(s2.__doc__)
s2.display()
print()
#print(s2.name,s2.rollno,s2.marks)

s3=Student('Sharu',100,100)
print(s3.__doc__)
s3.display()

help(Student)   #Special syntax instead of using doc string

'''
__init__ is the constructor and self should be there. Constructor is used to perform initialization of object.
Constructor wil automatically execute whenever we're creating object. Per object constructor will be executed only once
Initialization of object means providing values for the instance variables like self.name, self.rollno, self.marks
Instance variables are nothing but object related variables
Whenever we're creating an object automatically constructor by default will be executed
self is not reserved words
We can use anything in place of self

We took .formatself.name,self.rollno,self.marks) but not simply .format(name,rollno,marks) bs if it is instance variable,
object related variable within the class compulsory we need to use self like self.name
'''
