#Printing object

class Student:
    def __init__(self,name,rollno):
        self.name=name
        self.rollno=rollno
    def __str__(self):
        return 'This is student with name: {} and Rollno: {}'.format(self.name,self.rollno)
s1=Student('Prashant',101)
s2=Student('Aishwarya',201)
print(s1)
print(s2)