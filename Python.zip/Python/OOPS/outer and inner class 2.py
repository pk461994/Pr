class Human:
    def __init__(self):
        self.name='Sunny'
        self.head=self.Head()
        self.brain=self.Brain()

    def display(self):
        print('Hello',self.name)

    class Head:
        def talk(self):
            print('Talking....')

    class Brain:
        def think(self):
            print('Thinking....')
        
h=Human()
h.display()
h.head.talk()   #Calling Head class i.e, inner class talk() method directly
h.brain.think()
print()
Human().Head().talk()    #This is not needed as head object is already created. No need to created it again by calling Head()
Human().Brain().think()  #This is not needed as brain object is already created. No need to created it again by calling Brain()
print()
Human().head.talk()
Human().brain.think()
