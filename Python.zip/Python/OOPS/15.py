class Employee:
    def __init__(self,eno,ename,esal):
        self.eno=eno
        self.ename=ename
        self.esal=esal

    def display(self):
        print('Employee number:',self.eno)
        print('Employee name:',self.ename)
        print('Employee salary:',self.esal)

#Now we need to modify the salary

class Modify:
    def modify(self):
        self.esal=self.esal+10000000   #Updating the salary
        self.display()                 #Once updated display the content

e=Employee(100,'Prashant',10000000)   #Creating employee object
Modify.modify(e)                      #Calling modify method. We're passing employee object as arguement

'''
One class method we can access inside another class
Just like we're accessing display() method from class Employee from class Modify
We can pass member of one class to the another class without any issue
As we passed Employee object as an arguement to Modify class

We're calling the method modify() by using class name.
So we can only call classmethod and static method by using class name
If it is instance method we need to call by 'object reference' or by using 'self' only not by class name
'''

