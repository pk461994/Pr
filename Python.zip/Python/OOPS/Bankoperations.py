import sys
class Customer:
    bankname = 'ABC Bank'               #Static variable. As bank name will be same for each customer
    def __init__(self,name,balance=0.0):
        self.name=name
        self.balance=balance

    def deposit(self,amount):
        self.balance=self.balance+amount
        print('Balance after deposit: ',self.balance)

    def withdraw(self,amount):
        if amount>self.balance:
            print('Insufficient balance, Cannot perform withdraw operation')
            sys.exit()                      #Will stop the execution of program bz balance is not there
        self.balance=self.balance-amount    #No need of else as if amount is less than balance it'll execute further
        print('Balance after withdraw: ',self.balance)

print('Welcome To',Customer.bankname)  #We can access static variable by class name only i.e, Customer
name=input('Enter your name:')
c=Customer(name)   #We're passing name as arguement so that we can create object for the name we enter

while True:
    print('d,D-Deposit\nw,W-Withdraw\ne,E-exit')
    option=input('Choose your option: ')

    if option=='d' or option=='D':
        amount=float(input('Enter amount: '))
        c.deposit(amount)

    elif option=='w' or option=='W':
        amount=float(input('Enter amount: '))
        c.withdraw(amount)

    elif option=='e' or option=='E':
        print('Thanks for banking with us!')
        sys.exit()                              #Will stop the execution of program

    else:
        print('Invalid Option, please choose from valid options only')
