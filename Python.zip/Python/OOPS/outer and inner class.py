class Outer:
    def m1(self):
        print('This is outer class method')
    class Inner:
        def m2(self):
            print('This is inner class method')

o=Outer()   #Creating outer class object
o.m1()      #Accessing outer class instance method m1() by object reference
'''
i=Inner()
We can't call inner class directly just like we did with outer class. It'll throw NameError
Now if we want to create inner class object first we need to be ready with outer class object
'''

i=o.Inner()  # o is outer class object. Referring outer class object with o.Inner(). Calling inner class method directly
i.m2()

i=Outer().Inner()   #To call inner class method directly
i.m2()

i=Outer().Inner().m2()   #To call inner class method directly

'''
We can also take like below if we want to access inner class object directly

i=Outer().Inner()
i.m2()

or

i=Outer().Inner().m2()

'''
