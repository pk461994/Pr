class Test:
    a=10    #Static variable. Class level variable. One copy will be created and shared by all objects in class
    def __init__(self):
        self.b=20      #b is instance variable
        Test.b=30      #Accessing static variable inside constructor by using class name
    def m1(self):
        self.d=40
        Test.e=50     #Accessing static variable inside instance method by using class name
    @classmethod
    def m2(cls):      #cls means pointing to current class. We can take anything in place of cls
        cls.f=60      #Declaring static variable inside classmethod by using cls variable or class name
        Test.g=70
    @staticmethod
    def m3():
        Test.h=80     #Declaring static variable inside static method by using class name
Test.m2()
Test.m3()             #We need to call methods to access the variables within
Test.i=90             #Declaring static variable outside class by using class name

t1=Test()
t2=Test()
t1.m1()
t2.m1()
t1.m2()
t2.m2()
t1.m3()
t2.m3()
print(t1.a,t1.b,sep=',')  #Static variable can be accessed by using reference variable like t.a
print(Test.a,t2.b,sep=',') #Static variable can be accessed by using class name also like Test.a

print('t1:',t1.a,t1.b)
print('t2:',t2.a,t2.b)

Test.a=888  #Changing value of static variable from 10 to 888
t1.b=999
print(Test.b)
print('t1 after editing:',t1.a,t1.b)
print('t2 after editing:',t2.a,t2.b)
print(Test.__dict__) #To know every infos about static variable inside a class

print(t1.a,t1.e,t1.f,t1.g,t1.h,t1.i)  #Accessing static variables by object reference
print(Test.a,Test.e,Test.f,Test.g,Test.h,Test.i)  #Accessing static variables by class name
'''
We changed the value of a from 10 to 888 i.e, static variable. So only once copy is there
So after changing a will come as 888 for both objects t1 and t2
We changed b value from 20 to 999 for t1 object so the value of b in t1 only will change not for t2  
'''

