#Modify static variable. Either by using class name or by cls variable if it is classmethod.

class Test:
    a=10
    def __init__(self):
        self.b=20
t1=Test()
t2=Test()
t1.a=888
t1.b=999
print(t1.a,t1.b)
print(t2.a,t2.b)
print(t1.__dict__) #t1 contains only 1 instance variable
print(t2.__dict__) #t2 contains only 1 instance variable
t2.a+=1        #The value will be t2=10+1=11.
# As this is write operation as final value 11 will be assigned as a separate instance variable
#  Than instance variable will be created for t2
print(t2.a)
print(Test.a)  #This is the class variable i.e, static variable
print(t1.a)    #This will also access the static variable i.e, class level variable
print(t1.__dict__)
print(t2.__dict__)
'''
We cannot use reference variable or self keyword to modify static variable.
If we use object reference or self keyword. 
Than the static variable won't be modified. A new instance variable will be created for that object
Just like for t1, separate new instance variable a=888 will be added
So in this case a=888 is new instance variable for t1 not the static variable for all methods
And b value is 20 and we're re-assigning it to 888 So the b value for t1 will be 999
So a new instance variable will be added to t1 only. It'll not modify the static variable i.e, a=10 
'''