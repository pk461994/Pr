class Employee:
    def __init__(self,eno,ename):
        self.eno=eno
        self.ename=ename
        print('Constructor execution')
        print()
    def display(self):
        print('Employee No:',self.eno)
        print('Employee Name:',self.ename)
        print()
e1=Employee(100,'Prashant')  #Creating object. e1 is reference variable pointing to that object
print(e1.__dict__)  #To know how many instance variable are for e1 programatically
e2=Employee(200,'Aish')
print(e2.__dict__)  #To know how many instance variable are for e1 programatically
e1.display()            #Calling display method by using reference variable
e2.display()
print(e1.eno,e1.ename,sep=',') #Accessing instance variables outside of class by using reference variable
print(e2.eno,e2.ename,sep=',')

