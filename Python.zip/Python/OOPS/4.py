class Test:
    def __init__(self):
        print('constrtuctor execution started...')
    def m1(self):
        print('method execution started...')
t1=Test()   #If we crete an object the constructor will also execute. Per object only once constructor will be executed
t2=Test()
t3=Test()
t4=Test()
t1.m1()    #If we call a method than only it'll be executed
