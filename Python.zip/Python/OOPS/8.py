class Test:
    def __init__(self):
        self.a=1000
        self.b=2000
        self.e=5000
    def m1(self):
        self.c=3000
        self.d=4000
t1=Test()
print(t1.__dict__)   #2 variables are available i.e, of constructor
t1.m1()
print(t1.__dict__)  #4 variables are now available, 2 from constructor and 2 from m1()
print(t1.a,t1.b,t1.c,t1.d) #Accessing instance variables outside of class by using reference variable
del t1.e            #To delete instance variable we use del objectreference.variablename
print(t1.__dict__)

'''
To know how many instance variable are for t1 and t2 reference varibales programatically
we're using t1.__dict__ and t2.__dict__    iT'll provide output in dict style like in Key:value pairs

print(t1.a,t1.b,t1.c,t1.d)
To use above we need to call m1 like t1.m1() method as we can't get c and d value without calling m1()
We'll only have a and b as it is constructor and will be called whenever object is created
But to access method() we need to call it
If we're not calling instance variable related to that method will not be come in picture
'''