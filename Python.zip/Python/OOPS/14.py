class Test:
    a=10
    e=30
    def __init__(self):
        self.b=20
    @classmethod
    def m1(cls):
        cls.a=888   #a and b are class level variables not object level. Will be added as static variable
        cls.b=999
        del cls.e  #To delete static variable we use del followed by using cls or class name

t1=Test()
t2=Test()
t1.m1()
print(t1.a,t1.b)
print(t2.a,t2.b)
print(Test.a,Test.b)
print(t1.__dict__)
print(t2.__dict__)
print(Test.__dict__)