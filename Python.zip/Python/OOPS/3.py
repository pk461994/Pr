class Student:
    def __init__(self):         #Constructor method. self should be the first arguement
        self.name='Prashant'
        self.rollno=101
        self.marks=100

    def talk(self):    #Object related method. Object related method is instance method
        print('Hello my name is:',self.name)
        print('My roll no is:',self.rollno)
        print('My marks are',self.marks)
s1=Student()   #Creating object with reference variable s1
print(s1.name)        #By using reference variable we can access the properties of Student class
print(s1.rollno)
print(s1.marks)
s1.talk()

'''
We can access instance variable outside the class by using reference variables
Just like we did
s1.name, s1.rollno and s1.marks
'''
