class Person:
    def __init__(self):
        print('Person class constructor!')
        self.name='Prashant'
        self.dob=self.Dob()  #Whenever we call Person object it'll automatically call Dob(). Means Date of birth Dob() object will be created

    def display(self):
        print('Name:',self.name)

    class Dob:               #Without existing person object there is no chance of existing Dob
        def __init__(self):
            print('Dob class constructor!')
            self.dd=4
            self.mm=6
            self.yy=1994
        def display(self):
            print('Date of Birth={}/{}/{}'.format(self.dd,self.mm,self.yy))

p=Person()
p.display()    #Will execute Person class display() method only
p.dob.display()

'''
p.dob.display()
We're not required to create Dob() object again
Because Dob() object is already created
self.dob=self.Dob()
It is created by using dob variable it is associated to Dob()
p.dob means Dob() object
Dob() dobject display() method is nothing but
def display(self):
            print('Date of Birth={}/{}/{}'.format(self.dd,self.mm,self.yy))

So, it'll call the inner class i.e, Dob display() method directly no need to create object in this case
'''
            
