class Student:
    def read(self): #read is instance method. It has to take one mendatory arguement i.e, self
        print('Reading Python')
s=Student()  
s.read()     #Calling the method. We're calling the functionality of read() method by the object. We can call multiple times if required



'''
We can use anything in palce of self but convention is like this and we use self only. self is not mendatory

s=Student()  #Created student object. We're not passing anything to constructor so constructor by default will be generated in calss by python.
As we don't have instance variable. If we have instance variable for students than constructor concept will come in picture

read(self)     self is the arguement to read to refer current object. self is not external arguement
at the time of calling we're not required to pass self as arguement so we wrote like
Internally self means current object only
s.read() to call it
If we took like def read(self,a,b,c) than while calling the statement should be
s.read(a,b,c)

If we define any function inside a class it is considered as method. It is function only but considered as method generally 
'''
