class Test:
    a=10
    def __init__(self):
        self.b=20
t1=Test()
t2=Test()
t1.a=t1.a+1
t2.b=t2.b+1
print('t1:',t1.a,t1.b)
print('t2:',t2.a,t2.b)
print('Test:',Test.a)
print(t1.__dict__) #To know instance variables of t1
print(t2.__dict__) #To know instance variables of t2
