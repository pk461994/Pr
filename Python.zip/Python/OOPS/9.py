class Test():
    def __init__(self):
        self.a=1000
        self.b=2000
    def m1(self):
        self.c=3000
        self.d=4000
t1=Test()
t1.m1()
print(t1.__dict__)
t2=Test()
t2.a=5555
t2.b=6666
t2.c=7777
t2.d=8888
t2.e=9999
t2.f=7879787
print(t2.__dict__)

'''
We're creating t2 object where we're changing the instance varibale values for the t2 object only
As we're not calling m1() method via t2. So c and d values are absent for t2
So if we add c,d,e,f instance variables outside of a class like we did t2.c=7777
t2.d=8888 and so on
So c,d,e,f instance variables will be added for t2 reference variable only not for t1 or any other object
'''
