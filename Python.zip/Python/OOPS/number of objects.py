class Test:
    count=0                 #static variable
    def __init__(self):
        Test.count += 1         #To increment count value
    @classmethod                #Inside the method we're acessing class data so this is classmethod
    def noofObjects(cls):
        print('The number of objects created:',cls.count)
t1=Test()
t2=Test()
Test.noofObjects()

t3=Test()
t4=Test()
t5=Test()
Test.noofObjects()
t5.noofObjects()   #We can access classmethods by using Class name (Test) and object reference (t5,etc) also

