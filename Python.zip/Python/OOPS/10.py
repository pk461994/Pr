#Deleting instance variables

class Test():
    def __init__(self):
        self.a=10
        self.b=20
        self.c=30
        self.d=40
t1=Test()
t2=Test()
print('t1:',t1.__dict__)
del t1.c  #del is used to delete instance variable.
del t1.d
print('After deleting t1:',t1.__dict__)
print('t2:',t2.__dict__)
