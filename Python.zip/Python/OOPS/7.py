class Test:
    def __init__(self):
        self.x=10

t1=Test()
t2=Test()
print(t1.x,t2.x)
t1.x=888   #Changing x value as 888
print(t1.x,t2.x)


'''
By using one object reference if we perform any change to the instance variables, the change won't be 
effected to remaining objects as for each instance variable a separate copy will be created
'''