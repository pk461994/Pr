class Student:
    def __init__(self,n='',m=0):  #we didn't pass anything as n so No name will come. If we pass name like n='abc' it'll show
        self.name=n
        self.marks=m
    def display(self):
        print('Hi',self.name)
        print('Marks:',self.marks)

s1=Student()
s1.display()

s2=Student('Sunny',100)
s2.display()
