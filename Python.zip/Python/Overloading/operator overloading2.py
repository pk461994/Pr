# overload * operators for Employee objects

class Employee:
    def __init__(self,name,salary):
        self.name=name
        self.salary=salary

    def __mul__(self,other):
        return self.salary * other.days   #self refers to e and other refers to t. self for current object i.e, e and other for t

class Timesheet:
    def __init__(self,name,days):
        self.name=name
        self.days=days

    def __mul__(self,other):
        return self.days * other.salary   #self refers to t and other refers to e. self for current object i.e, t and other for e

e=Employee('Prashant',25000)
t=Timesheet('Prashant',25)

print('This month salary:',e*t)

'''
Suppose we override * in only Employee class like we take def __mul__(self,other): only within Employee class not in Timesheet class
Than the order is important while printing, like in
print('This month salary:',e*t)
we need to take e*t not t*e. Because if we take t*e it'll first search * in Timesheet class ans if it is not there it'll throw:
TypeError: unsupported operand type(s) for *: 'Timesheet' and 'Employee'

So to avoid this issue we take * in each classes so that we can use both e*t and t*e while printing
'''
