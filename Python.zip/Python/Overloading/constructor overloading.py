class Test:
    def __init__(self):
        print('No-arg method')

    def __init__(self,a):
        self.a=a
        print('One-arg method')

    def __init__(self,a,b):
        self.a=a
        self.b=b
        print('Two-arg method')

t=Test(10,20)
print(t.a,t.b)

'''
python does not supports constructor overloading.
We may overload the constructor but can only use the latest defined constructor.
Which in this case it is def __init__(self,a,b):
Like all the constructors within Test class having same name

Initially one method was there __init__(self):
Than we defined new one __init__(self,a): Than __init__(self) will be deleted
Than we defined new one __init__(self,a,b). Than __init__(self,a) will be deleted

def __init__(self,a,b):
It reuires 2 positional arguement So we passed t=Test(10,20)
'''
