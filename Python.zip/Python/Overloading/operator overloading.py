class Book:
    def __init__(self,pages):
        self.pages=pages
    def __add__(self,other):
        return self.pages+other.pages
    def __lt__(self,other):
        return self.pages<other.pages
    def __ge__(self,other):
        return other.pages>=self.pages

b1=Book(500)
b2=Book(600)
print('The total number of pages is:',b1+b2)
print('b1<b2:',b1<b2)
print('b2>=b1',b2>=b1)

'''
Here in def __add__(self,other)
self means b1 so we need to take other for b2

+ operator can be used for numbers, strings, or anything like we used for book
'''