# variable number of arguements

class Sum:
    def sum(self,*n):
        total=0
        for number in n:
            total=total+number
        print('The sum is:',total)
s=Sum()
s.sum()
s.sum(10,20,30,40)
s.sum(10,20)
