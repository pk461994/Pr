# overload > and >= oeprators for Student objects

class Student:
    def __init__(self,name,marks):
        self.name=name
        self.marks=marks

    def __gt__(self,other):
        return self.marks>other.marks

    def __le__(self,other):
        return self.marks<=other.marks

s1=Student('Prashant',98)
s2=Student('Aish',99)
print('s1>s2:',s1>s2)
print('s1<=s2:',s1<=s2)
