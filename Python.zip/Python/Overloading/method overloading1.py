#With default arguements

class Sum:
    def sum(self,a=None,b=None,c=None):

        if a!= None and b!= None and c!= None:  #We're passing 3 values a,b,c
            print('The sum of 3 values is:',a+b+c)

        elif a!=None and b!=None:
            print('The sum of 2 values is',a+b)

        else:
            print('Please pass 2 or 3 values only')

s=Sum()
s.sum(10,20)
s.sum(10,20,30)
s.sum()
s.sum(10)

'''
He we wanted either 2 arguements or 3 arguements
If we want variable number of arguements we can take like
def sum(self,*a):

We took a=None,b=None,c=None not a=0, b=0, c=0
Because while creating sum object if we pass values like s.sum(0,0,0)
Than the if statement fails bz a!=0 doesn't meet requirement
'''
