class Test:
    def m1(self):
        print('No-arg method')

    def m1(self,a):
        self.a=a
        print('One-arg method')

    def m1(self,a,b):
        self.a=a
        self.b=b
        print('Two-arg method')
t=Test()
t.m1(10,20)
print(t.a,t.b)

'''
python does not supports method overloading.
We may overload the methods but can only use the latest defined method.
Which in this case it is def m1(self,a,b):
Like all the methods within Test class having same name as m1()

Initially one method was there m1(self)
Than we defined new one m1(self,a). Than m1(self) will be deleted
Than we defined new one m1(self,a,b). Than m1(self,a) will be deleted

def m1(self,a,b):
It reuires 2 positional arguement So we passed t.m1(10,20)
'''
