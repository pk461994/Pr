words='the quick brown fox jumps over the lazy dog'.split()
print(words)
l=[[w.upper(),len(w)] for w in words]
print(l)

#w.upper() for converting all to Upper case
#len(w) for the length of each w in words

#Output:
#['the', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']
#[['THE', 3], ['QUICK', 5], ['BROWN', 5], ['FOX', 3], ['JUMPS', 5], ['OVER', 4], ['THE', 3], ['LAZY', 4], ['DOG', 3]]
