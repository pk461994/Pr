square=lambda n:n*n
print('The square of {} is {}'.format(4,square(4)))
print('The square of {} is {}'.format(5,square(5)))


#The square of 4 is 16
#The square of 5 is 25
