name=''
password=''
while name!='pk' or password!='jha':
    name=input("Enter name:")
    password=input('Enter password:')
print("Thanks for confirmation!")
