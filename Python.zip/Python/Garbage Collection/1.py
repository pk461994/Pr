import gc     #gc is the module name for garbage collector
print(gc.isenabled())   #By default garbage collector is enabled only so it'll return true

gc.disable()            #Disabling garbage collector
print(gc.isenabled())

gc.enable()             #Enabling garbage collector
print(gc.isenabled())

