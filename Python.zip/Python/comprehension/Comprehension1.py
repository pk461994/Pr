#Print Square root from 1 to 20 in a list and Print Even Results as well.

l1=[x*x for x in range(1,21)]                   #By using Comprehension
l2=[x for x in l1 if x%2==0]                    #For Even results from l1
l3=[2**x for x in range(1,11)]                  #2**x means 2 to power x
l4=[x**2 for x in range(1,21) if (x**2)%2==0]
l5=[x**2 for x in range(1,21) if (x**2)%2!=0]
words=['Prashant','Aishwarya','Jha','Sharma']
l6=[w[0] for w in words]                        #To read only first character
l7=[w for w in words if len(w)>3]               #For words having more than 3 letters in words
print(l1)
print(l2)
print(l3)       #[2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
print(l4)
print(l5)
print(l6)
print(l7)
n1=[10,20,30,40]
n2=[30,40,50,60]
n3=[x for x in n1 if x not in n2]               #To get values present in n1 but not in n2
print(n3)

#list=[expression for x in sequence]                   Eg-l1
#list=[expression for x in sequence if condition]      Eg-l2
# * means multiplication and ** means to the power. Like 2**3=2*2*2=8

#Output
#[1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289, 324, 361, 400]
#[4, 16, 36, 64, 100, 144, 196, 256, 324, 400]
#[2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
#[4, 16, 36, 64, 100, 144, 196, 256, 324, 400]
#[1, 9, 25, 49, 81, 121, 169, 225, 289, 361]
#['P', 'A', 'J', 'S']
#['Prashant', 'Aishwarya', 'Sharma']
#[10, 20]
