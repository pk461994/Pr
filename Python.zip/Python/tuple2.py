#WAP to take a tuple of numbers and print sum, average
t=eval(input('Enter some tuple of numbers:'))
print(type(t))
l=len(t)
sum=0
for x in t:
    sum=sum+x
print('The Sum is:',sum)
print('The Average is:',sum/l)


#Output:-
#Enter some tuple of numbers:10,20,30,40,50
#<class 'tuple'>
#The Sum is: 150
#The Average is: 30.0
