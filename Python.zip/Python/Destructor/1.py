import time, sys
class Test:
    def __init__(self):                     #Constructor
        print('Constructor Execution')

    def __del__(self):                      #Destructor
        print('Destructor Execution')
t1=Test()
t2=t1
t3=t2
print(sys.getrefcount(t1))  #sys.getrefcount is to know number of references to object
del t1
time.sleep(5)
print('Object not yet destroyed after deleting t1')
del t2
time.sleep(5)
print('Object not yet destroyed after deleting t2')

print('Delete t3 also')
del t3

'''
When all the reference variables associated with an object will be deleted than only the object will
be eligible for the garbage collection
Just like we deleted t1 at first bu the object will not be deleted bz t2 and t3 still pointing to object
Sae is when we deleted t2 still t3 is there.
Once we deleted t3 than garbage collector will delete the object

print(sys.getrefcount(t1)) will give output as 4 but we have created 3 objects only
This is so because, for every object python will maintain one implicit variable to refer current object
That implicit variable is nothing but self. It'll be maintained internally
'''