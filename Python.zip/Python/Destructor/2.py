import time
class Test:
    def __init__(self):
        print('Constructor Execution')

    def __del__(self):
        print('Destructor Execution')

l1=[Test(),Test(),Test()]   #Creating multiple Test() object
time.sleep(5)
del l1   #Here all the objects will be eligible for garbage collection
print('End of application')