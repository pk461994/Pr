a0=dict(zip(('a','b','c','d','e'),(1,2,3,4,5)))
a1=range(10)
a2=sorted([i for i in a1 if i in a0])
a3=sorted([a0[s] for s in a0])
a4=[i for i in a1 if i in a3]
a5={i:i*i for i in a1}
a6=[[i,i*i] for i in a1]
print (a0,"\n",a1,"\n",a2,"\n",a3,"\n","\n",a4,"\n",a6)