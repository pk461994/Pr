numbers=[10,20,0,5,0,30]
for n in numbers:
    if n==0:
        print('We cannot divide by zero')
        continue
    print('100/{}={}'.format(n,100/n))  #n value will be evaluated for 100/{} and 100/n is for {}
