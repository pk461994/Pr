>>> s1={10,20,30,40}
>>> s2={30,40,50,60}
>>> print(s1.symmetric_difference(s2))  #To know elements present in s1 and not in s2 and vice-versa(Excluding common elemets)
{10, 50, 20, 60}
>>> print(s1^s2)                        #To know elements present in s1 and not in s2 and vice-versa(Excluding common elemets)
{10, 50, 20, 60}
