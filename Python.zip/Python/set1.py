>>> s=set()
>>> s.add('Python')
>>> s
{'Python'}
>>> s=set()         #To create empty set
>>> s.add(10)       #To add one element at one time we use .add()
>>> s.add(20)       #More than 1 arguement is not allwoed in set using .add()
>>> s.add(30)
>>> s.add(40)
>>> s
{40, 10, 20, 30}
>>> l=[50,60,70,80]
>>> s.update(l) #To add group of element at one time we use .update() Any no of arguements we are allowed to pass using update
>>> s
{70, 40, 10, 80, 50, 20, 60, 30}
>>> x={11,21,31}        #set
>>> y=[12,22,32]        #list
>>> z=(13,23,33)        #tuple
>>> s.update(x,y,z)     #Any no of arguements we are allowed to pass using .update()
>>> s
{32, 33, 70, 40, 10, 11, 12, 13, 80, 50, 20, 21, 22, 23, 60, 30, 31}
>>> s.update(range(111,131,2),'Durga') #We can add range function as well as string object. Sequence will be changed
>>> s
{129, 10, 11, 12, 13, 20, 21, 22, 23, 30, 31, 32, 33, 'g', 40, 'r', 50, 60, 70, 80, 'a', 'u', 'D', 111, 113, 115, 117, 119, 121, 123, 125, 127}
>>> s.update(555)       #update() method will only take a sequence but not single value
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    s.update(555)
TypeError: 'int' object is not iterable
>>> s.update(555,666,777) #Bz we need to take values as sequence like s.update([555,666,777]) or s.update((555,666,777))
Traceback (most recent call last):
  File "<pyshell#22>", line 1, in <module>
    s.update(555,666,777)
TypeError: 'int' object is not iterable

>>> s={1,2,3,4}
>>> s1=s            #Alias
>>> id(s)==id(s1)   #Aliasing so id of s and s1 are same
True
>>> s2=s.copy()     #Clone
>>> id(s)==id(s2)   #Cloning so id is different but value will be same. Different copy is created pointing to same object
False
>>> s2
{1, 2, 3, 4}

>>> s={10,20,30,40,50}
>>> s[0]                #indexing is not alloed in set as order is not preserved
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    s[0]
TypeError: 'set' object does not support indexing
>>> s[0:4]              #slicing is not allowed as order is not preserved
Traceback (most recent call last):
  File "<pyshell#40>", line 1, in <module>
    s[0:4]
TypeError: 'set' object is not subscriptable
