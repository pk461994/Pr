#Find the number of occurences of each character in a String

s=input('Enter some String:')
d={}        #dictionary means a group of key values
for x in s:
    if x not in d.keys():
        d[x]=1
    else:
        d[x]=d[x]+1
print(d)            #To print as a list
for k,v in d.items():       #k is key and v is value, d.items() means every item present in d
    print('{} occurs {} times'.format(k,v))


#Output:-
#Enter some String:abcdaaddbbbssaadd
#{'a': 5, 'b': 4, 'c': 1, 'd': 5, 's': 2}           Bz of print(d)
#a occurs 5 times                                   Bz of for loop
#b occurs 4 times
#c occurs 1 times
#d occurs 5 times
#s occurs 2 times


#Logic
#Like AABAB we took
#for x in s means first A will come. if x not in d.keys():     So its true as A is not in d. So, d[x]=1
#Means in dictionary, d, the x i.e, A will be added as the key and 1 will be its value
#Again for loop will continue for the value A. Already A is there so else part will execute which has d[x]=d[x]+1
#d[x]=1+1=2 So value will be 2 now for A. Means A came 2 times as of now. And again loop will continue
#Now B comes. for loop continues.  B is not there so key will be B and value will be 1.
