l=(x*x for x in range(10))
print(type(l))


'''Comprehension is not valid for tuple.
If we try comprehension for tuple, it becomes generator
Here we can use large numbers.
Bz the value will not be stored in memory before execution. So execution is faster
Generator generates a sequence of values at runtime based on requirement. Not storing in memory'''
