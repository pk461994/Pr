l=list(input('Enter some List:'))
x=len(l)
for i in range(x):
    print(l[i],'is present at positive index',i,'and at negative index',i-x)



#Output:
#Enter some List:ABCD
#A is present at positive index 0 and at negative index -4
#B is present at positive index 1 and at negative index -3
#C is present at positive index 2 and at negative index -2
#D is present at positive index 3 and at negative index -1
