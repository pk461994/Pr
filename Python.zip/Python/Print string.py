name=input('Enter a Name:')
age=int(input('Enter the age:'))
salary=float(input('Enter the Salary per month:'))
print()         #Empty print statement will act as an empty line b/w 2 lines
print(name,"Age is",age,'and the earning per month is',salary)
print()
print("{}'s age is {} and the earning per month is {}".format(name,age,salary))
print()         
print("{0}'s age is {1} and the earning per month is {2}".format(name,age,salary))
print()
print("{x}'s age is {y} and the earning per month is {z}".format(x=name,y=age,z=salary))   #In this case order is not important
print()
print("{z}'s age is {x} and the earning per month is {y}".format(z=name,x=age,y=salary))   #Not compulsory to take x, y or z 
#We can assign any value to x, y or z or any valid identifiers. We can take any valid identifier in {} like a,b,c,l,m or anything
#But it will print in the order given in " "
#First {} will point to name, second{} will point to age and third {} points to salary
