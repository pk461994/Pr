#Multithreading without using a class

from threading import *
def display():
    for i in range(10):
        print('Child Thread')
t=Thread(target=display)
t.start()
for i in range(10):
    print('Main Thread')

'''
When we have multiple independent jobs than we have to go for multithreading 
So output may come in any order as threads or jobs are independent from each-other
If we need specific order we need not to go for multithreading concept
'''