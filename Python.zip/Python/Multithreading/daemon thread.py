from threading import *
def job():
    print('Child thread...')

t=Thread(target=job) #main thread is the parent and t is the chid
print(t.daemon)      #To know whether t is Daemon or non-Daemon
print(t.isDaemon())  #To know whether t is Daemon or non-Daemon
t.setDaemon(True)  #Now onwards t is Daemon thread. We can set it as daemon bs the child thread hasn't started bz we didn't use t.start()
print(t.daemon)

'''
We can change to daemon and non-daemon by using setDaemon() method
By default Main thread is non-daemon only
Main created child thread so child is also non-Daemon. As child thread will inherit from Parent thread
Than we changed it to Daemon by using setDaemon() method
'''

