from threading import *
import time
l=Lock()
def wish(name):
    l.acquire()
    try:
        for i in range(5):
            print('Good evening:',flush=True,end=' ')
            time.sleep(3)
            print(name)
    finally:
        l.release()

t1=Thread(target=wish,args=('Prashant',))
t2=Thread(target=wish,args=('Aishwarya',))
t3=Thread(target=wish,args=('Rekha',))
t1.start()
t2.start()
'''
It is highly recommended to write code of releasing locks inside finally block.The advantage is lock
will be released always whether exception raised or not raised and whether handled or not
handled. Logic to use:-
l=threading.Lock()
l.acquire()
try:
perform required safe operations
finally:
l.release()
'''