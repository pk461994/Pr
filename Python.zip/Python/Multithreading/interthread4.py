#Interthread communication by using Queue
from threading import *
import time
import random
import queue
def produce(q):
    while True:         #Continuous activity so it is infinite loop
        item=random.randint(1,100)   #Randomly generate no between 1 to 100
        print('Producer producing items:',item)
        q.put(item)
        print('Producer giving notification...')
        time.sleep(5)

def consume(q):
    while True:         #Continuous activity so it is infinite loop
        print('Consumer waiting for updation')
        print('Consumer consuming item:',q.get())
        time.sleep(5)

q=queue.Queue()   #Creating queue object
t1=Thread(target=consume,args=(q,)) #args=(q,) represents a tuple with a single item list
t2=Thread(target=produce,args=(q,))
t1.start()
t2.start()
'''
1. put(): Put an item into the queue.
2. get(): Remove and return an item from the queue.

We called consumer so it'll print  'Consumer waiting for updation'
and when it executed get() method and as the queue is empty so
it'll go into waiting state. So, print('Consumer consuming item:',q.get())   not printed
Now producer gets chance and print  Producer producing items:
Once he produces he's giving the notification by put()
Here we need not to create any list, tuple,dict etc bz Queue itself is data structure we can add directly
It is provided from Queue module
Consumer is waiting at q.get(). Whenever we call get() method if the queue is empty than thread will wait
Once producer adds q.put(item)method will send the notification than get() method will be executed
put() and get() methods internally contains all the functions like notify and all
Threads are sharing the same queue
'''