from threading import *
import time
l=Lock()   #Creating Lock object
def wish(name):
    with l:
        for i in range(5):
            print('Good evening:',flush=True,end=' ')
            time.sleep(3)
            print(name)

t1=Thread(target=wish,args=('Prashant',))
t2=Thread(target=wish,args=('Aishwarya',))
t3=Thread(target=wish,args=('Rekha',))
t1.start()
t2.start()
'''
It is highly recommended to acquire lock by using with statement. The main advantage of with
statement is the lock will be released automatically once control reaches end of with block and we
are not required to release explicitly.

This is exactly same as usage of with statement for files.
with open('demo.txt','w') as f:
f.write("Hello...")

Here we need not to close the file by f.close()
'''