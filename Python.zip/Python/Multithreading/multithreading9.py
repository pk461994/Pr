from threading import *
import time
def display():
    print(current_thread().name,'started....') #We can use getname or name
    time.sleep(3)
    print(current_thread().name,'ended....')

print('The number of active threads:',active_count())   #1 thread

t1=Thread(target=display,name='Child Thread 1')
t2=Thread(target=display,name='Child Thread 2')
t3=Thread(target=display,name='Child Thread 3')
t1.start()
t2.start()
t3.start()
print(t1.name,' is alive:',t1.isAlive())
print(t2.name,' is alive:',t2.isAlive())
print(t3.name,' is alive:',t3.isAlive())

print('The number of active threads:',active_count())   #4 no of threads one main and 3 child threads

l=enumerate()    #enumerate will provide list of all active threads
for thread in l:
    print('Name:',thread.name)

time.sleep(10)

l=enumerate()
for thread in l:
    print('After 10 seconds sleep, Name:',thread.name)

print('The number of active threads:',active_count())   #1 thread

'''
active_count() is a function to know the active threads. It's function bz we're not calling it on any object
enumerate() function will provide list of all active threads. It's function bz we're not calling it on any object
isAlive() is a method used to know whether thread is alive or dead. If returns True than its alive. Its a method as we're calling it with object like t1.isAlive()
'''


