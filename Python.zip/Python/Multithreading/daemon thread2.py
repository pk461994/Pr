from threading import *
import time
def job1():
    print('Child Thread 1....')
    print(current_thread().name,'is daemon?:',current_thread().daemon)
    t2 = Thread(target=job2, name='Child Thread 2')
    #Created by child Thread i.e, daemon thread as we have made it daemon by t.setDaemon(True)
    print('t2 is daemon:',t2.daemon)
    t2.start()   #Without starting Child Thread 2... will ot come as output

def job2():
    print('Child Thread 2...')

t1=Thread(target=job1,name='Child Thread')
t1.setDaemon(True)
t1.start()
time.sleep(3)
'''
By default only Main Thread is Daemon
Rest other nature will be inherited by parent
As t2 is Daemon
'''