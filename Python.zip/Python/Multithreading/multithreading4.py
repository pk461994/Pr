#Creating a thread without extending Thread class

from threading import *
class Test:  #MyThread is child class which is extending Thread class
    def display(self):  #self is reference variable to current object. Here run method is already there in Thread which is parent class. We're changing that run method in the clild class i.e, MyThread. This is overriding
        for i in range(5):
            print('Child Thread')
            print('Child Thread executed by:',current_thread().getName())
obj=Test() #Creating test object
t=Thread(target=obj.display)
t.start()
for i in range(5):
    print('Main Thread')
