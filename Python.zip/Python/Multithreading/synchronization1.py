from threading import *
import time
l=RLock()
def factorial(n):
    l.acquire()
    if n==0:
        result=1
    else:
        result=n*factorial(n-1)  #recussion. Inside funcion we're using same function
    l.release()
    return result

def results(n):
    print('The factorial of', n,'is:',factorial(n))

t1=Thread(target=results,args=(5,))
t2=Thread(target=results,args=(9,))
t1.start()
t2.start()

'''
t1 acquires lock() than it calls results with arguement 5
Than it goes to factorial(n) means factorail(5)
And as i has recurssion within, again and again factorial method will execue 5 times as the arguement is 5
It means thread is always asking for l.acquire whenever factorial method executes
In this type of scenario we need to take RLock() as same thread asks Lock() again and again without holding the execution
'''
