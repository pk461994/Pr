from threading import *
import time
e=Event()
def consumer():
    print('Consumer thread waiting for updating')  #Line 1
    e.wait()
    print('Consumer thread got notification and started consuming')  #Line 4
def producer():
    time.sleep(5)
    print('Producer thread producing items')        #Line 2
    print('Producer thread giving notification by setting event')  #Line 3
    e.set()

t1=Thread(target=producer)
t2=Thread(target=consumer)
t1.start()
t2.start()
'''
consumer has to wait until update is ready. So it called wait() on event object by e.wait()
It'll wait until producer gives notification
producer will give notification by e.set() Than consumer will start again
'''