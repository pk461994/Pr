#With using multithreading we're calculating time
import time
from threading import *
def doubles(numbers):
    for n in numbers:
        time.sleep(1)
        print('Double:',2*n)

def squares(numbers):
    for n in numbers:
        time.sleep(1)
        print('Square:',n*n)
numbers=[1,2,3,4,5,6]
begintime=time.time()
#doubles(numbers)
t1=Thread(target=doubles,args=(numbers,))  #numbers, is for tuple for single value so we put ,
#target is always expecting some method or function so we have passed doubles or squares. If we don't pass anything default target is always run method
t2=Thread(target=squares,args=(numbers,)) #In Thread class args variable is always expecting tuple so we're passing tuple as arguement
t1.start()
t2.start()
t1.join() #main Thread should wait until child chreads complete execution
t2.join()
endtime=time.time()
print('The total time taken:',endtime-begintime)
