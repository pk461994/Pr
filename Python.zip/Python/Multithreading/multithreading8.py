from threading import *
def display():
    print('Child thread....')

t=Thread(target=display)
t.start()
print('Main thread identification number:',current_thread().ident)
print('Child thread identification number:',t.ident)

'''
ident is a variable (not function so we didn't use ()) used to determine identification number
'''

