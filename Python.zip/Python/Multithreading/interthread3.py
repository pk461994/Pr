#Interthread communication by using Condition object
from threading import *
import time
import random
items=[]
def produce(c):         #c is the Condition object that we're passing in thread
    while True:         #Continuous activity so it is infinite loop
        c.acquire()
        item=random.randint(1,100)  #Randomly generate no between 1 to 100
        print('Producer producing the item:',item)
        items.append(item)   #Adding item produced in a list called items
        print('Producer giving notification...')
        c.notify()
        c.release()
        time.sleep(5)

def consume(c):
    while True:         #Continuous activity so it is infinite loop
        c.acquire()
        print('Consumer waiting for update...')
        c.wait()
        print('Consumer consuming item...',items.pop()) #helps to pop out elements from a set
        c.release()
        time.sleep(5)
c=Condition()       #Creading Condition object
t1=Thread(target=consume,args=(c,))  #args=(c,) represents a tuple with a single item list
t2=Thread(target=produce,args=(c,))
t1.start()
t2.start()

'''
pop() method removes a random element from the set and returns the removed element.
The return value is the popped element from the set. Like its returning from list, items[]
acquire() ->To acquire Condition object before producing or consuming items.i.e thread acquiring internal lock.
release()  To release Condition object after producing or consuming items. i.e thread releases
internal lock
wait()|wait(time)  To wait until getting Notification or time expired
notify()  To give notification for one waiting thread
notifyAll()  To give notification for all waiting threads
Threads are communicating via wait() and notify()
'''