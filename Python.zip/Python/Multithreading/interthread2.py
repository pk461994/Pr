#Interthread communication by using Condition object
from threading import *
def consume(c):   #c is the Condition object that we're passing in thread
    c.acquire()
    print('Consumer ordered and waiting for Pizza Token number...')     #Line 1
    c.wait()
    print('Consumer got notification and started enjoying Cheese-burst Pizza...')   #Line 4
    c.release()

def produce(c):
    c.acquire()
    print('Dominos got the order producing items...')       #Line 2
    print('Dominos giving notification via Token number...')  #Line 3
    c.notify()    #Signalling mechanism. Will provide notification
    c.release()   #We need to release lock so that consumer stops waiting

c=Condition()   #Creading Condition object
t1=Thread(target=consume,args=(c,))       #args=(c,) represents a tuple with a single item list
t2=Thread(target=produce,args=(c,))
t1.start()
t2.start()
'''
acquire() ->To acquire Condition object before producing or consuming items.i.e thread acquiring internal lock.
release()  To release Condition object after producing or consuming items. i.e thread releases
internal lock
wait()|wait(time)  To wait until getting Notification or time expired
notify()  To give notification for one waiting thread
notifyAll()  To give notification for all waiting threads
Threads are communicating via wait() and notify()
'''