from threading import *
import time
def job():
    for i in range(5):
        print('Child Thread')
        time.sleep(3)

t=Thread(target=job)    #Creating child thread object
#t.setDaemon(True)     #Changing Child thread as Daemon before starting it
t.start()
time.sleep(3)
print('End of Main Thread')

'''
Here both the Main Thread nd Child Thread is non-Daemon. So both the threads will continue to execute
Even if Main Thread print statement i.e, print('End of Main Thread') executes after that also
child thread will keep on executing bz child thread is non-Daemon

If we change child thread as Daemon before starting it. So now child is Daemon
Once main thread completed child thread is not required to continue so it terminated
As job of child thread is to provide support for Main Thread only. As Daemon thread will help Non-Daemon thread
So if Non-Daemon thread is not there no need of Daemon Thread. So Daemon thread terminates
If last non-Daemon thread terminates than Daemon thread terminates automatically
'''