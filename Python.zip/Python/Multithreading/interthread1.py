#Interthread communication by using Event object
from threading import *
import time
e=Event()   #Event object
def trafficpolice():
    while True:             #Continuous activity so it is infinite loop
        time.sleep(10)    #10 seconds Red signal
        print('Traffic police giving Green Signal')
        e.set()     #internal flag value will become True and it represents GREEN signal for all waiting threads.
        time.sleep(15)   #15 seconds Green signal
        print('Traffic police giving Red Signal')
        e.clear()  #internal flag value will become False and it represents RED signal for all waiting threads

def driver():
    num=0   #Tracking no of vehicles
    while True:             #Continuous activity so it is infinite loop
        print('Drivers waiting for Green signals')
        e.wait()
        print('Traffic signal is Green, Vehicles can move')
        while e.isSet():        #This method can be used whether the event is set or not
            num=num+1
            print('No of vehicles:',num,' crossing the signal')
            time.sleep(2)
        print('Traffic signal is Red, Drivers have to wait')

t1=Thread(target=trafficpolice)
t2=Thread(target=driver)
t1.start()
t2.start()

'''
Event object is the simplest communication mechanism between the threads. One thread signals
an event and other threads wait for it.
1.set()  internal flag value will become True and it represents GREEN signal for all waiting
threads.
2. clear()  internal flag value will become False and it represents RED signal for all waiting
threads.
3. isSet()  This method can be used whether the event is set or not
4. wait()|wait(seconds)  Thread can wait until event is set
'''