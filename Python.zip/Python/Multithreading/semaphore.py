from threading import *
import time
s=Semaphore(3)
def wish(name):
    s.acquire()
    for i in range(5):
        print('Good morning',name)
    s.release()

t1=Thread(target=wish,args=('Prashant',))
t2=Thread(target=wish,args=('Aishu',))
t3=Thread(target=wish,args=('Sharu',))
t4=Thread(target=wish,args=('Anjali',))
t5=Thread(target=wish,args=('Khushboo',))
t1.start()
t2.start()
t3.start()
t4.start()
t5.start()
'''
At a time 3 threads are allowed to execute parallel as we passed s=Semaphore(3)
In Locak and RLock only 1 thread is allowed
In Semaphore we can allow multiple threads to execute in parallel. Like we passed 3 here
After 3 executes, next 3 set of threads will execute
Also called as unbounded semaphore
Number of or release() can exceed number of acquire()
'''