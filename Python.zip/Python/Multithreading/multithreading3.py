#Creating a Thread by extending Thread class

from threading import *
class MyThread(Thread):  #MyThread is child class which is extending Thread class
    def run(self):  #self is reference variable to current object. Here run method is already there in Thread which is parent class. We're changing that run method in the clild class i.e, MyThread. This is overriding
        for i in range(10):
            print('Child Thread')
t=MyThread() #No need to use target bz if we're taking anything inside run method it will automatically considered as target
t.start()
for i in range(10):
    print('Main Thread')