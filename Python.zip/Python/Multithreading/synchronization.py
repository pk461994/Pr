from threading import *
import time
l=Lock()
def wish(name):
    l.acquire()
    for i in range(5):
        print('Good evening...',end='')   #print('Good evening...',name)    No need to take print(name)
        #time.sleep(3)
        print(name)
    l.release()

t1=Thread(target=wish,args=('Dhoni',))
t2=Thread(target=wish,args=('ABD',))
t1.start()
t2.start()

'''
For synchronization we use Lock()
One thread will acquire the lock so we did l.acquire()
And will execute and after execution it'll release lock by l.release()
Than the next thread will acquire the lock and continue execution

Only one thread is allowed to execute at a time other will wait until it'll release lock
Like Dhoni thread will execute and ABD thread will wait until Dhoni thread completes execution and release lock

If we use RLock() instead of Lock() than a thread can acquire more than one time the Lock()
'''
