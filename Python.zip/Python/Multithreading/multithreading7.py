from threading import *
print(current_thread().getName())
current_thread().setName('Sunny Leone') #We're changing the default name of MainThread to Sunny Leone
print(current_thread().getName())
print(current_thread().name)  #We can take only name in place of getName()

