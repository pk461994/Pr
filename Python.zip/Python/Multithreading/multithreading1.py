#Multithreading without using a class

from threading import *
def display():
    print('This code executed by thread:',current_thread().getName())

t=Thread(target=display).start()

#t.start()  #Here MainThread starts clild Thread i.e, t

print('This code executed by thread:',current_thread().getName()) #this will be executed by MainThread only bz it is not related to child thread which will only execute display()


'''
Creating Thread object t and within () we're passing arguement. It'll execute display()
MainThread created child Thread object but MainThread not sorted that child Thread object. This child Thread is responsible to execute display() method

'''
