# join() method

from threading import *
import time
def display():
    for i in range(5):
        print('Prashant Thread')
        time.sleep(2)

t=Thread(target=display)
t.start()
t.join()    #Main Thread i.e, Aishwarya Thread will be in waiting state until child thread i.e, Prashant Thread completes
#t.join(3)
for i in range(5):
    print('Aishwarya Thread')


'''
join() is used when one thread needs to wait until other thread completes
If we put some value of time in join like join(3)
Than the main thread will wait only upto 3 seconds After that it'll start executing
Even if child thread hasn't executed in 3 secs main thread will start executing without waiting child thread to complete
'''
