import threading
print('Current Executing thread:', threading.current_thread().getName())

''' Output:
Current Executing thread: MainThread
By default every python program contains one thread i.e, MainThread
This thread is responsible to execute our code.
'''