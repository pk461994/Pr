from functools import *             #from functools import reduce       we took * to import everything present inside functools module
l=[10,20,30,40,50]
result=reduce(lambda x,y:x+y,l)
print(result)

#Output:-
#150

#l=[10,20,30,40,50]
#It will take x=10, y=20. so x+y=30
#Than x=30,y=30. So x=y=60
#Than x=60, y=40. So 100
#Than x=100,y=50. So 150

#reduce() function is by default not available in python
#reduce() function is only available in a package called functools.
#We need to import functools package before using reduce function
#If we call it without calling it from functools like we don't take below statements:-
#from functools import *     or    from functools import reduce
#we'll get NameError: name 'reduce' is not defined

