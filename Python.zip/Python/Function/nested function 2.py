#Function returning other function

def outer():
    print('Outer Function started')
    def inner():
        print('inner function started')
    print("outer function returning inner function")
    return inner  #We can call inner function as well like inner()
i = outer() # i is return type of outer() means inner() so i internally points to inner()
i()
'''
i=outer() means we're calling outer() function. Then line no 2 and 5 will execute. And than inner() function returns some value
So now return value will come to outer(). Now we're assigning that to i and then we call i()
'''