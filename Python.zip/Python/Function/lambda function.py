result=lambda x:x*x  #Anonymus Function
print(result(2))
print(result(3))
print(result(4))



#4
#9
#16



#No need to write def and all and also no return statement.
