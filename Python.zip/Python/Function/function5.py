#BMI Calculator

name1='Prashant'
height_m1=2.5
weight_kg1=68

name2='Aishwarya'
height_m2=2
weight_kg2=45

name3='Jha'
height_m3=2.4
weight_kg3=152

def bmi_calculator(name, height_m, weight_kg):
    bmi=weight_kg / (height_m ** 2)
    print("bmi: ",bmi)
    if bmi<25:
        return name + ' is not overweight'
    else:
        return name + ' is overwight'

result1= bmi_calculator(name1, height_m1, weight_kg1)
result2= bmi_calculator(name2, height_m2, weight_kg2)
result3= bmi_calculator(name3, height_m3, weight_kg3)
print(result1)
print(result2)
print(result3)



#bmi:  10.88
#bmi:  11.25
#bmi:  26.38888888888889
#Prashant is not overweight
#Aishwarya is not overweight
#Jha is overweight
