def f1():
    print('Hello this is function')
class Student:
    def info(self):
        print('This is method not function so do not confuse')
f1()            #We are calling f1()
s=Student()     #We are calling info(self)
s.info()


#If you define any function or a method outside of a class than it is called function.
#If you declare a function inside a class than such type of function is called method.
