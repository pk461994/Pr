def wish(name,message):
    print('Hello',name,message)
wish(name='Durga',message='Good Morning') #Passing value by parameter name or by keyword. These are called Keyword Arguement. Order is not important
wish(message='Good Morning',name='Aishwarya')
wish('Prashant',message='Good Morning')
#wish(msg='Good Morning','Chandan')  #We'll get error saying, positional arguement follows Keyword arguement. Positional Arguement should come before Keyword Arguement
                                     #Positional arguement should be in beginning. After that we can take any no of Keyword arguements 
#Hello Durga Good Morning
#Hello Aishwarya Good Morning
#Hello Prashant Good Morning
