l1=[1,2,3,4]
l2=[10,20,30,40]
final=list(map(lambda x,y:x*y,l1,l2)) #For given 2 inputs x,y calculate x*y. x will take from 1st sequence i.e, l1 and y will take from l2
print(final)


#[10, 40, 90, 160]
#Extra elements will be ignored if no of elements in l1 and l2 differs and length differs
#Suppose input contains 10 elements than output also contains 10 elements only.
#In map function the no of elements in input is equal to no of elements in output
#map is the name of a higher-order function that applies a given function to each element of a list, returning a list of results in the same order.
