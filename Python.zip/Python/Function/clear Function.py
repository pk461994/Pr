x=[10,20,30,40,50,60]
print(x)
x.clear()
print(x)


#Output:
#[10, 20, 30, 40, 50, 60]
#[]                             Only Elements will be removed
