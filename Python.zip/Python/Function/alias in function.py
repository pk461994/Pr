def wish(name):
    print('Good Morning:',name)
greeting=wish           #We are calling wish as greetings. This is aliasing
print(wish is greeting)   #So id(wish)==id(greeting)
wish("Prashant")
greeting('Aishwarya')

#True
#Good Morning: Prashant
#Good Morning: Aishwarya




#greeting will also have the same function as wish
#Just we are calling wish by the name of greetings
