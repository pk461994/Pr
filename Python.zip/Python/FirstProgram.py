n=int(input("Enter some number: "))
for i in range(n):
    print("Prashant will succeed")
