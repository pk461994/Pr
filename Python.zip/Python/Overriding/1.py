class Parent:
    def property(self):
        print('Cash+Land+Gold+Power')
    def marraige(self):
        print('Need to marry xyz girl')

class Child(Parent):
    def marraige(self):                 #Overriding marraige() method
        super().marraige()              #Just accessing marraige() method of Parent class
        print('Married to Aishwarya')

c=Child()
c.property()
c.marraige()
