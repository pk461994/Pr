# Method overriding

class Loan:
    def interestrate(self):
        return 10.5

class Gold(Loan):
    def interestrate(self):
        return 14.5

class Vehicle(Loan):
    def interestrate(self):
        return 8.5

g=Gold()
print(g.interestrate())
v=Vehicle()
print(v.interestrate())
