# Constructor overriding

class P:
    def __init__(self):
        print('Parent constructor')

class C(P):
    def __init__(self):          #Overriding
        super().__init__()       #Calling parent class constructor
        print('Child constructor')

c=C()
