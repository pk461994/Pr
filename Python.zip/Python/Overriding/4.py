class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

class Employee(Person):
    def __init__(self,name,age,eno,esal):   #Overriding parent class
        super().__init__(name,age)
        self.eno=eno
        self.esal=esal

    def display(self):
        print('Employee name:',self.name)
        print('Employee age:',self.age)
        print('Employee number:',self.eno)
        print('Employee salary:',self.esal)
        print()

e=Employee('Prashant',24,123213,350000000)
e.display()
e=Employee('Aishwarya',25,123212,350000000)
e.display()
