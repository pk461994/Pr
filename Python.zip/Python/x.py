s=input('Enter some String:')
print(''.join(set(s)))
