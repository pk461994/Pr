import smtplib

def get_mail():    #Function to take only valid email from the user and Provide Service Provider(sp)
    servicesAvailable= ['hotmail', 'gmail', 'yahoo', 'outlook']

    while True:
        
        mail_id=input('Enter email ID: ')

        if '@' in mail_id and '.com' in mail_id:
            symbol_pos=mail_id.find('@')  #To find position of @ symbol in mail
            dotcom_pos=mail_id.find('.com') #To find position of .com in mail
            sp = mail_id[ symbol_pos+1 : dotcom_pos ] #Slice operator to find value between @  and  .com

            if sp in servicesAvailable:
                return mail_id, sp  #Will return 2 values, mail_id and sp when we call send_mail() function
                                    #It'll be tuple type and give value like (pk461994@gmail.com, gmail)
                break
            else:
                print("We don't provide services for ", +sp)
                print('We provide services only for : hotmail,gmail,yahoo,outlook')
                continue
        else:
            print('Invalid email type')
            continue

def set_smtp_domain(serviceProvider): #Function to set smtp domain for different mail systems using argument: sp
    if serviceProvider == 'gmail':
        return 'smtp.gmail.com'
    if serviceProvider == 'outlook' or serviceProvider == 'hotmail':
        return 'smtp-mail.outlook.com'
    if serviceProvider == 'yahoo':
        return 'smtp.mail.yahoo.com'
    

user_mail, sp = get_mail() #Calling send_mail function and saving mail_id in user_mail 
smtpDomain = set_smtp_domain(sp)
print('Email provided by user is: ',user_mail)
print("Value found between '@' and '.com' in the email given by user is: ",sp)
print ('Your SMTP Domain is: ' +str(smtpDomain))
print()
print('Welcome you can send an Email using this Program')
print('Please provide Email ID and Password')
e_mail , serviceProvider = get_mail()   #User email address and service provider
password=input('Enter Password: ')

while True:
    try:
        smtpDomain= set_smtp_domain(srviceProvider)
        connection= smtplib.SMTP(smtpDomain, 587)
        connection.ehlo()
        connection.starttls()
        connection.login(e_mail , password)

    except:
        if smtplib.SMTPException:
            print('SMTP Excepton occured')
            break
        elif smtplib.SMTPServerDisconnected:
            print('server unexpectedly disconnects or an attempt is made to use the SMTP instance before connecting it to a server')
            break
        elif smtplib.SMTPResponseException:
            print('SMTP server returns an error code')
            break
        elif smtplib.SMTPSenderRefused:
            print('Sender address refused')
            break
        elif smtplib.SMTPRecipientsRefused:
            print('All recipient addresses refused')
            break
        elif smtplib.SMTPDataError:
            print('The SMTP server refused to accept the message data')
            break
        elif smtplib.SMTPConnectError:
            print('Error occurred during establishment of a connection with the server')
            break
        elif smtplib.SMTPHeloError:
            print('The server refused our HELO message')
            break
        elif smtplib.SMTPNotSupportedError:
            print('The command or option attempted is not supported by the server')
            break
        elif smtplib.SMTPAuthenticationError:
            print('SMTP authentication went wrong. Most probably the server didn’t accept the username/password combination provided')
            break
    else:
        print('Login Successfully')
        break

print("Please type receiver's Email Address: ")
receiverAddress, receiverSP = get_mail() #We called get_mail function to validate correct email and service provider
print('Please provide Email Subject and Message')
Subject = input('Email Subject : ')
Message = input('Email Message : ')
connection.sendmail(e_mail , receiverAddress , ('Subject: ' + str(Subject) + '\n\n' + str(Message)))
print('Email has been sent Successfully')
connection.quit()

