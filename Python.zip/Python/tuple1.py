>>> t=1,2,3,4,5,6
>>> type(t)
<class 'tuple'>     #() is not necessary to define a tuple
>>> t
(1, 2, 3, 4, 5, 6)
>>> t=(10)
>>> type(t)
<class 'int'>       #Single value tuple not allowed
>>> t=('a')
>>> type(t)         #Single value tuple not allowed
<class 'str'>
>>> t=(10,)
>>> type(t)
<class 'tuple'>
>>> t=10,
>>> type(t)
<class 'tuple'>

#Single value tuple not allowed
#If we want to represent single tuple value. Compulsary comma(,) should be there in the last like t=(10,)
>>> t=(,0)
SyntaxError: invalid syntax
>>> t=()            #Empty tuple
>>> type(t)
<class 'tuple'>
>>> t=(10,20,30,)   #Ends wih comma is acceptable. Result will be tuple only
>>> t
(10, 20, 30)
>>> type(t)
<class 'tuple'>
>>> t=tuple(range(1,21,2))      #Valid for range function
>>> t
(1, 3, 5, 7, 9, 11, 13, 15, 17, 19)
>>> type(t)
<class 'tuple'>
>>> t=tuple('AishwaryaPrashant')
>>> t
('A', 'i', 's', 'h', 'w', 'a', 'r', 'y', 'a', 'P', 'r', 'a', 's', 'h', 'a', 'n', 't')
>>> t=(1,2,3,4,5)
>>> t[1]=11                     #tuple is immutable. Once assigned can't be changed
Traceback (most recent call last):
  File "<pyshell#83>", line 1, in <module>
    t[1]=11
TypeError: 'tuple' object does not support item assignment

>>> t=(1,2,3,4,5,6)
>>> print(min(t))         #Minimum value by using min() fuction
1
>>> print(max(t))         #Maximum value by using max() fuction
6
>>> print(len(t))         #To know length of the tuple by len() method
6
>>> t=(1,2,3,1,2,5,6,9,7,2,3)
>>> print(t.count(2))     #To know how many time 2 comes in tuple t using count() method
3
>>> a=10
>>> b=20
>>> c=30
>>> t=(a,b,c)       #Assign values of a,b,c in tuple t. This is packing
>>> t
(10, 20, 30)
>>> x,y,z=t         #Assigning value of tuple t to x,y,z. This is unpacking
>>> x
10
>>> y
20
>>> z
30
