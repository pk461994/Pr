n=int(input('Enter the number of rows:'))
for i in range(n):      #No of rows
    for j in range(n):  #no of *
        print('*',end=' ')
    print()             #After completion first n star other n starts should be in next line.




# Alternate Code:-
#n=int(input('Enter the number of rows:'))
#for i in range(n):
#    print('* '*n)
