>>> s1={10,20,30,40}
>>> s2={30,40,50,60}
>>> print(s1.symmetric_difference(s2))  #To know elements present in s1 and not in s2 and vice-versa(Excluding common elemets)
{10, 50, 20, 60}
>>> print(s1^s2)                        #To know elements present in s1 and not in s2 and vice-versa(Excluding common elemets)
{10, 50, 20, 60}
>>> print(s1.union(s2))                 # Union
{40, 10, 50, 20, 60, 30}
>>> print(s1|s2)                        # | will also act as union only
{40, 10, 50, 20, 60, 30}
>>> print(s1.intersection(s2))          #Will provide the elements present in both s1 and s2. If nothing is common returns empty set
{40, 30}
>>> print(s1.difference(s2))            #Print elements present in s1 but not in s2
{10, 20}
>>> print(s1-s2)                        #Print elements present in s1 but not in s2
{10, 20}
>>> print(10 in s1)                     #Membership operator
True
>>> print('d' in s1)
False
>>> s={x*x for x in range(1,6)}         #Comprehension in set
>>> s
{1, 4, 9, 16, 25}
