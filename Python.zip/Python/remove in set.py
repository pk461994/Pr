s={10,20,30,40,50}
print(s.remove(40))  #To remove particular or specified element we use .remove() function
print(s)
print(s.discard(20)) #To remove 20
print(s)
print(s.discard(444)) #discard() method used to remove but if it is unavailable it'll not throw error it will return None
print(s.remove(555))  #555 is not there in s so will throw KeyError: 555




#Output:-
#None             remove() doesn't return anything in output.pop() returns value
#{10, 50, 20, 30}
#Traceback (most recent call last):
#  File "C:/Users/pkuma182/Documents/Py/remove in set.py", line 4, in <module>
#    print(s.remove(555))
#KeyError: 555


#If the set is empty or specified element is not available we'll get KeyError
