#To generate OTP of 6 digits

from random import *
for i in range(10):         #We're generating 10 OTPs
    print(randint(0,9),randint(0,9),randint(0,9),randint(0,9),randint(0,9),randint(0,9),sep='')




'''Output:-
074479
160902
523409
088216
933681
242074
113352
571121
418575
116286
'''
