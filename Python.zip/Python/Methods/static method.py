class Math:

    @staticmethod           #General utility method
    def add(firstnumber,secondnumber):
        print('The sum is:',firstnumber+secondnumber)

    @staticmethod
    def product(firstnumber,secondnumber):
        print('The product is:',firstnumber*secondnumber)

    @staticmethod
    def average(firstnumber,secondnumber):
        print('The product is:',(firstnumber+secondnumber)/2)

Math.add(10,20)
Math.product(10,20)
Math.average(10,20)

'''
If we're not using any class method or instance method
Just we're passing some data and our method will read and perform in such case, we use staticmethod
static method are General utility method

If we don't use any self or cls keyword or any decorators like @staticmethod or @classmethod by default it'll be considered as
static method only
'''
