class Animal:
    legs=4    #Class level variable means static variable

    @classmethod   #classmethod means we're using class variables
    def walk(cls,name):     #name is the local variable  cls is for classmethod and is implicitely provided for calssmethod by python
        print('{} animal walks with {} number of legs'.format(name,cls.legs)) #legs is class level variable so its cls.legs

Animal.walk('Dog')
Animal.walk('Cat')
