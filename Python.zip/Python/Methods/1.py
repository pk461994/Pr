class Student:
    def __init__(self,name,marks):
        self.name=name
        self.marks=marks
    def display(self):
        print('Hi',self.name)
        print('Your have scored',self.marks)
    def grade(self):
        if self.marks>=90:
            print('You got A grade')
        elif self.marks>=70 and self.marks<90:
            print('You got B grade')
        elif self.marks>=50 and self.marks<70:
            print('You got C grade')
        elif self.marks>=35 and self.marks<50:
            print('You got A grade')
        else:
            print('You got F grade')

n=int(input('Enter number of student:'))
for i in range(n):
    name=input('Enter name of student:')
    marks=int(input('Enter Student marks:'))
    s=Student(name,marks)
    s.display()
    s.grade()
