class Student:
    def setName(self,name):
        self.name=name      #It is initializing the value to instance variable and declaring instance variable also

    def getName(self):      #No need to provide any arguement
        return self.name

    def setMarks(self,marks):
        self.marks=marks

    def getMarks(self):      
        return self.marks
n=int(input('Enter numbe rof students:'))

for i in range(n):
    s=Student()                         #Created student object
    name=input('Enter name of student:') #Reading name from keyboard
    s.setName(name)                     #The name we provide will be set to the Name property of the student object
    marks=int(input('Enter marks of student:'))
    s.setMarks(marks)
    print('Hi',s.getName())             #Getting student name
    print('You have scored:',s.getMarks())
    print()
        
