def factorial(n): 
    if n==0:
        result=1
    else:
        result=n*factorial(n-1)
    return result
print(factorial(0))
print(factorial(3))


#Let n=0 we took. So 3!=0 so no if condition it'll go to else part
#result=3*factorial(2)
#again factorial(2) is also a fuction so again loop starts for factorial(2)
#n=2 again else part so, result=3*2*factorial(1)
#again factorial(1) is also a fuction so again loop starts for factorial(1)
#n=1 again else part so, result=3*2*1*factorial(0)
#Mow n=0 so if part finally executes and returns result=1
#So final and would be result=3*2*1*1=6

#factorial(n) functional calls factorial(n-1) so it calls same fuction until some end condition.
#So it is recurssive function.
#Calling same function again and again is Recurssion.
