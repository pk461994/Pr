#WAP to print no of occurences of each letter present in given string

word=input('Enter some word:')
d={}
for x in word:
    d[x]=d.get(x,0)+1 #In d if x is already there
print(d)
print(sorted(d)) #If we use sorted function it will sort only the keys in alphabetical order and result will be in List[]
for k,v in d.items():   #for k,v in sorted(d.items()):
    print(k,'occurred',v,'times') #Or print('{} occurred {} times'.format(k,v))

#Output
#Enter some word:mississippi
#{'m': 1, 'i': 4, 's': 4, 'p': 2}
#['i', 'm', 'p', 's']
#m occurred 1 times
#i occurred 4 times
#s occurred 4 times
#p occurred 2 times

#First m comes
#d[m]=d.get['m',0]+1
#If m letter is there in word than consider its count as 0. Just like the Key:value concept
#Now d[m]=0+1=1. So 1 will be assigned to d{m}. If m comes again d[x]=1+1=2 so d[m]=2
#Now i comes so d[i]=d.get['i',0]+1. d[i]=0+1=1. d[i]=1
