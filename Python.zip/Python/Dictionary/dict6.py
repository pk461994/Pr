#WAP to take dictionary from keyboard and print the sum of values

d=eval(input('Enter dictionary:'))
s=sum(d.values())  #For all values sum() function will be applied. By default present in Python
print('The sum:',s)

#Output:-
#Enter dictionary:{'A':100,'B':200,'C':300}
#The sum: 600


#sum() function applicable for any sequence like list, set or tuple
