records={}  #records as empty dictionary
n=int(input('Enter number of students:'))
i=1
while i<=n:
    name=input('Enter student name:')
    marks=(input('Enter percentage of marks:'))
    records[name]=marks         #To add Keys and Values. Name will become Key and marks will become Values
    i=i+1
print('Name of student:','\t','Percentage of marks:')
for x in records:
    print('\t',x,'\t\t',records[x])  #x means key and its corresponding value i.e, records[x]  x will be the name and records[name]=marks so records[x]=marks




#Output-
#Enter number of students:2
#Enter student name:Prashant
#Enter percentage of marks:99%
#Enter student name:Aishwarya
#Enter percentage of marks:99%
#Name of student: 	 Percentage of marks:
#	 Prashant 		 99%
#	 Aishwarya 		 99%
