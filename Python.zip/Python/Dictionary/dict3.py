d={100:'abc',200:'pqr',300:'xyz'}
for k,v in d.items():
    print(k,'------',v)

#Output
#100 ------ abc
#200 ------ pqr
#300 ------ xyz
