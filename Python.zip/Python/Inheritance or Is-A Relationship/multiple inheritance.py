class Parent1:
    def m1(self):
        print('Parent1 instance method')
class Parent2:
    def m1(self):
        print('Parent2 instance method')

class Child(Parent1,Parent2):
    pass

c=Child()
c.m1()

'''
Output:-
Parent1 instance method

If same method present in both the Parent classes and we're calling it using the child reference variable
Than it'll first search the method in the first Parent class if it is there it'll execute that
If not it'll search in the second Parent class and if found it'll execute that
We took
class Child(Parent1,Parent2):
So Parent1 will be called first
If we take like
class Child(Parent2,Parent1):
Than Parent2 method will be called first
If child class has same m1() method than child class m1() method will be called not any of the Parent class

This is called the multiple inheritance in classes
'''
