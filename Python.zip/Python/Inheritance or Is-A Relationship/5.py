class P:
    a=7777
    def __init__(self):
        self.b=10

class C(P):
    a=8888
    def __init__(self):
        super().__init__()
        self.b=20
        print(C.a)  #Or print(self.a)   child class a
        print(P.a) #If print(self.a) than child class but we used P.a so Parent class a
        print(super().a)  #Parent class a
        print(self.b)
c=C()
'''
Here 2 static variables are present in child class one from child class and another from Parent
as we have called using C.a and super().a
But for instance variable, we're calling Parent class constructor by using
super().__init__()
So the instance variable present in child will be b=10
But in the next line self.b=20
So the value of a which was 10 will override to a=20 
only one copy of instance variable will be available i.e, b=20
So when at last we execute print(self.b) to know about instance variable it'll give 20 as output
'''
