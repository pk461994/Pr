class P:
    x=777
    def __init__(self):
        self.x=10

class C(P):
    def __init__(self):
        super().__init__()
        self.y=20
        print(super().x)
        print(self.x)
        print(self.__dict__)
c=C()

'''
super() will bring everything from parent except instance variable of Parent 
super() cannot access Parent class instance variable like we tried to access x=10 value(If we comment x=777)
x is instance variable of the parent class P so it'll throw 
AttributeError: 'super' object has no attribute 'x'

Than if we create static variable x=777 i.e, a class level variable it'll easily access that and
print(super().x)      will give output as
777
We can access Parent class instance variable by using self keyword like we did in
print(self.x) which will give output as 10

'''
