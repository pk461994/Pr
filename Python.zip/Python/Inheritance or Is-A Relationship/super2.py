class P:
    a=10

    def __init__(self):
        print('Parent constructor')
    def m1(self):
        print('Parent instance method')
    @classmethod
    def m2(cls):
        print('Parent class classmethod')
    @staticmethod
    def m3():
        print('Parent class static method')

class C(P):
    @staticmethod
    def m1():
        #print(super().a)
        #super().__init__()
        #super().m1()
        #super().m2()
        #super().m3()
        pass
c=C()
c.m1()   #Calling child class C staticmethod m1()

'''
Inside child class:
From staticmethod of child class we can't use super() at all
Because static means general utility method. It is nowhere related to the class or object
Just we pass some arguement in staticmethod and it performs operations according to those arguements
If we don't metion decorator like we delete @staticmethod from child class
Than we need to call m1() of child class by using class name only like C.m1() not by c.m1()
'''
