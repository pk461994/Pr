class A:
    x=10
    def m1(self):
        print('Parent class instance method')

    @classmethod
    def m2(cls):
        print('Parent class class method')

    @staticmethod
    def m3():
        print('Parent class static method')

    def __init__(self):
        self.c=8888          #Instance method of Parent class A
        print('Parent Constructor....')

class B(A):     #Inheritence. Extending class A from child class B
    x=7777
    def __init__(self):
        super().__init__()      #This is method calling no need to pass self
        super().m2()
        super().m1()
        super().m3()
        print('Child constructor....')
        print(super().x)
        print(B.x)          #To access static variable of class B we're calling it using class name B
b=B()

'''
If constructor is avaiabe in both parent and child classes by default child class will be executed as child
has higher priority than parent. But if we want to call parent class method from child class than we
need to use super() 
Because of the super() call parent constructor will be executed for super().__init__()
'''
