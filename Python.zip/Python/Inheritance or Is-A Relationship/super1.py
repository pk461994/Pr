class P:
    a=10

    def __init__(self):
        print('Parent constructor')
    def m1(self):
        print('Parent instance method')
    @classmethod
    def m2(cls):
        print('Parent class classmethod')
    @staticmethod
    def m3():
        print('Parent class static method')

class C(P):
    @classmethod
    def m1(cls):
        print(super().a)
        #super().__init__()
        #super().m1()
        super().m2()
        super().m3()
c=C()
c.m1()   #Calling child class C classmethod m1()

'''
Inside child class:
From classmethod of child class we can't call Parent class constructor or instance method by using super()
From classmethod of child class we can call Parent class, class method and static method by using super()
'''
    
