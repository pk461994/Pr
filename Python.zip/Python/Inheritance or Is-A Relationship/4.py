class P:
    a=8888
    def m1(self):
        self.a=10

class C(P):
    def __init__(self):
        super().m1()    #Calling m1 method of Parent class by using super()
        print(super().a) #Will give static variable a=8888 as by super() w can only access class level variables
        print(self.a)    #Accessing instance variable a=10 of parent class by using self only
c=C()

'''
We can also call m1 method from child class C using self
Like in place of super().m1() we can write like self.m1()
As m1() is the instance methodwe can call it by using self
'''