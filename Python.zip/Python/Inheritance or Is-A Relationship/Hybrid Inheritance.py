#MRO(Method Resolution Order)
class A:
    def m1(self):
        print('A class method')
class B:
    def m1(self):
        print('B class method')
class C:
    def m1(self):
        print('C class method')
class Z:
    def m1(self):
        print('Z class method')
class X(A,B):
    def m1(self):
        print('X class method')
class Y(B,C):
    def m1(self):
        print('Y class method')
class P(X,Y,C,Z):
    def m1(self):
        print('P class method')

p=P()
p.m1()

'''
Output:-
[<class '__main__.P'>, <class '__main__.X'>, <class '__main__.A'>, <class '__main__.Y'>, <class '__main__.B'>, <class '__main__.C'>, <class '__main__.Z'>, <class 'object'>]


L(P)=P+merge(L(X),L(Y),L(C),L(Z),XYCZ)
    =P+merge(XABO,YBCO,CO,ZO,XYCZ)
    =PX+merge(ABO,YBCO,CO,ZO,YCZ)
    =PXA+merge(BO,YBCO,CO,ZO,YCZ)
    =PXAY+merge(BO,BCO,CO,ZO,CZ)
    =PXAYB+merge(O,CO,ZO,CZ)
    =PXAYBC+merge(O,O,ZO,Z)
    =PXAYBCZ+merge(O)
L(P)=PXAYBCZO

So if we don't write any method inside P class and simply write pass than X will execute
If in X we take pass A will execute, if we take in A class and write pass,Y will execute and so on

If anything is present in the tail part we need not to take that if it is not in tail we need to add to main result
'''
