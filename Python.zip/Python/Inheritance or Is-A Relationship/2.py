class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def eatndrink(self):
        print('Biryani with chilled Beer')

class SoftwareEngineer(Person):
    def __init__(self,name,age,eno,esal):
        super().__init__(name,age)
        self.eno=eno
        self.esal=esal

    def work(self):
        print('Python is like drinking chilled beer')

s=SoftwareEngineer('Prashant',24,100,3500000)
print(s.name,s.age,s.eno,s.esal)
s.eatndrink()
s.work()

'''
while object creation we have 4 properties. All 4 are in constructor of child class SoftwareEngineer
Now the first 2 properties i.e, name and age we're sending to super class constructor i.e, in Person class
Now suer class constructor will create 2 instance variable and assign the values
Rest 2 properties we're assigning in constructor of child class i.e, eno and esal 
'''