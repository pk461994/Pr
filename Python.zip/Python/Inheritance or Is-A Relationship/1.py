class A:
    x=10
    def m1(self):
        print('Parent class instance method')

    @classmethod
    def m2(cls):
        print('Parent class class method')

    @staticmethod
    def m3():
        print('Parent class static method')

    def __init__(self):
        self.c=8888          #Instance method of Parent class A
        print('Parent Constructor....')

    def __del__(self):
        print('Parent Destructor....')

class B(A):     #Inheritence. Extending class A from child class B
    x = 7777
    print('Child class method')
    def __init__(self):
        print('Child constructor....')
    def __del__(self):
        print('Child Destructor....')

b=B()   #Creating B class object. A class functionality will also be available in B
print(b.x)   #Calling x value i.e, defined in class A from class B object i.e, b
b.m1()
b.m2()
b.m3()
#print(b.c)

'''
In Python highest priority is of child class. when its not there in child than only parent will come in picture
As x is there in both child and parent class but the child class x executed at first
Here constructor got executed first because at the time of object creation only the constructor will be executed

Whatever variables, methods and constructors available in the parent class by default available to the child classes 
We are not required to rewrite. 
Hence the main advantage of inheritance is Code Reusability and we can extend existing functionality with some more extra functionality.

We took print(b.c)
c is there in constructor of parent class A but not in child class constructor
As child class constructor will be executed at first, and it doesn't have c so it'll throw AttributeError
If wo don't take constructor in child class than we'll get value of c from parent class 

Constructor and Destructor are present in both parent and child class but as the child class has hot the 
highest priority child class methods will be executed first. This rule is applicable for any method 
'''