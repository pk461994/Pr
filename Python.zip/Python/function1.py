def sum_sub(firstnumber,secondnumber):          #firstnumber & secondnumber are Formal Parameters
    sum=firstnumber+secondnumber
    sub=firstnumber-secondnumber
    return sum,sub                              #A function can return multiple values in Python.
firstnumber=int(input('Enter the First number:'))
secondnumber=int(input('Enter the Second number:'))
sum,sub=sum_sub(firstnumber,secondnumber)       #firstnumber & secondnumber are Actual Parameters
print('The sum is:',sum)
print('The substraction is:',sub)


#Enter the First number:100
#Enter the Second number:50
#The sum is: 150
#The substraction is: 50


#sum_sub(firstnumber,secondnumber)  is a function
#Everything in Python is by default and object except keywords like def. So does the function also
