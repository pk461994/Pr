#Generate OTP which has Characters on odd position and numbers on even position

from random import *
for i in range(10):
    print(chr(randint(65,90)),randint(0,9),chr(randint(65,90)),randint(0,9),chr(randint(65,90)),randint(0,9),sep='')
