import re
my_string = "Mary had a little lamb"
len(re.findall("a", my_string))
