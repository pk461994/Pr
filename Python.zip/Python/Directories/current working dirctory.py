import os
cwd=os.getcwd()
print('The Current working directory is:',cwd)
subdirectory=os.mkdir('Prashant Jha')
print('Sub directory created')
#x=os.mkdir('Prashant Jha/python infos')    # To create directory within the sub directory


'''
os.getcwd() to know the current working directory
os.mkdir() to create sub directory within a directory
When we're making directory within a sub-directory like we did in 
x=os.mkdir('Prashant Jha/python infos')   we're creating python infos within Prashant Jha
But in this case the sub directory Prashant Jha should be available. If it is not there it'll throw FileNotFoundError
'''