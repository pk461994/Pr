import os
cwd=os.makedirs('sub1/sub2/sub3/sub4')
print('Multiple sub directories created')