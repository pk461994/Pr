import os,datetime
stats=os.stat('aaa.txt')
print('File size in bytes:',stats.st_size)
print('File last accessed Time:',datetime.datetime.fromtimestamp(stats.st_atime))
print('File Last modified Time:',datetime.datetime.fromtimestamp(stats.st_mtime))
print('File last Headers modified time:',datetime.datetime.fromtimestamp(stats.st_ctime))
