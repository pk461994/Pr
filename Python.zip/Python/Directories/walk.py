import os
for dirpath,dirnames,filenames in os.walk('.'):   # . is for everything inside current working directory
    print('Current working directory path:',dirpath)
    print('Directories:',dirnames)
    print('File Names:',filenames)
    print()
'''
We can mention a specific directory name in place of . in os.walk() like os.walk('.idea')
walk() will always return all the informations like all the subdirectories
All the informations of the subdirectories like the name of the files in it
or the subdirectories in it name and everything

listdir() will only be used to know about the current working directory not its subdirectories
walk() can be used to know full infos like the current working directory with its subdirectories
'''