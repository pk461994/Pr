import os
os.system('dir *.py')        #system function will execute system command. It'll take the arguement which we need to perform. * will print everything within
os.system('py walk.py')
os.system('notepad')   #Will open notepad