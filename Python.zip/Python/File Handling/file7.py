#Copying binary file

file1=open('Koala.jpg','rb')   #rb for reading binary file
file2=open('newpic.jpg','wb')  #wb for writing in binary file
bytes=file1.read()
file2.write(bytes)
print('New image is available with the name: newpic.jpg')
