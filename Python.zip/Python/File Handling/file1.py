file=open('abc.txt','w')   #Here we're opening a file
print('File Name:',file.name)
print('File Mode:',file.mode)
print('Is the File Readable:',file.readable())
print('Is the File Writable:',file.writable())
print('Is the File closed? :',file.closed) #Just to prove that the file has closed we used f.closed. It'll return True of False

file.close()

print('Is the File closed? :',file.closed) #Just to prove that the file has closed we used f.closed. It'll return True of False

'''
Here we're creating a text file named abc.txt in current working directory with the write option
So if the file is not available, it'll create a new file in current working directory
If we want to create in a specific directory we need to mention whole path like C:/        before file
f.name   f.mode   and   f.closed. name, mode, closed  are variables as we didn't use ()
readable()  and   writable()  are methods as we're using ()

If we take like
f=open('abc.txt','r')
So we're opening abc.txt in read mode. So for this, the file should already exist in directory
If it is not available it'll throw error like FileNotFoundError

If we take like
f=open('abc.txt','x')
Exclusive mode---> x
Here also a file will be created if it is not available
As x is for exclusively write operation only
But if file is already there it'll throw error like FileExistsError
The file should be created freshly it should not be present there in directory

In w if file is there it'll override the existing one. If not, it'll create one in current working directory
In x if file is there it'll throw error. Compulsory, file should not be available. It should create new file only

To open a file from windows command prompt we need to use command type
type xyz.txt
'''
