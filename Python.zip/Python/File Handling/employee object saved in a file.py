import emp,pickle
f=open('employeedetails.dat','wb')
n=int(input('Enter number of employees:'))
for i in range(n):
    eno=int(input('Enter Employee number:'))
    ename=input('Enter Employee name:')
    esal=float(input('Enter Employee salary:'))
    eaddr=input('Enter Employee address:')
    e=emp.Employee(eno,ename,esal,eaddr)  #Created employee onject. Employee is present in emp module so we have put emp.employee
    pickle.dump(e,f)   #Pickling the employee object i.e, e into a file whose reference variable is f
