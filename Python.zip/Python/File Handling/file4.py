#Modifying data in a file

data='All students are STUPIDS'
f=open('abc.txt','w')
f.write(data)         #We're writing the data in file f from data
with open('abc.txt','r+') as f:  #We're opening the same file f for read and write operation
    text=f.read() #Total data will come inside text so that we can read it first so that all the elements we've added from data will be there. Than we can edit it by write
    print(text)
    print('The current cursor position is:',f.tell()) #Cursor would be at last bz we've read complete data in text
    f.seek(17)  #To jump cursor to 17th position. So that we can convert STUPID to our desired result
    print('The current cursor position is:',f.tell())
    f.write('INTELLIGENT')
    print('The current cursor position is:',f.tell())
    f.seek(0)    #To jump again to 0th index i.e, the starting point. So that we can get modified results from starting
    text=f.read()   #Again all the changes saved to text
    print('Data after modification:',end=' ')  #We use end to join lines. As we needed space so we gave spaces only
    print(text)

'''
If we want to move cursor from one location to another, we need to use seek() method
If we want to know what is my current cursor position we need to use tell() method

We're modifying STUPIDS as INTELLIGENT So the no of chars in INTELLIGENT is more than that of STUPIDS
So let's suppose we took GEMS in place of INTELLIGENT which has less characters than STUPIDS
So output will be like GEMSIDS

OUTPUT:-

All students are STUPIDS
The current cursor position is: 24
The current cursor position is: 17
The current cursor position is: 31
Data after modification: All students are INTELLIGENT
'''
    
