#To check file exists or not in a given path. If it is present print the content

import os,sys    #Bs we need to import os module to know

fname=input('Enter File name:')

if os.path.isfile(fname):
    print('File exists',fname)
    f=open(fname,'r') #Opening file fname in reading mode
    print('The content of file is:')
    data=f.read()      #Now thecontent of file will be saved in data
    print(data)
    f.close()
else:
    print('File Not Found:',fname)
#    sys.exit(0)    #Stop the program. In sys module exit is there


