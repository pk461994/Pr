#Unzip and display content of each file

from zipfile import *
f=ZipFile('files.zip','r',ZIP_STORED)  #ZIP_STORED indicates that we're unzipping text file

names=f.namelist()    # .namelist() to know the names of files present in zip file

for name in names:
    print('File name:',name)
    print('The content of this file is:')
    f1=open(name,'r')
    print(f1.read())  #f1.read() will read the complete data
    print()           #To give one line space between the different files present in a zip file
    
