import emp,pickle
f=open('emp.dat','rb')
print('Employee details:')
while True:
    try:
        obj=pickle.load(f)
        obj.display()   #display() is the instance method. Inside a class we can use it by se of object reference. display() is present inside employee class
        print()
    except EOFError:
        print('All employees completed')
        break
f.close()


'''
We are taking try-exceot because if we take seperate obj=pickle.load(f) for diff employees
Like we have 3 employees data
So we're writing
obj1=pickle.load(f)
obj2=pickle.load(f)
obj3=pickle.load(f)
Than if we don't know that there are only 3 no of employees and if we enter for 4th employee also we'll get EOFError: Ran out of input
So to avaoid we took try-except block
'''
