#The with statement
#with open('filename.txt','w') as f          ---> Syntax of with statement

with open('pqr.txt','w') as file:   #Using with we need not to close the file at last. It'll be closed automatically after the execution
    file.write('Durga\n')
    file.write('Software\n')
    file.write('Solutions')
    print('Is file closed?',file.closed) #Just to prove that the file has closed we used file.closed. It'll return True of False. But this nis within the block. So within the block file will not be closed
print('Is file closed?',file.closed)     #This is outside block and than file will be closed

'''
Once the staments completed automatically file will be closed.
This is the speciality if with statement
We neeed not close the file explacitely using file.close()
Just like in real time we forgot to close. Than this with will help in closing the file automatically
'''

