#To read csv(comma seperated value) files.

import csv

f=open('employee.csv','r')
r=csv.reader(f)   #returns reader object pointing to file f. r is csv reader object
data=list(r) #If we pass reader object to the list inbuilt function than total data infos will come into data
print(type(data))
print()
print(data)
print()
for line in data:
    for word in line:
        print(word,'\t',end='')
    print()
