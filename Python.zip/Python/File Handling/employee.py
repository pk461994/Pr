class Employee:
    def __init__(self,eno,ename,esal,eaddr):   #__init__ is the constructor and self should be there. self is current object reference variable
        self.eno=eno
        self.ename=ename
        self.esal=esal
        self.eaddr=eaddr
    def display(self):  #To display state of object. This is like instance method. It'll display the content of current object. It's our own function which will only print the values
        print('Employee info: ',self.eno,'\t',self.ename,'\t',self.esal,'\t',self.eaddr) #If we call display it'll return these values

