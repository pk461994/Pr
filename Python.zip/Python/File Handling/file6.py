#Read file name from keyboard. Read no of lines, no of words and no of characters

import os, sys
fname=input('Enter file name:')
if os.path.isfile(fname):
    print('File exists:',fname)
    f=open(fname,'r')
else:
    print('File Not Found:',fname)
    sys.exit(0)         #0 means normal termination non-zero means abnormal termination. If file is not there program will be stopped without executing further

lcount=wcount=ccount=0    #Line no count, word count, character count

for line in f:              #For each line in file f we will count
    lcount=lcount+1         #For each line increment count by 1
    ccount=ccount+len(line) #Find each character in that line. Add that no of characters to ccount. Spaces will also be considered as characters
    words=line.split()        #Split the line according to space character. We'll get no of words automatically by splitting by space. split default character is space only so no need tospecify space
    wcount=wcount+len(words)  #Adding the numbers of words present in the line to wcount

print('The number of lines is:',lcount)
print('The number of words is:',wcount)
print('The number of characters is:',ccount)

'''
f = open('file.txt', 'r')  # follow your logic and exception handling at the end open file in read mode

content = f.read()  # read content of file

print('The number of lines is:', len(content.split('\n')))
print('The number of words is:', len(content.split()))
print('The number of characters is:', len(content))
'''
