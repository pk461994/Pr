from zipfile import *
f=ZipFile('files.zip','w',ZIP_DEFLATED)  #ZIP_DEFLATED indicates that we're zipping a file
f.write('cricketers.txt')
f.write('actresses.txt')
f.close()
print('files.zip file created successfully')


'''
zipfile is the module name. All are in small letters.
ZipFile is a class name and  ('files.zip','r',ZIP_STORED) are the arguments to it
'''