#To write in csv(comma seperated value) files. For csv files a seperate module is there with name csv

import csv
with open('employee.csv','w',newline='') as f:
    w=csv.writer(f)     #returns csv writer object pointing to f. We're getting writer to write something
    w.writerow(['ENo','EName','ESal','EAddr'])
    numberofemployees=int(input('Enter no of Employees:'))
    for value in range(numberofemployees):  #This loop will be repeated for each employee and add the informations
        eno=int(input('Enter employee number:'))
        ename=input('Enter employee name:')
        esal=float(input('Enter employee salary:'))
        eaddr=input('Enter employee address:')
        w.writerow([eno,ename,esal,eaddr])
print('Total employees data written to csv file successfully')

'''
If we don't write newline=''
One extra line will be added automatically. To avoid that we used newline=''
We didn't give spaces within '' i.e, empty

We're opening employee.csv in writing mode which has a reference variable f.
One writer object is required to write in the file. that writer object is w here

'''
