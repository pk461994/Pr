import pickle
class Employee:
    def __init__(self,eno,ename,esal,eaddr):   #__init__ is the constructor and self should be there. self is current object reference variable
        self.eno=eno
        self.ename=ename
        self.esal=esal
        self.eaddr=eaddr
    def display(self):  #To display state of object. This is like instance method.It'll display the content of current object. It's our own function which will only print the values
        print(self.eno,'\t',self.ename,'\t',self.esal,'\t',self.eaddr) #If we call display it'll return these values

with open('emp.dat','wb') as f:  #We're opening emp.dat in write mode. As it could be binary file so we took wb. f is pointing to that file
    e=Employee(100,'Prashant',55555555,'Blr')   #Creating employee object with the reference variable e to access methods and properties related to the object
    pickle.dump(e,f)        #Pickling. We're dumping from e to f. e is employee object and f points to the file.
    print('Pickling of employee object completed')
    print()

with open('emp.dat','rb') as f:
    obj=pickle.load(f)     #The content of the file will come as output and will be saved by obj reference variable. Only one object in file so it'll come out and be saved with obj reference variable
    print('Employee information after unpickling')
    print()
    obj.display()   #To print the employee infos we're calling display function.

'''
__init__ is the constructor and self should be there. self is current object reference variable
constructor in python is treated as a function so we need to use def keyword so we used def __init__

def __init__(self,eno,ename,esal,eaddr) here eno,ename,esal,eaddr are just the values we're passing at time of object creation
self.eno, self.ename here eno ename, esal,eaddr are the instance variables

We can also take any value in place of eno,ename,esal,eaddr in def __init__(self,eno,ename,esal,eaddr) like
def __init__(self,x,y,z,a)
Than we can
self.eno=x, self.ename=y and so on  We're assigning a or y value to ename, esal

e=Employee(100,'Prashant',55555555,'Blr')
Creating employee object with the reference variable e to access methods and properties related to the object
Employee is the object which has properties like eno=100, esal=55555555
We can access those properties by the reference variable i.e, e Just like a remote is used for the TV

.dat is for data files
'''
        
        
