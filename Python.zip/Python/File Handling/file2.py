#Writing something to the file
file=open('xyz.txt','w')  #Single line of data will only be written. Here we're opening a file
file.write('Prashant\n')  #\n means new line
file.write('Kumar\n')     #.write for passing strings
file.write('Jha\n')

list=['rides',' Royal',' Enfield',' Thunderbird 350x']  #Writing list of lines
file.writelines(list)
print('Data written successfully to the file xyz.txt')
file.close()  #We also need to close the file for it to write on disk

'''
Here we can override only not append to file.
If we want to perform append we need to take 'a' instead of 'w'
append will always add the output but override will always show the latest data

To open a file from windows command prompt we need to use command type
type xyz.txt

By Unix command prompt we use command cat
'''
