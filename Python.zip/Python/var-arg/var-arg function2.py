#Using Positional Arguement and var-arg arguement together

def sum(name,*marks):                     
    result=0
    for element in marks:
        result=result+element
    print('The marks of',name,':',result)
sum('Minu',10,50,90) 
sum('Aishwarya',80,50,40)
sum('Prashant',10,20,100)
sum('Rekha',70,90,30)
sum('Raj',80,30,40)



#The marks of Minu : 150
#The marks of Aishwarya : 170
#The marks of Prashant : 130
#The marks of Rekha : 190
#The marks of Raj : 150



# name is Positional and (*marks) is var-arg function
#We need to pass the positional arguement like we passed the different names
#var-arg, we can pass any number of arguements
#var-arg is denoted by *

#We can also take Positional arguement first than var-arg arguement but in that case we need to pass as the keyword arguement
#def sum(*marks,name):
#sum(10,50,90,name='Minu')          Here the positional arguement should come first
#sum(80,50,40,name='Aishwarya')
