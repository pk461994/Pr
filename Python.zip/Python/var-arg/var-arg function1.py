def sum(*input):                     # sum(*input) var-arg function
    result=0
    for element in input:
        result=result+element
    print('The sum is:',result)
sum()
sum(10)
sum(10,20)
sum(10,20,30)
sum(10,20,30,40)




#The sum is: 0
#The sum is: 10
#The sum is: 30
#The sum is: 60
#The sum is: 100
