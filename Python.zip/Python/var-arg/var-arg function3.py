def display(**kwargs):              #Keyword variable length arguement denoted by **
    print('Records Information:')
    for k,v in kwargs.items():
        print(k,'..........',v)
display(name='Durga',marks=100,age=48,GF='Sunny')
display(name='Ravi',wife='Nandita',child1='Akash',child2='Aditi')


#Output:
#Records Information:
#name .......... Durga
#marks .......... 100
#age .......... 48
#GF .......... Sunny
#Records Information:
#name .......... Ravi
#wife .......... Nandita
#child1 .......... Akash
#child2 .......... Aditi


#Variable no of arguements. Everytime we are passing keywords by keywords. So it is Keyword variable length arguement
