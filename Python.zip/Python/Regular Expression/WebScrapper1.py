import re,urllib
import urllib.request
u=urllib.request.urlopen('https://www.redbus.in/info/contactus')
text=u.read()
numbers=re.findall('[0-9]{3-4}[- ][0-9-]+',str(text))
for n in numbers:
    print(n)


'''
[0-9]{3-4}[- ][0-9-]+
[0-9]{3-4}   0 to 9 numbers 3 or 4 times
[- ]         - or empty space
[0-9-]+     0 to 9 with -, any number of times
'''
