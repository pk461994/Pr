import re
s=input('Enter mobile number to validate:')
m=re.fullmatch('[6-9]\d{9}',s)  #\d means 0 to 9 and {9} means 9 times
if m!=None:
    print(s,'is valid mobile number')
else:
    print(s,'is not a valid mobile number')

'''
[6-9]\d{9} means 1st no is 6 to 9
\d means 0 to 9 and {9} means 9 times
\d will pick any no between 0 to 9 and \d will be executed 9 times

[6789][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]
[6789][0-9]{9}
'''
