#To check mail ID is correct or not

import re
s=input('Enter mail ID:')
m=re.fullmatch('\w[a-zA-Z0-9_.]*@[a-z0-9]+[.][a-z]+',s)
if m !=None:
    print('Valid mail ID')
else:
    print('Invalid mail ID')


'''
\w[a-zA-Z0-9_.]*@[a-z0-9]+[.][a-z]+

\w is for alphanumeric char. Bz mail ID 1st letter may start from characters or digits
Than from 2nd letter it may be a-z, A-Z, 0-9, _, .
_ may be there or . may be also there so we took all
And this will be repeated any number of times even 0 number of times so we took *

[a-z0-9]+
like gmail or yahoo or it may contain numeric so we took like this and
we took + so that atleast 1 char or digit should be there

[a-z]+
like .com or .net

If we want only gmail or reddifmail, we can take in place of [a-z0-9]+
(gmail | rediffmail)
'''
