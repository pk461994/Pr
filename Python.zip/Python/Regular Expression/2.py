#To search anything in a string with start end index and also the group

import re
count=0
#pattern=re.compile('ab')   #Creating pattern object
#matcher=pattern.finditer('abaaabaabababaaab')
matcher=re.finditer('ab','abaaabaabababaaab')
for match in matcher:
    count+=1
    print('start: {}, end: {}, group: {}'.format(match.start(),match.end(),match.group()))
    print('The number of occurences is:',count)
    print()

'''
Instead of writing:
pattern=re.compile('ab')   
matcher=pattern.finditer('abaaabaabababaaab')

We can also simplify in one line like

matcher=re.finditer('ab','abaaabaabababaaab')

end() method always returns end+1 index
group() returns the matched pattern
'''
    
