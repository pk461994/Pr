import re
s='Learning Python is EASY'
res=re.search('Easy$',s,re.IGNORECASE)

if res!=None:
    print('Target string ends with Easy')
else:
    print('Target string does not end with Easy')

'''
re.IGNORECASE to ignore the case. Like upper or lower case. For case insensitivity
Easy$, we put $ to identify whether string ends with Easy
^Easy will be used for checking whether  it starts with Easy
'''
