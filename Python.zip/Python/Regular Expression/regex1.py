import re
emails='''
prashantkumar461994@gmail.com
pk461994@gmail.com
corey-321-schafer@my-work.net
rekha_kumari@gmail.com
aish.sharma@yahoo.co.in
prashantkumar@gmail.com
'''
#matches = re.finditer( r'[a-zA-Z0-9.-]+@[a-zA-Z-]+\.(com|co.in|net)',emails )
matches = re.finditer( r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-z A-Z 0-9-.]+' , emails )
for match in matches:
    print(match)