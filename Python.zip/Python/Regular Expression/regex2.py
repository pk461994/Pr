import re
urls='''
https://www.google.com
http://coreyms.com
https://youtube.com
https://www.nasa.gov
'''

#matches = re.finditer(r'https?://(www.)?[a-zA-Z0-9]+[.a-zA-Z0-9.]+' , urls)
matches = re.finditer(r'https?://(www.)?(\w+)(.\w+)' , urls)
for match in matches:
    #print(match)
    #print(match.group(0))  # group(0) is the entire match
    #print(match.group(1))  # group(1) will be the optional www
    #print(match.group(2))  # group(2) will be the domain name like google or youtube
    print(match.group(3))  # group(3) will be the top level domain like .com or .gov
