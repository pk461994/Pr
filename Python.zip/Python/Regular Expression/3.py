import re
matcher=re.finditer('[a-zA-Z0-9]','a7b@k9z')
for m in matcher:
    print(m.start(),'.....',m.group())
    
