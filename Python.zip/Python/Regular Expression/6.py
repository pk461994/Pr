import re
l=re.split('[.]','www.durgasoft.com')
for x in l:
    print(x)

'''
If we take some symbol within [] it will be considered as a symbol
Or we can give like \.  instead of .
. means all and it'll split every characters and nothing will be shown as output
'''
