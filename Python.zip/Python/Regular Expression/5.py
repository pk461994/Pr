import re
t=re.subn('\d','xxxx','a7b9k5t9k')
print(type(t))
print('The Result string:',t[0])
print('The number of replacements:',t[1])

'''
subn will replace chars
Return type of subn is tuple
1st value is result string i.e, t[0]
2nd is number of replacements that happened i.e, t[1]
'''
