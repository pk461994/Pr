import re
s=input('Enter pattern to be checked:')
m=re.search(s,'abcdefgh123133$%bdsc154cfdcvdfs414cvfecv1')

if m!=None:
    print('Match is available')
    print('Start index: {} and End index: {}'.format(m.start(),m.end()))
else:
    print('Match is not available at the beginning of the string')


'''
match will only follow at the starting of string
fullmatch will match the full string
search will give match of first occurance only
'''
