#To extract all mobile nos present in input.txt file

import re
f1=open('input.txt','r')
f2=open('output.txt','w')
for line in f1:
    list=re.findall('[6-9]\d{9}',line)    #Finding matched mobile number from line. List contains all the infos
    for number in list:
        f2.write(number+'\n')             #Writing those numbers from list to f2 which eventually writes to output.txt
print('Extracted all mobile nos from input.txt to output.txt')
f1.close()
f2.close()
