import re,urllib
import urllib.request
sites=['https://google.com','https://rediff.com']
for s in sites:
    print('Searching...',s)
    u=urllib.request.urlopen(s)     #This is to open the site. We put s as arguement. It'll search each s in sites
    text=u.read()                   #Getting text related to sites
    #print(text)
    title=re.findall('<title>.*</title>',str(text),re.I)
    print(title[0])


'''
title=re.findall('<title>.*</title>',str(text),re.I)
3 things will be there,
1-   pattern i.e, <title>.*</title>
2-   where we required to search ans we took that for str(text)
3-   re.IGNORECASE to ignore the case sensitivity. We can take re.I also in place of re.IGNORECASE
'''
