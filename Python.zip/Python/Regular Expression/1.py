#To search anything in a string

import re
count=0
pattern=re.compile('ab')    #Creating pattern object
matcher=pattern.finditer('abaaabaabababaaab')     #Iterator object
print(type(matcher))
for match in matcher:
    count+=1            #count=count+1
    print('match is avaiable at start index:',match.start())
    print('match is avaiable at end index:',match.end())   #Always shows end+1 in result
    print()
print('The number of occurenes is:',count)


'''
Instead of writing:
pattern=re.compile('ab')   
matcher=pattern.finditer('abaaabaabababaaab')

We can also simplify in one line like

matcher=re.finditer('ab','abaaabaabababaaab')

end() method always returns end+1 index
group() returns the matched pattern
'''
