import re
urls='''
https://www.google.com
http://coreyms.com
https://youtube.com
https://www.nasa.gov
'''

subbed_urls = re.sub(r'https?://(www.)?(\w+)(.\w+)',r'\2\3',urls)
print(subbed_urls)

'''
sub means substitution or replacement
re.sub(regex,replacement,targetstring)
In the target string every matched pattern will be replaced with provided replacement.
'''