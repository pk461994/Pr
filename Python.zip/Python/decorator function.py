def decor(func):           #Decorator function
    def inner(name):
        if name=='Kim':
            print('Hey Kim! I Love You')  
        else:
            func(name)
    return inner

@decor   #This will give the wish(name) as the arguement to decor(func), No need to pass anything as arguement
         #   @ symbol is used befor any function to make as Decorator function
def wish(name):
    print('Hello',name,'You are my friend')

wish('Sunny')
wish('Anjolina')
wish('Camella')
wish('Kim')

#Hello Sunny You are my friend
#Hello Anjolina You are my friend
#Hello Camella You are my friend
#Hey Kim! I Love You


'''  @decor will automatically call the decor function which returns inner(). @ symbol is used befor any function.
Here bz of @decor, wish() function will never execute. decor(func) will execute which returns inner().
wish() will be the input for decorator decor(). Than it returns inner which will provide some value
So inner executes. There the condition will be checked
It'll give wish(name) as the arguement to decor(func)
Now it'll start from decor(func) and goes into inner(name) function. Now the name will be matched
It'll check the name if it is Kim than it'll print the statement
If it is diff, than it'll call func(name). As the func has the arguement wish So it will print acc to wish(name)

Decorator function is function that takes other function as input and provide output function with extended functionality
Purpose of Decorator function is, without modifying existing function, extend its functionality'''
