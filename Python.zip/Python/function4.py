def wish(marks,age,name='Guest',msg='Good Morning'):    #While declaring, default arguement should be at last like name='Guest',msg='Good Morning'
    print('Student Name:',name)
    print('Student age:',age)
    print('Student Marks:',marks)
    print('Message:',msg)
wish(100,age=48,msg='Good Afternoon') #Positional arguement should be first followed by Keyword arguement

#Student Name: Guest
#Student age: 48
#Student Marks: 100
#Message: Good Afternoon
