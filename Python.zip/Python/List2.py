list=eval(input('Enter some List:'))
for x in list:
    if x%2==0:
        print('The character',x,'is Even')
    else:
        print('The character',x,'is Odd')

#Output:
#Enter some List:1,2,3,4,5
#The character 1 is Odd
#The character 2 is Even
#The character 3 is Odd
#The character 4 is Even
#The character 5 is Odd
