from django.shortcuts import render
from testapp import forms
# Create your views here.
def student_view(request):
    form=forms.StudentForm()
    if request.method=='POST':
        form=forms.StudentForm(request.POST)
        if form.is_valid():
            form.save(commit=True) #Here form default value is true so we can also take form.save instead of form.save(commit=True)
            print('Form Data Inserted into DB')
    return render(request,'testapp/register.html',{'form':form})
