from django.shortcuts import render
from testApp.models import Employee

# Create your views here.
def home(request):
    return render(request,'testApp/home.html')

def profile(request):
    return render(request,'testApp/profile.html')

def empview(request):
    emp_list=Employee.objects.all()   #To get employees data. To get Employee model class data in views.py
    my_dict={'emp_list':emp_list}
    return render(request, 'testApp/emp.html', context=my_dict)

def index(request):
    return render(request,'testApp/index.html')


'''
We're geetting employee information by using emp_list=Employee.objects.all()
And then we're sending those infos to template file
'''
