from django.contrib import admin
from testApp.models import Employee

#Model admin class to show eno and ename in admin console and register the class
class EmployeeAdmin(admin.ModelAdmin):  #Arguement has to be only admin.ModelAdmin
    list_display=['id','eno','ename','esal','eaddr']

# Register your models here.
admin.site.register(Employee,EmployeeAdmin)

'''
We're registering Employee from model.py to this admin.py
We're doing so bz when we open admin url there Employee table should be there
We're registering Employee table from model.py to admin.py to see the table in admin interface
'''
