from django.shortcuts import render
from . import forms

# Create your views here.
def studentregisterview(request):
    form=forms.StudentRegistration() #form object of StudentRegistration class
    return render(request,'testapp/register.html',{'form':form})

#creating form object and sending the form object as an arguement to testapp/register.html file
