from django.shortcuts import render
from testapp.models import Tenant
from testapp.forms import TenantForm
# Create your views here.
def index_view(request):
    return render(request,'testapp/index.html')

def add_tenant_view(request):
    form=TenantForm()
    if request.method=='POST':
        form=TenantForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
        return index_view(request)
    return render(request,'testapp/addtenant.html',{'form':form})

def list_tenant_view(request):
    tenant_list=Tenant.objects.all()
    return render(request,'testapp/listtenant.html',{'tenant_list':tenant_list})
