from django.db import models

# Create your models here.
class Tenant(models.Model):
    tname=models.CharField(max_length=30)
    tage=models.IntegerField()
    tgender=models.CharField(max_length=30)
    tmobile1=models.IntegerField()
    tmobile2=models.IntegerField()
    tmobile3=models.IntegerField()
    tcity=models.CharField(max_length=30)
    tcountry=models.CharField(max_length=30)
    tlocation=models.CharField(max_length=30)
