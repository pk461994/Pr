from django.contrib import admin
from testapp.models import Tenant
# Register your models here.
class TenantAdmin(admin.ModelAdmin):
    list_display=['tname','tage','tgender','tmobile1','tmobile2','tmobile3','tcity','tcountry','tlocation']
admin.site.register(Tenant,TenantAdmin)
