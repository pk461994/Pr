from django.db import models
from django.contrib.auth.models import User
from PIL import Image

class Profile(models.Model):
    user=models.OneToOneField(User, on_delete=models.CASCADE) #CASCADE meaans if user is deleted also delete the profile. But if we delete profile don't delete the User
    image=models.ImageField(default='default.jpg', upload_to='profile_pics') #upload_to for uploading to profile_pics directory.
    def __str__(self):
        return f'{self.user.username} Profile'

    def save(self):
        super().save()
        img = Image.open(self.image.path)
        if img.height > 300 or img.width > 300:
            output_size= (300,300)
            img.thumbnail(output_size)
            img.save(self.image.path)
