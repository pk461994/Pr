from django.db.models.signals import post_save  #post_save will hit once the data is saved
from django.contrib.auth.models import User  #User will be the sender
from django.dispatch import receiver         #receiver will be the receiver of the signal
from .models import Profile

#We want a User profile to be created for each new user. So we take 2 functions to create and save profile

@receiver(post_save, sender=User)
def create_profile(sender,instance,created,**kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_profile(sender,instance,**kwargs):
    instance.profile.save()



'''
Earlier we have to go to admin page to create profile and provide the default image.
But we want to make sure for every new user created they automatically get a profile as well which will include default profile picture as well.
For that we use Django signals
When a user is saved then send post_save signal. Signal will be received by the receiver. receiver is create_profile function
And there are diff arguments passed by post_save. So if user created than create profile object with user=instance that was created
'''
