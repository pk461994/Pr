'''
Singleton will create an object and when you try to make new it will refer to same object.
'''

# class SingleTon(object):
#     def __new__(cls, *args,**kwargs):
#         if not hasattr(cls,'_instance'):
#             cls._instance = super().__new__(cls,*args,**kwargs)
#         return cls._instance

# o1 = SingleTon()
# print('Object 1 present at ==>', o1)
# o1.data = 10
# print('Object 1 Data ==>', o1.data) # 10
# o2 = SingleTon()
# print('Object 2 present at ==>', o2)
# print('Object 2 Data ==>', o2.data) # 10 As o1 and o2 share the state with each other
# o2.data = 5
# print('Object 1 Data ==>', o1.data) # 5
# print('Object 2 Data ==>', o2.data) # 5 As o1 and o2 share the state with each other

class Man(object):
    _shared = {}
    def __init__(self):
        self.__dict__ = self._shared

class SingleTon(Man):
    def __init__(self,arg):
        Man.__init__(self)
        self.val = arg

o1 = SingleTon('Prashant')
print('Object 1 present at ==>', o1)
print('Object 1 value ==>', o1.val)
o2 = SingleTon('Suman')
print('Object 2 present at ==>', o2)
print('Object 2 value ==>', o2.val)
print('Object 1 value ==>', o1.val) # As o1 and o2 share the state with each other


