# Decorator is a function that takes another function as arguement add functionality and return another function

# Example 1

def outer_func(msg):
    message = msg
    def inner_func():
        print(msg) # Or print(message)
    return inner_func
my_func1 = outer_func('Hi There')
my_func2 = outer_func('How Are You')
my_func1()
my_func2()
print()
print("--------*********------------***************---------------***************")
print()

'''
Example 2
Here we are using same decorator function for "display" function with no arguements and "display_info" function with 2 arguements.
For this we need to pas *args, **kwargs to take any number of arguements and keywords arguements in our wrapper_function and original_function
'''

def decorator_function(original_function):
    def wrapper_function(*args,**kwargs):
        print(f'Wrapper function ran before "{original_function.__name__}" function')
        return original_function(*args,**kwargs)
    return wrapper_function

@decorator_function
def display():
    print('Display Function ran')

@decorator_function
def display_info(name,age):
    print(f'display_info function ran with the arguement ({name}, {age})')

decorated_function = decorator_function(display) # When we pass in display then display = original_function within deccorator
decorated_function()
display()
display_info('Prashant',25)
print()
print("--------*********------------***************---------------***************")
print()

'''
Example 3
Using Class as decorator instead of function as decorator
'''
class decorator_class(object):
    def __init__(self, original_function):          #Passing original_function to decorator_class using __init__ method
        self.original_function = original_function
    
    def __call__(self, *args, **kwargs):            #TO make class callable. Adding functionality to our original_function using __call__ method
        print(f'Call Method ran before "{self.original_function.__name__}" function')
        return self.original_function(*args, **kwargs)

@decorator_class
def display():
    print('Display Function ran')

@decorator_class
def display_info(name,age):
    print(f'display_info function ran with the arguement ({name}, {age})')
display()
display_info('Prashant',25)
print()
print("--------*********------------***************---------------***************")
print()

'''
Example 4
Realtime with Logging module
'''
from functools import wraps

def my_logger(orig_function):
    import logging
    logging.basicConfig(filename = f'{orig_function.__name__}.log', level=logging.INFO)

    @wraps(orig_function)
    def wrapper_func(*args, **kwargs):
        logging.info(f'Ran with args : {args} and kwargs : {kwargs}')
        return orig_function(*args, **kwargs)
    return wrapper_func

def my_timer(orig_function):
    import time

    @wraps(orig_function)
    def wrapper(*args, **kwargs):
        time1 = time.time()
        result = orig_function(*args, **kwargs)
        time2 = time.time() - time1
        print(f'{orig_function.__name__} ran in : {time2} sec')
    return wrapper          # Return unexicuted wrapper function to allow all the added functionality to original_function

import time
@my_logger
@my_timer
def display_info(name,age):
    time.sleep(1)
    print(f'display_info function ran with the arguement ({name}, {age})')

# my_func = my_timer(display_info)  #passing display_info to my_timer and my_timer return wrapper 
# print(my_func.__name__)

# my_func = my_logger(my_timer(display_info))   # passing display_info to my_timer and again to my_logger my_logger returns wrapper_func
# print(my_func.__name__)

display_info('Rekha',45)

'''
my_func = my_logger(my_timer(display_info))
This would be stacked version of @my_logger followed by @my_timer
Lower one i.e, my_timer executed first than higher one my_logger executed
We're passing display_info to my_timer. my_timer() uses wrapper to add timing functionality to original_function

So when we passed like my_func = my_logger(my_timer(display_info))
my_timer(display_info) returns wrapper
and now the orig_function in my_logger(orig_function) is not same as display_info function. Now it is equal to wrapper which is returned by my_timer
So the log file got created by the name of wrapper.log instead of the function_name.log

To overcome this we use wraps
'''

def decor(func):
    def inner(name,*args,**kwargs):
        if name == 'Sunny':
            print('Hello',name,'Good night')
        else:
            func(name,*args,**kwargs)
    return inner
@decor
def wish(*name):
    print(name,'Good morning')
@decor
def age_name(name,age):
    print(name,age)
wish('Durga', 'Das')
wish('Sunny')
age_name('pkj',26)
age_name('rkj',49, 'golu', 28)