# 1------>
# s=input('Enter some string: ')
# l = s.split()
# l1=[]
# i=0
# while i<len(l):
#     l1.append(l[i][::-1])
#     i = i+1
# output=' '.join(l1)
# print(output)

# 2-------->
# s=input('Enter some string: ')
# l = s.split()
# l1=[]
# i = len(l)-1
# while i>=0:
#     l1.append(l[i])
#     i= i-1
# output = ' '.join(l1)
# print(output)


# 3---------->
# a=[1,2,3]
# b=[]
# for i in range(1,3):
#     b.append(a)
# a.append(5)
# print(b)
# print(a)

# 4------------>
# s= 'Prashant Jha'
# s = s.replace('Prashant','Aishwarya')
# print(s)

# 5-------------->
# Track the position in a list of strings
# sample = 'Prashant Kumar Jha'
# names= sample.split()
# pos = 0
# for name in names:
#     print(f'{pos} ----> {name}')
#     pos += 1

# 6-------------->
# import re
# regex = re.sub('\$noun\$', 'the heck', 'What $noun$ is $verb$?')
# print(regex)

# 7-------------->
# Track the position in a list of strings using Enumerate
sample = 'Prashant Kumar Jha'
names= sample.split()

for pos, name in enumerate(names):
    print(f'{name} is present at ------> {pos}')

def find_position(names, target):       # Enumerate will takes a list as input from where we'll match the target string
    for pos, name in enumerate(names):
        if name == target:
            return pos
    return -1
print('Position of a particular word is: ',find_position(names,'Kumar'))


# 8--------------> THREADING MODULE
# import threading
# import concurrent.futures
# import time
# start = time.perf_counter()

# def do_something(seconds):
#     print(f'Sleeping for {seconds} sec(s)')
#     time.sleep(seconds)
#     return f'Done Sleeping.... {seconds} second(s)'

# with concurrent.futures.ThreadPoolExecutor() as executor:
    # f1 = executor.submit(do_something, 1)                   # submit() method schedules a fucntion to be excuted and return a future object. 1 is for arguement for how many seconds it'll sleep
    # f2 = executor.submit(do_something, 1.5)                 # Sleep for 1.5 seconds. 1.5 will be the arguement for do_something function
    # print(f1.result())
    # print(f2.result())

    # secs = [5,4,3,2,1]
    # results = [executor.submit(do_something, sec) for sec in secs]
    # for f in concurrent.futures.as_completed(results):          # as_completed will give the results in the order it completed. So 1,2,3,4,5
    #     print(f.result())

    # results = executor.map(do_something, secs)                    # map will give the results in the order it started. So 5,4,3,2,1
    # for result in results:
    #     print(result)

# threads = []
# for _ in range(10):                                           # _ in for loop is throwaway variable. THis is used when we're not doing anything just we need to loop
#     t = threading.Thread(target= do_something, args=[1.5])    # args will be arguement for do_something function which will sleep for 1.5 secs
#     t.start()
#     threads.append(t)
# for thread in threads:
#     thread.join()

# do_something()
# finish = time.perf_counter()
# print(f'Finished in {round(finish-start, 2)} second(s)')

# def data(klass):
#     class Decorator(klass):
#         def __repr__(self):
#             return f'<{klass.__name__} object {str(self.__dict__)}>'
#     return Decorator

# @data
# class Person:
#     def __init__(self, name, age):
#         self.name = name.capitalize()
#         self.age = age
# p = Person('prashant', 25)


# def is_leap(year):
#     return True if year%4==0 and (year%100!=0 and year%400==0) else False
# year=input('Enter a number: ')
# print(year)
# print(is_leap(year))