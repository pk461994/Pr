Palindrome check
word = 'wow'
p = bool(word.find(word[::-1]) + 1)
print(word.find('wow'))
print(p)
print(bool(1)) if word[:] == word[::-1] else print(bool(0))

# Sum of all even numbers up to n
n = 10
s = sum( (range(n+1))[::-2] )
print('Sum of all even numbers:',s)

# Read lines of file into a list
# f='myfile.txt'
# lines = [lines.strip() for line in open(f)]

# Factorial
from functools import reduce
n=5
factorial = reduce(lambda x,y : x*y, range(1, n+1))
print('Factorial:',factorial)

#Fibonacci numbers
fib = lambda n : n if n<=1 else fib(n-1) + fib(n-2)
result = fib(10)
print('Fibonacci numbers:', result)

# Unzip
z = [(1,2), (3,4), (5,6), (7,8)]
unzip = lambda z: list(zip(*z))
result = unzip(z)
print('Unzip:', result)

# Get the first and last element in the list
l = [1,2,3,4,5,6,7]
first, *x, last = l
print(f'First is {first} and last is {last}')