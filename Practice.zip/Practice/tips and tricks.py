# Terniory condition

condition = True
x = 1 if condition else 0
print(x)
print("--------*********------------***************---------------***************")

# Working with large numbers
num1 = 10_000_000_000
num2 = 10_000_778
total = num1 + num2
print(f'{total:,}')
print("--------*********------------***************---------------***************")

# Enumerate function to loop over a list
names = ['Prashant','Aishwarya','Suman','Rekha']
# index = 0
# for name in names:
#     print(index,name)
#     index+=1

for index,name in enumerate(names, start=1):    #start=1 to start the index value from 1
    print(index,name)
print("--------*********------------***************---------------***************")

num = [1,2,3,4]
for i,j in enumerate(num, 1):  # 1 is for start index in this case its 1. By default it is 0. So now i=1 j=1, i=2 j=2, i=3 j=3, i=4 j=4
    print('Sum:',i+j, sep= ' ')
print("--------*********------------***************---------------***************")


# Enumerate to access from 2 lists
names = ['Gangadhar','Peter','Clark','Wade','Bruce']
heroes = ['Shaktiman','Spiderman','Superman','Deadpool','Batman']

for index,name in enumerate(names): #Here we got the index from names. Then we use that index to match with heroes
    hero = heroes[index]
    print(f'{name} is actually {hero}. We got using Enumerate')
print("--------*********------------***************---------------***************")

# Zip to access from 2 or more lists. If lists are of different length then Zip will work till shortest list is exhausted
names = ['Gangadhar','Peter','Clark','Wade','Bruce']
heroes = ['Shaktiman','Spiderman','Superman','Deadpool','Batman']
universes = ['Doordarshan','Marvel','DC','Marvel','DC']

for name, hero, universe in zip(names,heroes,universes):        #We can pass any number of lists in zip
    print(f'{name} is actually {hero} from {universe}. We got using Zip')
print("--------*********------------***************---------------***************")

# Unpacking
# _ is used to ignore a variable and it won't be used anywhere in the code
a, _ = (1,2)
print(a)

a, b, *c = (1,2,3,4,5,6,7,8,9,10)  #a=1, b=2 and rest will be assigned to c as it has prefix as *
print(a)
print(b)
print(c)

a, b, *c, d = (1,2,3,4,5,6,7,8,9,10) #a=1, b=2 and rest upto last one will be assigned to c as it has prefix as * and d=10
print(a)
print(b)
print(c)
print(d)

a, b, *_, d = (1,2,3,4,5,6,7,8,9,10) #a=1, b=2 and rest upto last one will be ignored as we used *_ (_ used to ignore) and d=10
print(a)
print(b)
# print(c)
print(d)
