__title__ = 'More Function'
__author__ = 'Prashant Jha'
__email__ = 'pk461994@gmail.com'
__twitter__ = 'prashantjha'

# from builtins import print as _print
# def print(*args, first = [True], **kwargs):
#     _print(*args, **kwargs)
#     if first and first.pop():
#         _print(f'Follow me on twitter @{__twitter__}')
#     else:
#         _print(f'@{__twitter__}')

# if __name__ == '__main__':
    # print(__title__)
    # print(__author__)
    # print(__twitter__)

z = 0
def add1(x,y):
    'add x to y'
    global z
    z += 1
    return x+y+z

def add1( z=0 ):
    def add1(x,y):
        'add x to y'
        nonlocal z
        z += 1
        return x+y+z
    return add1

add2 = lambda x,y: x+y

add2.__doc__='add x to y'
add2.__name__='add2'

print(f'add1: {add1(1,2)}')
print(f'add2: {add1(3,4)}')
# help(add1)
# help(add2)

class Adder:
    def __init__(self):
        pass
    def __call__(self, x, y):
        return x+y
add3 = Adder()
print(f'add3: {add3(4,5)}')