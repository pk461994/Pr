from time import time

def timer(func, a, b):
    before = time()
    between = func(a, b)
    after = time()
    print('Duration', after - before)
    return between

def add(a, b):
    return a+b

def sub(a, b):
    return a-b

print(timer(add, 10, 30))
print(timer(sub, 100, 200))

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~###################################~~~~~~~~~~~~~~~~~~~~~~~~~

def timer(func):
    def inner(*args, **kwargs):
        before = time()
        between = func(*args, **kwargs)
        after = time()
        print('Duration', after - before)
        return between
    return inner

# Execute the main function n numnber of times
def ntimes(n):
    def inner(func):
        def wrapper(*args, **kwargs):
            for _ in range(n):
                print(f'Running : {func.__name__}')
                rv = func(*args, **kwargs)
            return rv
        return wrapper
    return inner

@ntimes(2)
# @timer
def add(*n):
    total = 0
    for element in n:
        total = total + element
    return f'The sum is : {total}'
# add = timer(add)

@ntimes(3)
# @timer
def mul(*n):
    mul = 1
    for element in n:
        mul = mul * element
    return f'The multiplication is : {mul}'

@ntimes(2)
# @timer
def sub(a,b):
    return a-b
# sub = timer(sub)

# print(add(1123, 312))
# print(sub(342, 111))

print(add(1123, 312))
print(add(1000, 20000))
print(mul(1,3,4,5,5,3,2,1))
print(sub(342, 111))