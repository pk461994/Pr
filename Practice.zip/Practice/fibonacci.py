# Fibonacci Sequence

# 1st way. This will take time if we don't import lru_cache from functools if and if we increase the range like range(1, 101)
# lru stands for least recently used

from functools import lru_cache

@lru_cache(maxsize = 1000)      # If we don't specify maxsize python will take 128 as default
def fibonacci(n):

    #Check if the arguement is a positive integer
    if type(n) != int:
        raise TypeError('n must be a positive integer value')
    if n<1:
        raise ValueError('n must be a positive integer value')

    if n == 1:
        return 1
    if n == 2:
        return 1
    elif n>2:
        return fibonacci(n-1) + fibonacci(n-2)      # Using recurssion

for number in range(1,501):
    print(number, ':', fibonacci(number))
# print(fibonacci(-1))
# print(fibonacci('one'))


print('------------------****************-------------------------###########################--------------------')

# 2nd way using memorization. Speed up performance. But this is not clean and is tough to read

fibonacci_cache = {}

def fibonacci_memorization(n):
    # If we've cached the value than return it
    
    if n in fibonacci_cache:
        return fibonacci_cache[n]
    # Compute the Nth term
    if n == 1:
        value = 1
    if n == 2:
        value = 1
    if n > 2:
        value = fibonacci_memorization(n-1) + fibonacci_memorization(n-2)
    
    # Cache the value and return it
    fibonacci_cache[n] = value
    return value

for number in range(1,101):
    print(number , ':',fibonacci_memorization(number))


# 3rd way to use fibonacci using generator

def fib():
    a,b = 0,1
    while True:
        yield a
        a,b = b, a+b
for f in fib():
    if f>100:
        break
    print(f)

import profile
def fib_without_memoization(n):
    if n == 1:
        return 0
    if n == 2:
        return 1
    return fib_without_memoization(n-1) + fib_without_memoization(n-2)
profile.run("print(fib_without_memoization(20))")

import profile
def fib(n, memo):
    if n in memo:
        return memo[n]
    # if n == 2:
    #     return 1
    print('memo',memo[n-1])
    memo[n-1] = fib(n-1, memo)
    memo[n-2] = fib(n-2, memo)
    return memo[n-1] + memo[n-2]
# print(fib(20, {1:0,2:1,3:1}))
profile.run("print(fib(20, {1:0,2:1,3:1}))")