from pandas import DataFrame
from inspect import signature


class Resistor:
    # __slots__ = __fields__ = 'number', 'manufacturer', 'resistance'      #We cannot add any other objects apart from objects defined in __slots__
    def __init__(self, number, manufacturer, resistance):
        if resistance < 0:
            raise ValueError('Resistance must be Positive')
        self.number, self.manufacturer, self.resistance = number, manufacturer, resistance
    
    #property - its something that doen't need to know any information other than the current state of the object
    @property
    def resistance(self):
        return self._resistance

    @resistance.setter
    def resistance(self, value):
        if value < 0:
            raise ValueError('Resistance must be Positive')
        self._resistance = value

    # def get_resistance(self):
    #     return self.resistance

    # def set_resistance(self, value):
    #     if value < 0:
    #         raise ValueError('Resistance must be Positive')
    #     self.resistance = value
    
    def __repr__(self):
        
        fields = signature(self.__init__).parameters
        values = ', '.join(repr(getattr(self, f)) for f in fields)
        return f'{type(self).__name__}({values})'

        # return f'Resistor("{self.number}", "{self.manufacturer}", {self.resistance})'

        # return f'Resistor({self.number}, {self.manufacturer}, {repr(self.resistance)})'

        # return (f'{type(self).__name__}({self.number!r},'
        #                             f' {self.manufacturer!r},'
        #                             f' {self.resistance!r})')

    def __eq__(self,other):
        return self.number == other.number


'''
# dataclasses - This module provides a decorator and functions for automatically adding generated special methods such as __init__() and __repr__() to user-defined classes. 
# Here we're creating Resistor class again using dataclass and the code has reduced drastically

from dataclasses import dataclass
@dataclass
class Resistor:
    __slots__ = __fields__ = 'number', 'manufacturer', 'resistance' 
    number          : str
    manufacturer    : str
    resistance      : float
    # resistance      : float = 101           # Assign  a default value for 'resistance' while creating object no need to pass resistance arguement
'''

class Product:
    def __init__(self, *components):
        self.components = DataFrame([
            [x.manufacturer , x.resistance] 
            for x in components
        ], columns = ['manufacturer', 'resistance'], index = [x.number for x in components])

    def __getitem__(self, number):
        x = self.components.loc[number]
        return Resistor(number, x.manufacturer, x.resistance)

class Potentiometer(Resistor):
    # __slots__ = __fields__ = *Resistor.__fields__, 'min_resistance', 'max_resistance'
    def __init__(self, number, manufacturer, resistance, min_resistance, max_resistance):
        if not min_resistance <= resistance <= max_resistance:
            raise ValueError('Resistance out of bounds')
        self.min_resistance = min_resistance
        self.max_resistance = max_resistance
        super().__init__(number, manufacturer, resistance)
    
    # def __repr__(self):
    #     return (f'{type(self).__name__}({self.number!r},'
    #                                 f' {self.manufacturer!r},'
    #                                 f' {self.resistance!r},'
    #                                 f' {self.min_resistance!r},'
    #                                 f' {self.max_resistance!r})')


class Network:
    def __init__(self, *connections):
        self.connections = connections
        self.elements = {x.number : x for uv in connections for x in uv if x is not None}
    
    def __len__(self):
        return len(self.elements)
    
    def __getitem__(self,number):
        return self.elements[number]
    
    def get_size(self):
        return len(self.elements)

class T:
    def __call__(self, x, y, *, mode=''):
        return x*2+y
    def __getitem__(self, xy):
        x, y = xy
        return x * 2 + y
    def f(self, x, y):
        return x * 2 + y

'''
Why to use classmethod.?
Let suppose our data is coming from other file, that file can be in xls or csv so everytime we need to put lots of conditions in our __init__ constructor which is bad practice. 
We should limit __init__ to only creation of objects because if we use __init__ we can have only one way to construct the objects. 
clasmethod gives a mechanism by which we can add to a class in several possible ways.
clasmethod is the method that gives us the class. classmethod is also the factory functions
Protocols that are not unique and priviledged but instead might be duplicatedin order to satisfy a variety of usecases
'''

class Multimeter:
    def __init__(self, *resistors):
        self.resistors = resistors
    @classmethod
    def from_file(cls, filename):
        with open(filename) as f:
            pass
        return cls(...)
    @classmethod
    def from_xls_file(cls, filename):
        with open(filename) as f:
            pass
        return cls(...)
    @classmethod
    def from_database(cls, filename):
        with open(filename) as f:
            pass
        return cls(...)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~-----------------OBJECT CREATION STARTS HERE------------------~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# mult = Multimeter.from_file('multimeter_data.json')
# print(f'{mult = }')

obj = T()
print(f'{obj(10,20) = }')
print(f'{obj[10,20] = }')
print(f'{obj.f(10,20) = }')

r = Resistor('10-232-122342', 'INTEL', 10)
# r.set_resistance(-10)
print(f'{r= }')
print(f'{r.resistance = }') #Using @property we can call methods as an arguement
# print(repr(r)) # Will print only resistor object if we don't define __repr__ method
# print( f'{  Resistor('10-232-122342', 'INTEL', 10) == r = }' )

p = Potentiometer('10-322-233','Qualcomm',15,10,20)
print(f'{p= }')

# n = Network(16)
# print(f'{n= }')

# from sys import getsizeof
# print(f'{getsizeof(Resistor(None, None, None)) = }')        # Give size of object in bytes

p = Product(
    Resistor('1-234-3453', 'INTEL', 1),
    Resistor('1-235-7453', 'Qualcomm', 2),
    Resistor('1-236-3859', 'SanDisk', 3),
)

print(f'{p.components.resistance.mean() = }')
print(f'{p["1-234-3453"] = }')


component = 'resistor', '10-23232-232', 10
if component[0] == 'resistor':
    print('component provided is Resistor')
if component[0] == 'capacitor':
    print('component provided is Capacitor')

from collections import namedtuple
Resistor = namedtuple('Resistor', 'number manufacturer resistance')
Capacitor = namedtuple('Capacitor', 'number manufacturer capacitance')
x = Resistor('1213-323-1','XXX',16)
if isinstance(x, Resistor):
    print('x is Resistor')
if isinstance(x, Capacitor):
    print('x is Capacitor')