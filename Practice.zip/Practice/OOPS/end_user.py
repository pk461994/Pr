from oops_starting import Base

assert hasattr(Base, 'foo'), 'You broke the code, you fool!!!'      
#To check whether the Base class has foo method. If not it'll throw error before executing Derived class

class Derived(Base):
    def bar(self):
        return 'bar'