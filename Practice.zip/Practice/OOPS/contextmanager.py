class temptable:
    def __init__(self, name):
        self.name , self.con= name, None
    
    def __repr__(self):
        return f'<temptable {self.name} {id(self)}>'

    def __enter__(self):
        import sqlite3
        self.con = sqlite3.connect('temp.db')
        cursor = self.con.cursor()
        cursor.execute(f'CREATE TABLE {self.name} (a int, b int)')
        cursor.close()
        self.con.commit()
        print('Table Created')
        return cursor

    def __exit__(self, t, value, traceback):
        cursor = self.con.cursor()
        cursor.execute(f'DROP TABLE {self.name}')
        cursor.close()
        self.con.close()
        print('Table Dropped')
        return True

if __name__ == '__main__':
    with temptable('sample') as t:         # as it's a contextmanager and we're returning cursor object in __enter__ so t will be cursor object
        t.execute('INSERT INTO sample VALUES (1,2)')
        t.execute('INSERT INTO sample VALUES (3,4)')
        t.execute('INSERT INTO sample VALUES (5,2)')
        t.execute('INSERT INTO sample VALUES (1,9)')
        t.execute('SELECT * FROM sample')
        print(t.fetchall())