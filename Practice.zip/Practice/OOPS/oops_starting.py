class Polinomial:
    def __init__(self, *coeffs):    # To initialize the object we use __init__
        self.coeffs = coeffs
    
    def __repr__(self):
        return f'Polinomial(*{self.coeffs})'
    
    def __add__(self,other):
        return Polinomial(*(x+y for x,y in zip( self.coeffs, other.coeffs )))

    def __len__(self):
        return len(self.coeffs)

p1 = Polinomial(1,2,3)
p2 = Polinomial(4,5,6)
print(p1)
print(p2)
print('Sum of polinomials:', p1+p2)

class BaseMeta(type):
    def __new__(cls, name, bases, body):
        if name != 'Base' and not 'bar' in body:
            raise TypeError('Bad User Class')
        # print('BaseMeta.__new__', cls, name, bases, body)
        return super().__new__(cls, name, bases, body)

class Base(metaclass = BaseMeta):
    def foo(self):
        return self.bar()
    
    def __init_subclass__(self, *a, **kw):
        print('init_subclass', a, kw)
        return super().__init_subclass__(*a, **kw)

old_bc = __build_class__
def my_bc(fun, name, base=None, **kw):
    if base is Base:
        print('Check if bar method is defined')
    if base is not None:
        return old_bc(fun, name, base, **kw)
    return old_bc(fun, name, **kw)

import builtins
builtins.__build_class__ = my_bc