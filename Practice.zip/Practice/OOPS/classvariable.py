class Employee:
    num_of_emps = 0
    raise_amount = 1.20
    def __init__(self, first, last ,pay):
        self.first = first  #We can put anything in place of self.first like self.fname or self.pk value after = is instance variable
        self.last  = last
        self.pay   = pay
        self.email = first+'.'+last+'@gmail.com'

        Employee.num_of_emps += 1

    def fullname():
        return f'{self.first} {self.last}'
    def apply_raise(self):
        self.pay = int(self.pay * self.raise_amount)

emp_1 = Employee('Prashant','Jha',100000)
emp_2 = Employee('Chandan','Jha',200000)
emp_1.apply_raise()
print('Employee 1 pay after rise in salary',emp_1.pay)
print(emp_1.raise_amount)
print(Employee.raise_amount)

Employee.raise_amount = 1.30
print(emp_2.raise_amount)
emp_2.apply_raise()
print(emp_2.pay)
print('Number of Employees are:',Employee.num_of_emps)