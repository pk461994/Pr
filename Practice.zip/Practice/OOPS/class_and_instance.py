'''
Class is a blue print to create instances
'''

class Employee:
    def __init__(self,first,last,pay):
        self.fname = first  #We can put anything in place of self.first like self.fname or self.pk value after = is instance variable
        self.last  = last
        self.pay   = pay
        self.email = first+'.'+last+'@gmail.com'

    def fullname(self):
        return f'{self.fname} {self.last}'

emp_1 = Employee('Prashant','Jha',100000)
emp_2 = Employee('Chandan','Jha',200000)
print(emp_1.fname)
print(emp_2)
print(emp_1.email)
print(emp_2.email)
print(emp_1.fullname())
print(Employee.fullname(emp_1)) # We need to pass the instance when we call method using Class name as class name doesn't know about the instance
print(emp_2.fullname())
print(Employee.fullname(emp_2))


class MyWallet:
    def __init__(self, nickels : int, dimes : int, pennies : int, material : str) -> None:
        self.nickels  = nickels
        self.dimes    = dimes
        self.pennies  = pennies
        self.material = material
    
    def __eq__(self,other):
        if other.__class__ is self.__class__:
            return (
                self.nickels  == other.nickels,
                self.dimes    == other.dimes,
                self.pennies  == other.pennies,
                self.material == other.material
            )
            return NotImplemented
    __hash__ = None

    def amount_in_wallet(self) -> float:
        return sum([self.nickels*5 , self.dimes*10 , self.pennies * 1]) / 100

    def __repr__(self):
        return(self.__class__.__qualname__
        + f'(nickels = {(self.nickels)!r}, dimes = {(self.dimes)!r}, pennies = {(self.pennies)!r}, material = {(self.material)!r})'
        )

from dataclasses import dataclass
# from DataclassInspector.inspector import Inspector
@dataclass()
class MyWallet:
    # __slots__ = 'nickles','dimes','pennies','material'
    nickels     : int
    dimes       : int
    pennies     : int
    material    : str

    def amount_in_wallet(self) -> float:
        return sum([self.nickels*5 , self.dimes*10 , self.pennies * 1]) / 100

wallet1 = MyWallet(10,15,20,'Gold')
print(wallet1.amount_in_wallet())
print(wallet1)
wallet2 = MyWallet(15,67,20,'Platinum')
print(wallet1 == wallet2)

# inspected = Inspector(MyWallet)
# print(inspected.code)