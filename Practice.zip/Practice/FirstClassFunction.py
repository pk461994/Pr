'''
Treats functions as First class citizen(First class objects). 
It can be assigned as an arguement, returned from a function, and assigned to a variable.
We can treat function as any other object or variable
'''

# def square(x):
#     return x*x
# f = square # We can use f as the square function.
# print(square)
# print(f(5))


# def square(x):
#     return x*x
# def cube(x):
#     return x*x*x

# def my_map(func, arg_list):
#     result = []
#     for i in arg_list:
#         result.append(func(i))
#     return result
# squares = my_map(square, [1,2,3,4,5])
# cubes = my_map(cube, [1,2,3,4,5])
# print(squares)
# print(cubes)



# def logger(msg):
#     def log_message():
#         print('Log:', msg)
#     return log_message
# log_hi = logger('Hi THere') #log_hi will act like a function so we need to call it
# log_hi()



def html_tag(tag):
    def wrapper(msg):
        print(f'<{tag}>{msg}</{tag}>')
    return wrapper

print_h1 = html_tag('h1')
print_h1('This is Prashant here')

print_p = html_tag('p')
print_p('I am a Developer')