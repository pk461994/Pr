nums = [1,2,3,4,5,6,7]
'''
Example 1
We want n*n for each 'n' in nums
'''
my_list = [n*n for n in nums]
print('my_list',my_list)
#Using map and lambda
my_map = list(map(lambda x:x*x, nums))
print('my_map',my_map)

'''
Example 2. We want 'n' for 'n' in nums if 'n' is even
'''
my_even = [n for n in nums if n%2==0]
print('my_even',my_even)

#Using filter function to get even numbers
my_filter = list(filter(lambda x:x%2==0, nums))
print('my_filter',my_filter)

'''
Example 3
We want a (letter,num) pair for each letter in 'abcd' and each number in '0123'
'''
my_result = []
for letter in 'abcd':
    for num in range(4):
        my_result.append((letter,num))
print('my_result',my_result)

#Using Comprehension
my_result_comp = [(letter,num) for letter in 'abcd' for num in range(4)]
print('my_result_comp',my_result_comp)

'''
Example 4
Dictionary Comprehension
'''
names = ['Bruce', 'Clark', 'Peter', 'Logan', 'Wade']
heros = ['Batman', 'Superman', 'Spiderman', 'Wolverine', 'Deadpool']
print (list(zip(names,heros)))  #zip matches 1 to 1 indexwise. Returns zip object so converted to list

#Using Dictionary
my_dict = {}
for name, hero in zip(names,heros):
    my_dict[name] = hero
print('my_dict',my_dict)

#Using dictionary comprehension with added condition if name=='Peter' don't add in our list
my_dict_comp = {name:hero for name,hero in zip(names,heros) if name!='Peter'}
print('my_dict_comp',my_dict_comp)

'''
Example 5
Set Comprehension
'''
nums = [1,2,3,3,4,1,1,1,2,2,2,3,3,3,3,4,4,4,5,5,5,5,5]
my_set = set()
for n in nums:
    my_set.add(n)
print('my_set',my_set)

#Using Set Comprehension
my_set_comp = {n for n in nums}
print('my_set_comp',my_set_comp)


not_eq = [(x, y) for x in [1,2,3] for y in [3,1,4] if x != y]
print('Map which is unequal',not_eq)


'''
Comprehension in Tuple acts as a Generator
Generator Expression
Yield 'n*n' for each 'n' in nums
'''
nums = [1,2,3,4,5,6,7,8,9,10]
# def gen_func(nums):
#     for n in nums:
#         yield n*n
# my_gen = gen_func(nums)

my_gen = (n*n for n in nums)
print('my_gen',my_gen) #Gives generator object. So iterastor through it
for i in my_gen:
    print(i)


'''
Assigning a local variable in a comprehension in 3.8
'''
def append_to_list():
    n = int(input('How many - '))
    even = [x for _ in range(n) if (x := int(input('Enter an even number - '))) % 2 == 0]
    print(even)
append_to_list()