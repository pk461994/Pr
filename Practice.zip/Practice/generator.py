from time import sleep
import os
import sqlite3
from sqlite3 import connect

def add1(x, y):
    return x+y

class Adder:
    def __init__(self):
        self.z = 10
    def __call__(self, x, y):
        self.z += 1
        return x + y + self.z
add2 = Adder()


def compute():
    rv = []
    for i in range(10):
        sleep(.5)
        rv.append(i)
    return rv

# Generator formulation using class
class Compute:
    def __iter__(self):
        self.last = 0
        return self
    def __next__(self):
        rv = self.last      # Take the last element
        self.last += 1      # Increase the last element by 1
        if self.last > 10:
            raise StopIteration()
        sleep(0.5)
        return rv
for val in Compute():
    print(val)


# Uisng Generator
def compute():
    for i in range(10):
        sleep(.5)
        yield i


# To make queries faster
def fetch_many_wrapers(result, count=20000):
    '''
    In an effort to speed up queries, this wrapper fetches count objects at a time. 
    Otherwise our implementations has sqlalchemy fetching 1 row at a time(~30x slower) 
    '''
    done = False
    while not done:
        items = result.fetchmany(count)
        done = len(items) == 0
        if not done:
            for item in items:
                yield item

# Recursive generator example. Pass a base_dir and recurse will give all the files withing the directory
def find_files(base_dir, recurse = False):
    # yield files found in base_dir
    for name in os.listdir(base_dir):
        filepath = os.path.join(base_dir, name)
        if os.path.isdir(filepath) and recurse:
            # make sure to iterate when recursing!
            for child in find_files(filepath, recurse):
                yield child
        else:
            yield filepath