# To find all the occurance of a substring present in a string

input_str = input('Enter main string: ')
input_sub_str = input('Enter sub string: ')

flag = False
pos = -1
n = len(input_str)

while True:
    pos = input_str.find(input_sub_str, pos+1, n)
    if pos == -1:
        break
    print('Found at position: ',pos)
    flag = True
if flag == False:
    print('Not Found')

# Find number of occurance of each character present in given string
s = input('Enter the string: ')
d = {}
for x in s:
    if x in d.keys():
        # print('Before',d[x])
        d[x] = d[x] + 1
        # print('After',d[x])
    else:
        d[x] = 1
for k,v in d.items():
    print(f'{k} = {v} Times')

# Reverse even index elements in string
s = 'String to be played with'
l = s.split()
i = 0
l1 = []
while i <len(l):
    if i % 2 == 0:
        l1.append(l[i])
    else:
        l1.append(l[i][::-1])
    i = i+1
print(l1)