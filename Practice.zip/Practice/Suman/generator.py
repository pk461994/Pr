class Example:
    name_is = 'Suman'
    size_is = 'XXL'
    def __init__(self, *args, **kwargs):
        # self.name_of = 'Prashant'
        # self.size_of = 'Medium'
        for k, v in kwargs.items():
            setattr(self, k, v)