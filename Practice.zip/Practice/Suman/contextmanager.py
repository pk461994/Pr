from sqlite3 import connect, Connection
# Using sqlite3 connection context manager

# with connect('test.db') as conn:
#     cur = conn.cursor()
#     cur.execute('CREATE TABLE points (x int, y int)')
#     cur.execute('insert into points (x,y) values(1,1)')
#     cur.execute('insert into points (x,y) values(1,2)')
#     cur.execute('insert into points (x,y) values(2,1)')
#     for row in cur.execute('select x, y from points'):
#         print(row)
#     for row in cur.execute('select sum(x * y) from points'):
#         print(row)

# # Using custom context manager
# class Temptable:
#     def __int__(self, cur):
#         self.cur = cur
#     def __enter__(self):
#         self.cur.execute('create table points(x int, y int)')
#     def __exit__(self, *args):
#         self.cur.execute('drop table points')

# The same example using generator
from contextlib import contextmanager

# @contextmanager
# def temptable(cur):
#     cur.execute('create table points(x int, y int)')
#     print('Table created')
#     try:
#         yield
#     finally:
#         cur.execute('drop table points')
#         print('Table dropped')



# with connect('test.db') as conn:
#     cur = conn.cursor()
#     with temptable(cur):
#         cur.execute('insert into points (x,y) values(1,1)')
#         cur.execute('insert into points (x,y) values(1,2)')
#         cur.execute('insert into points (x,y) values(2,1)')
#         for row in cur.execute('select x, y from points'):
#             print(row)
#         for row in cur.execute('select sum(x * y) from points'):
#             print(row)

# Using generator as context manager
def generator_context_manager(original_func):
    class _WithContextManager:
        def __init__(self, func, *args, **kwargs):
            self.generator = func(*args, **kwargs)
        
        def __enter__(self):
            print('Inside enter')
            return next(self.generator)

        def __exit__(self, t, v, traceback):
            print('Inside Exit')
            try:
                next(self.generator)
            except StopIteration:
                pass
            return True
    def wrapper(*args, **kwargs):
        return _WithContextManager(original_func, *args, **kwargs)
    return wrapper

@generator_context_manager
def generate():
    print('Generate func')
    yield 1
    print('Out Generator')

from contextlib import contextmanager
@contextmanager
def temptable(cur):
    cur.execute('create table points(x int, y int)')
    print('Table created')
    yield
    cur.execute('DROP TABLE points')
    print('Table Dropped')