import sqlite3

def convert_to_value(value):
    converters = {
        str.__name__                : lambda x : f"'{x}'",
        int.__name__                : lambda x : str(x),
        float.__name__              : lambda x : str(x),
        None.__class__.__name__     : lambda x : 'NULL',
    }
    return converters[value.__class__.__name__](value)

def convert_to_column(key, value):
    converters = {
        str.__name__                : lambda x : f'{x} VARCHAR',
        int.__name__                : lambda x : f'{x} BIGINT',
        float.__name__              : lambda x : f'{x} DECIMAL',
        None.__class__.__name__     : lambda x : f'{x} VARCHAR NULL',
    }
    return converters[value.__class__.__name__](key)

def generate_createtable_sql(table, content):
    columns = [convert_to_column(k, v) for k, v in content.items()]
    return f"CREATE TABLE IF NOT EXISTS {table} ({','.join(columns)})"

def generate_inserttable_sql(table, content):
    columns = [key for key in content.keys()]
    values = [convert_to_value(v) for v in content.values()]
    return f"INSERT INTO {table} ({','.join(columns)}) VALUES ({','.join(values)})"

class Person:
    connection = sqlite3.connect('person.db')

    @classmethod
    def table_name(cls):
        return cls.__name__.lower()+'s'
    
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
        self.cursor = self.connection.cursor()
        sql = generate_createtable_sql(self.table_name(), self.kwargs)
        print('Create Table SQL is:', sql)
        self.cursor.execute(sql)
        self.connection.commit()

    def __hide(self):
        for k, v in self.kwargs.items():
            setattr(self, k, v)

    def save(self):
        sql = generate_inserttable_sql(self.table_name(), self.kwargs)
        print('Insert Table SQL is:', sql)
        self.cursor.execute(sql)
        self.connection.commit()