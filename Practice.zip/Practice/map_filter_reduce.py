# Passing list of functions as input using Map function
def multiply(x):
    return x*x

def add(x):
    return x+x
funcs = [multiply, add]
for i in range(10):
    value = list(map(lambda x: x(i) ,funcs))
    print('multiply, add:',value)

# Conver Fahrenheit tp Celsius using Map function
temps_in_f = [('Berliun',29) , ('Los Angeles',26), ('New Delhi', 30), ('Ranchi', 22), ('New York', 28)]
temp_in_c = list(map(lambda data: (data[0], (9/5)*data[1]+32) , temps_in_f))
print('Temperature in degree Celsius:',temp_in_c)

# Find all data greater than the average in a list using Filter function
import statistics
data = [1.3, 2.7, 0.8, 4.1, 4.3, -0.1]
average = statistics.mean(data)
print('Average of data in list:',average)
data_gt_avg = list(filter(lambda x: x>average, data))
print('Data in list greater than average are:',data_gt_avg)

# Remove missing data from list using Filter Funtion
countries = ['India', {}, 'America', (), 'Israel', '', 0, 0.0, 'Japan', [], 'Germany', 0j, False, 'France', None, 'Australia', 'Russia']
result = list(filter(None, countries))
print('Result after removing missing data:',result)

# Multiply all nos in list using Reduce function
from functools import reduce
data = [2,3,4,6,3,7,8,10]
mul = reduce(lambda x,y: x*y, data)
print(mul)


